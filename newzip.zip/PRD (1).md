# PRD.md
## Product Requirements Document
## Online Salon Appointment and Queue Management System

**Document type:** Product Requirements Document  
**Delivery model:** Multi-tenant B2B SaaS  
**Initial customer experience:** Responsive Web / PWA  
**Business focus:** Hair salons and barbershops  
**Primary operational model:** Mixed scheduled appointments + walk-ins  
**Implementation approach:** Sequential, module-by-module delivery  
**Existing product:** Reference-only; must remain unchanged  

---

# 1. Product Vision

Build a salon/barbershop operating platform that combines:

- scheduled appointments
- walk-in demand
- virtual queueing
- live estimated waiting ranges
- remote waiting
- staff availability
- service duration
- constrained resources
- customer notifications

into one shared capacity-management system.

The product must not be designed as an appointment calendar with an unrelated waitlist attached.

The core product proposition is:

> **One live operational schedule for appointments, walk-ins, staff, resources, and real waiting time.**

---

# 2. Customer Value Proposition

For customers:

> **Know when your chair will be ready before you walk into the salon.**

For salons:

> **One live schedule for appointments, walk-ins, staff and real waiting time.**

The product should reduce unnecessary physical waiting while helping salons operate peak demand more effectively.

A virtual queue by itself does not necessarily reduce total service-system delay. The product must separately measure:

- total waiting
- remote waiting
- physical in-salon waiting

The goal is not merely to move a customer from a physical line to a digital line. Later scheduling and staffing improvements should attempt to reduce total delay as well.

---

# 3. Product Principles

1. Appointments and walk-ins share the same finite staff/resource capacity.
2. Customer wait estimates must be operationally credible.
3. Show ETA ranges rather than false single-minute precision.
4. Keep the customer entry experience low-friction.
5. Staff workflows must require very few taps.
6. Receptionists need a merged operational view and controlled manual overrides.
7. All manual overrides affecting operations must be auditable.
8. Booking capacity must be transactionally protected.
9. Realtime delivery must never replace authoritative server state.
10. Multi-tenant isolation is a critical security requirement.
11. Build PWA-first; native customer apps are deferred.
12. Start ETA with explainable deterministic/statistical logic.
13. Avoid premature microservices.
14. Do not expand into marketplace/POS/payroll before validating the operational core.

---

# 4. Target Users and Personas

## 4.1 Booked Customer

### Problem
A confirmed appointment is not useful if the salon is running significantly late and the customer discovers it only after arriving.

### Needs
- confirmed appointment
- current delay
- realistic arrival guidance
- cancel/reschedule
- reminders
- check-in
- payment/deposit information

---

## 4.2 Walk-In Customer

### Problem
The customer cannot determine whether waiting will be 5 minutes or 50 minutes before traveling to the salon.

### Needs
- live wait range
- remote queue joining
- estimated service time
- recommended arrival time
- current status
- alerts when ETA changes
- check-in
- leave queue

---

## 4.3 Parent / Group Customer

### Problem
Multiple sequential or parallel services may require realistic multi-staff capacity.

### MVP Position
Basic group support may be deferred unless specifically prioritized.

### Later Needs
- multiple customers/services
- parallel/sequential feasibility
- combined duration
- multi-staff assignment

---

## 4.4 Stylist / Barber

### Problem
Operational software must not distract from delivering services.

### Needs
- today view
- next customer
- start
- complete
- running late
- break
- unavailable
- minimal service/customer notes where permitted

---

## 4.5 Receptionist

### Problem
Must reconcile:

- appointments
- walk-ins
- late customers
- telephone requests
- cancellations
- staff delays
- breaks
- manual changes

### Needs
- one merged operational timeline
- walk-in queue
- staff status
- upcoming appointments
- risks/delays
- manual queue addition
- safe overrides
- reassignments
- check-in

---

## 4.6 Salon Owner / Manager

### Problem
Peak/weekend crowding, idle time, no-shows, overtime, inconsistent service duration.

### Needs
- waiting analytics
- utilization
- demand patterns
- policy controls
- cancellation/no-show metrics
- later staffing recommendations

---

## 4.7 Multi-Location Operator

### Problem
Demand and spare capacity may be uneven across nearby locations.

### MVP Position
Data model should be multi-location ready.

### Later Needs
- cross-location visibility
- alternative-location recommendation
- cross-location balancing
- consolidated analytics

---

## 4.8 Platform Administrator

### Problem
Operate many independent salon tenants without exposing tenant data.

### Needs
- tenant onboarding
- subscription state
- role/user administration
- support tooling
- feature flags
- provider health
- payment/webhook failure visibility
- notification logs
- audit trails

---

# 5. Application Surfaces

The platform contains five primary surfaces.

## 5.1 Customer PWA

MVP capabilities:

- salon/location selection
- service selection
- staff preference
- current live wait
- appointment availability
- guest/OTP-ready booking
- virtual queue joining
- ETA range
- recommended arrival time
- notification preference
- cancellation
- rescheduling
- check-in
- deposit/payment where required
- booking history
- queue history

Later:

- favorites
- memberships
- loyalty
- family profiles
- native wallet passes
- native apps
- cross-location suggestions

---

## 5.2 Salon Dashboard

MVP capabilities:

- unified appointments + walk-ins operational view
- waiting customers
- current ETA/delay
- staff status
- upcoming appointments
- manual queue add
- safe booking move/reassignment
- kiosk/QR management
- policies
- services
- durations
- chairs/resources
- deposits/refunds
- notification controls
- basic reporting

Later:

- forecast heat map
- staffing optimizer
- advanced resource scheduling
- multi-location balancing
- revenue optimization
- campaigns

---

## 5.3 Staff PWA

MVP capabilities:

- today view
- next customer
- start service
- complete service
- mark running late
- mark no-show where authorized
- break
- unavailable
- ETA adjustment workflow where authorized
- push-ready notifications
- cached current-day operational data

Later:

- commission/tip views
- availability requests
- shift trades
- performance dashboard

---

## 5.4 Check-In / Kiosk

MVP capabilities:

- appointment check-in
- queue-entry check-in
- new walk-in join
- QR-based access
- privacy-safe ticket lookup

Public displays must not reveal unnecessary customer PII.

---

## 5.5 Platform Admin

MVP capabilities:

- tenant onboarding
- subscription state
- tenant/user/role management
- support cases
- feature flags
- provider health
- payment/webhook failure visibility
- notification logs
- audit logs

Later:

- enterprise SSO controls
- reseller/white-label controls
- enterprise contracts
- regional residency controls

---

# 6. MVP Functional Modules

```text
01. Foundation
02. Identity / Tenancy / RBAC
03. Locations
04. Services
05. Staff / Skills / Shifts / Breaks
06. Resources / Chairs
07. Policies
08. Availability
09. Booking
10. Virtual Queue
11. Dispatch
12. ETA
13. Realtime
14. Customer PWA
15. Salon Dashboard
16. Staff PWA
17. Notifications
18. Payments
19. Cancellation / Rescheduling
20. Appointment Waitlist / Refill
21. QR / Kiosk
22. Platform Admin
23. Analytics
24. Offline Staff Support
25. Audit / Privacy / Security
26. Observability / Deployment
```

---

# 7. Recommended Sequential Delivery Plan

## Phase 00 — Existing Product Read-Only Analysis

### Objective
Understand the existing product without changing it.

### Output
- verified stack
- module map
- API inventory
- data model summary
- authentication/authorization map
- reusable conceptual patterns
- risks
- unknowns

### Gate
No code modifications allowed.

---

## Phase 01 — Gap Analysis

Compare verified existing capabilities to this PRD.

Classify each requirement:

```text
EXISTS
PARTIAL
MISSING
NOT APPLICABLE
```

### Output
- gap matrix
- dependency graph
- architectural conflicts
- MVP implementation plan

---

## Phase 02 — New Application Architecture

Design the new isolated application.

### Required outputs
- system context
- module map
- database/domain model
- API conventions
- auth model
- tenant strategy
- realtime architecture
- background/event architecture
- payment abstraction
- notification abstraction
- testing strategy
- deployment strategy

### Gate
No business implementation until architecture is approved.

---

## Phase 03 — Project Foundation

Implement:

- isolated application
- configuration validation
- database connection
- optional cache connection
- global error handling
- request IDs
- structured logging
- health/readiness endpoints
- testing framework
- provider interfaces

---

## Phase 04 — Multi-Tenancy + Authentication + RBAC

Implement:

```text
TENANT
USER
ROLE
PERMISSION
USER_TENANT
USER_LOCATION
SESSION
AUDIT_LOG
```

Initial roles:

```text
PLATFORM_ADMIN
SALON_OWNER
SALON_MANAGER
RECEPTIONIST
STAFF
```

### Acceptance
Cross-tenant access attempts fail.

---

## Phase 05 — Salon Master Data

Implement:

```text
LOCATION
SERVICE
STAFF
STAFF_LOCATION
STAFF_SERVICE
SHIFT
BREAK
RESOURCE
POLICY
```

---

## Phase 06 — Booking + Availability

Implement:

```text
APPOINTMENT
APPOINTMENT_ITEM
RESOURCE_RESERVATION
BOOKING_HOLD
```

### Critical acceptance criterion
Two concurrent customers cannot confirm the same staff/resource interval.

---

## Phase 07 — Virtual Walk-In Queue

Implement:

```text
QUEUE_ENTRY
QUEUE_EVENT
```

Queue states:

```text
WAITING
APPROACHING
CALLED
CHECKED_IN
IN_SERVICE
COMPLETED
CANCELLED
EXPIRED
NO_SHOW
```

---

## Phase 08 — ETA + Dispatch

Implement deterministic/statistical ETA V1.

### Output
- predicted service start
- lower ETA bound
- upper ETA bound
- recommended arrival
- confidence indicator
- model version

---

## Phase 09 — Realtime Infrastructure

Implement:

- WebSocket for salon/staff
- SSE or equivalent customer stream
- polling fallback
- tenant/location subscription authorization
- reconnect handling
- event deduplication

---

## Phase 10 — Customer PWA

Build mobile-first customer experience after core operational APIs are stable.

---

## Phase 11 — Salon Operations Dashboard

Build merged operational view.

---

## Phase 12 — Staff PWA

Build low-friction operational actions.

---

## Phase 13 — Notification Engine

Implement provider abstraction and event-driven notifications.

---

## Phase 14 — Payments

Implement provider abstraction, tokenized/hosted payment flow, secure webhooks and idempotency.

---

## Phase 15 — Cancellation / Rescheduling / Waitlist Refill

Implement policy-driven cancellation and opening refill workflow.

---

## Phase 16 — QR / Kiosk

Implement privacy-safe check-in and walk-in joining.

---

## Phase 17 — Platform Admin

Implement operational SaaS administration.

---

## Phase 18 — Analytics

Implement operational metrics.

---

## Phase 19 — Offline Staff Behaviour

Implement limited safe offline mutations.

---

## Phase 20 — Security / Privacy / Audit Hardening

Perform cross-application hardening and privacy workflow implementation.

---

## Phase 21 — Testing / Observability / Deployment

Complete production hardening.

---

## Phase 22 — MVP Readiness Audit

No new features.

Classify every requirement:

```text
PASS
PARTIAL
FAIL
NOT IMPLEMENTED
DEFERRED
```

Release only after critical invariants pass.

---

# 8. Core Data Model

The exact physical schema may differ after architecture review, but the domain requires the following concepts.

## TENANT

Represents an independent salon business/customer.

Suggested data:

- id
- name
- subscription plan/state
- status
- timestamps

---

## LOCATION

Suggested data:

- id
- tenant_id
- name
- timezone
- address
- operating hours
- status

---

## CUSTOMER

Suggested data:

- id
- tenant_id or customer-scope strategy per approved architecture
- name
- phone
- email
- consent metadata
- timestamps

Do not collect unnecessary customer information.

---

## STAFF

Suggested data:

- id
- tenant_id
- name
- operational status
- active state

Related through:

- staff locations
- staff services/skills
- shifts
- breaks

---

## SERVICE

Suggested data:

- id
- tenant_id
- name
- description
- configured duration
- price
- active status
- resource requirements where applicable

---

## RESOURCE

Examples:

- chair
- room
- equipment

Resources can be capacity constraints independent of staff.

---

## POLICY

Potential settings:

- cancellation window
- cancellation fee
- deposit requirement
- no-show handling
- late-arrival grace
- queue grace
- check-in behavior

---

## APPOINTMENT

Suggested data:

- id
- tenant/location/customer
- start/end
- state
- idempotency key
- timestamps

---

## APPOINTMENT_ITEM

Represents one or more services within the appointment.

---

## RESOURCE_RESERVATION

Represents authoritative consumption of staff/resource capacity for a time range.

Must support non-overlap/concurrency protection according to the approved data-store architecture.

---

## BOOKING_HOLD

Short-lived temporary reservation during booking/payment.

Must expire automatically.

---

## QUEUE_ENTRY

Suggested data:

- customer
- location
- requested service
- preferred staff
- joined time
- current state
- priority/fairness metadata where approved
- check-in metadata

---

## QUEUE_EVENT

Append-only history of queue changes.

Used for:

- auditability
- analytics
- debugging
- later prediction model development

---

## WAIT_ESTIMATE

Suggested data:

- queue entry
- predicted start
- lower bound
- upper bound
- recommended arrival
- confidence
- model version
- calculated timestamp

---

## NOTIFICATION

Suggested data:

- event/type
- recipient reference
- channel
- provider
- provider reference
- status
- attempt count
- failure
- timestamps

---

## PAYMENT

Suggested data:

- appointment
- amount
- currency
- provider
- processor reference/token reference
- status
- refund status
- timestamps

Never store raw card data.

---

## AUDIT_LOG

Record sensitive administrative/operational actions with:

- actor
- tenant
- location where relevant
- action
- target type/id
- timestamp
- reason where required
- correlation ID

---

# 9. Booking Workflow

## 9.1 Appointment Booking

```text
Customer opens salon
        ↓
Choose location
        ↓
Choose service
        ↓
Choose "Later"
        ↓
Calculate authoritative availability
        ↓
Choose staff or Any Staff
        ↓
Create short-lived capacity hold
        ↓
Deposit/payment required?
        ↓
If required, complete tokenized/hosted payment step
        ↓
Revalidate availability
        ↓
Transactionally reserve staff/resources
        ↓
Confirm booking
        ↓
Send confirmation/reminders
```

### Requirements

- Availability must be recalculated immediately before confirmation.
- Temporary holds must expire.
- Booking creation must be idempotent.
- Capacity reservation must be authoritative and concurrency safe.
- Never trust a slot merely because it was displayed earlier.
- A failed payment must not leave permanent accidental capacity unless the workflow explicitly supports it.

---

# 10. Availability Rules

Availability calculation must evaluate:

- location
- timezone
- operating hours
- requested service
- service duration
- staff service skill
- staff assigned location
- staff shift
- staff break
- appointment conflicts
- temporary holds
- resource requirements
- resource conflicts
- staff preference
- policy restrictions

Support:

```text
Specific Staff
Any Eligible Staff
```

"Any Staff" must be resolved server-side using the approved availability/dispatch strategy.

---

# 11. Virtual Walk-In Queue

## Customer View

The primary experience should show:

```text
Estimated service: 12:35–12:45
Estimated wait: 24–34 minutes
Recommended arrival: 12:27
Status: Waiting remotely
```

Do not rely only on:

```text
3 people ahead
```

because multiple staff, skills, service durations, breaks, and appointments can make simple position misleading.

---

# 12. Queue State Machine

Valid high-level states:

```text
WAITING
    ↓
APPROACHING
    ↓
CALLED
    ↓
CHECKED_IN
    ↓
IN_SERVICE
    ↓
COMPLETED
```

Terminal alternatives:

```text
CANCELLED
EXPIRED
NO_SHOW
```

A configurable grace window is required.

When a called customer misses the expected arrival/call, authorized staff should be able to postpone or apply the configured policy without corrupting the rest of the queue.

All transitions must be auditable.

---

# 13. Dispatch Requirements

The dispatcher must determine the earliest feasible assignment of queue work while protecting upcoming appointments.

Inputs include:

- eligible staff
- staff skill
- current service status
- expected completion
- scheduled appointments
- breaks
- shifts
- staff preference
- requested service
- duration
- constrained resources
- customer check-in/grace status

The dispatch engine must not sacrifice booked appointment punctuality without explicitly approved business rules.

---

# 14. ETA Engine V1

Do not begin with "AI scheduling".

ETA V1 should be explainable.

Initial duration basis:

1. configured service duration
2. blend with verified observed duration history when sufficient data exists
3. optionally use staff-specific history later

Recalculate when relevant operational state changes.

Examples:

- walk-in joins/leaves
- staff starts service
- service completes
- staff becomes unavailable
- break begins/ends
- appointment created/changed/cancelled
- customer checks in
- grace window expires
- material duration adjustment

### Customer output
Use ranges, not false precision.

### Monitoring
Track prediction error against actual service start.

---

# 15. Salon Dashboard Requirements

Main operational view should combine:

## Walk-In Queue
Show:

- customer/ticket
- requested service
- ETA range
- state
- staff preference
- check-in state

## Staff
Show:

- available
- in service
- expected completion
- break
- unavailable
- late/risk state where relevant

## Upcoming Appointments
Show:

- time
- customer
- service
- assigned staff or any staff
- risk/delay indicators

## Operational Actions

Authorized users may:

- add walk-in manually
- assign/reassign staff
- take next
- call customer
- mark checked in
- postpone according to policy
- mark appointment late/no-show
- mark staff unavailable
- move break where permitted
- safely move appointment
- apply documented manual override

Every significant override must be audited.

---

# 16. Staff PWA Requirements

Primary actions should be immediately accessible:

```text
NEXT CUSTOMER
START SERVICE
COMPLETE SERVICE
RUNNING LATE
BREAK
UNAVAILABLE
```

The interface should minimize typing and navigation.

Each service-state mutation must be:

- authorized
- validated
- idempotent where appropriate
- reflected in queue/ETA recalculation
- auditable where relevant

---

# 17. Customer PWA Requirements

Primary landing experience should answer:

1. What services are available?
2. How long is the current wait?
3. Can I join remotely?
4. Can I reserve a later appointment?

Customer states must include:

- loading
- no availability
- queue open
- queue closed
- waiting
- approaching
- called
- checked in
- in service
- completed
- cancelled
- expired
- stale ETA
- network error
- offline/read-only where supported

Target WCAG 2.2 AA.

---

# 18. Realtime Requirements

Recommended use:

| Mechanism | Primary use |
|---|---|
| WebSocket | Salon dashboard and staff operational state |
| SSE | Active customer queue status |
| Polling | Fallback |
| Push | Background customer alerts |
| SMS | Important fallback / configured reminders |

Requirements:

- authenticated channels where needed
- tenant/location scoping
- reconnect support
- event IDs
- deduplication
- stale-state recovery
- fallback polling

Authoritative data must always be retrieved from server-side state.

---

# 19. Notification Requirements

Support provider abstraction.

Initial channels:

- Email
- SMS
- Push

Future:

- WhatsApp

Events may include:

- appointment confirmed
- appointment reminder
- appointment changed
- appointment cancelled
- queue joined
- material ETA change
- approaching
- leave-for-salon
- next/called
- waitlist opening
- payment receipt

Store delivery lifecycle.

Prevent duplicate sends for idempotent events.

---

# 20. Cancellation and Rescheduling

Policy configuration should support combinations of:

- free cancellation window
- fixed fee
- percentage fee
- deposit forfeiture
- no-show charge
- discretionary manager waiver

High-level flow:

```text
Cancellation request
        ↓
Evaluate salon policy
        ↓
Calculate fee/refund
        ↓
Process payment/refund if applicable
        ↓
Cancel appointment
        ↓
Release capacity
        ↓
Find matching waitlist candidate
        ↓
Create timed offer
        ↓
Accepted?
   ┌────┴────┐
   Yes       No
   ↓          ↓
Create       Offer next
replacement  candidate
booking
```

The workflow must remain idempotent and concurrency safe.

---

# 21. Appointment Waitlist / Cancellation Refill

A waitlist for appointment openings is distinct from the live walk-in queue.

Requirements:

- customer can express acceptable opening criteria
- candidate selection must match requested service/staff/location/time rules
- offer should expire
- accepted offer must go through authoritative availability validation
- only one candidate can acquire the capacity
- if not accepted, safely offer the next candidate

---

# 22. Payment Requirements

Supported salon models:

| Model | Behavior |
|---|---|
| Pay in salon | No online financial transaction required |
| Deposit | Fixed/percentage amount at booking |
| Full prepayment | Full amount charged |
| Card on file / no-show protection | Processor token/reference only |

Rules:

- never store raw card number
- never store CVV
- use provider tokenization/hosted components
- payment provider must be abstracted
- webhook signatures must be validated
- webhook processing must be idempotent
- refunds must be tracked
- payment state must be auditable

---

# 23. QR / Kiosk Check-In

Support:

- appointment check-in
- queue-entry check-in
- new walk-in queue join
- privacy-safe ticket lookup

Security-sensitive queue links must use opaque unguessable tokens.

Public displays must show only minimum necessary customer information.

---

# 24. Platform Administration

Required:

- tenant onboarding
- tenant state
- subscription state
- users
- roles
- locations
- feature flags
- support cases
- provider health
- payment/webhook failures
- notification failure logs
- audit search

Support impersonation, if implemented, must:

- require explicit reason
- be time-limited
- be visible
- record administrator
- record tenant
- record start/end
- create audit trail

Invisible permanent impersonation is prohibited.

---

# 25. Analytics Requirements

Track at minimum:

| Metric | Purpose |
|---|---|
| Median in-shop wait | Core customer objective |
| P90 in-shop wait | Exposes peak failures |
| Total queue delay | Distinguishes real reduction from remote relocation |
| Remote waiting | Shows waiting moved off-site |
| ETA absolute error | Tests prediction trustworthiness |
| ETA interval coverage | Tests whether ranges contain actual start |
| Queue abandonment | Measures lost walk-in demand |
| Appointment no-show | Booking quality |
| Cancellation refill | Waitlist value |
| Staff utilization | Capacity efficiency |
| Overtime | Staffing quality |
| On-time appointment start | Protects booked customers |
| Manual overrides | Reveals workflow/algorithm weakness |
| Booking conversion | Customer UX |
| Queue conversion | Customer UX |
| Notification delivery | Operational reliability |
| Weekend throughput | Peak-period impact |

Suggested north-star metric:

> **In-shop customer waiting minutes avoided per completed visit, while maintaining appointment punctuality and acceptable staff utilization.**

Do not market modeled wait reductions as guaranteed production results.

---

# 26. Offline Staff Requirements

Cache:

- current day's assigned appointments
- recent queue state

Safe offline mutations may include:

- start service
- complete service
- permitted notes

Do not allow confirmed future appointment creation offline.

Reconnection flow:

```text
Offline action
    ↓
Local durable mutation
    ↓
Connection restored
    ↓
Send with idempotency key
    ↓
Conflict?
 ┌────┴────┐
 No        Yes
 ↓          ↓
Commit     Apply approved
            conflict policy
            or manager review
```

---

# 27. Security Requirements

The most important application-level security risk is cross-tenant data exposure.

Mandatory controls:

- tenant-scoped authorization
- location-scoped authorization where applicable
- IDOR prevention
- role-based access
- customer OTP/passwordless-ready architecture
- MFA-ready privileged access
- platform-admin strong authentication
- secure session lifecycle
- session/device revocation
- rate limiting
- bot/OTP abuse protection
- secure transport
- secure storage
- secret management
- audit events
- dependency scanning
- centralized monitoring
- redacted logs

---

# 28. Privacy Requirements

Architecture should support privacy workflows appropriate to the final deployment jurisdiction.

Product capabilities should include:

- access/export
- correction
- deletion where legally applicable
- retention
- consent records
- consent revocation
- marketing opt-out
- processor/provider governance support

Data minimization is required.

Suggested data treatment:

| Data | Treatment |
|---|---|
| Name/phone/email | Protected personal data |
| Service preferences | Collect only when operationally useful |
| Queue position/ETA | Operational personal data |
| Service start/end | Useful for analytics; minimize/pseudonymize for long-term use |
| Marketing consent | Maintain consent/revocation history |
| Staff schedule | Confidential business/employment data |
| Card/CVV | Never store |
| Provider token/reference | Restricted, audited |
| Logs | Redact sensitive content |

---

# 29. Non-Functional Requirements

The source requirements propose the following production planning targets.

| Area | Target |
|---|---|
| Availability | 99.9% for MVP/pilot |
| Queue freshness | Connected updates p95 around 2 seconds |
| Booking latency | Normal app reads/writes p95 around 500 ms excluding external payment calls |
| Critical notification dispatch | Handed to provider around 30 seconds |
| Booking/payment consistency | Strong |
| Analytics consistency | Eventual acceptable |
| Scalability | Horizontally scalable stateless application nodes |
| Peak handling | Explicit Friday/Saturday load tests |
| Offline customer | Read-only cached state; no booking confirmation without server |
| Recovery | Backups + point-in-time recovery where supported + tested restore |
| Multi-tenancy | Every business query tenant scoped |
| Accessibility | WCAG 2.2 AA target |
| Time | Store timestamps consistently; display/evaluate using location timezone |
| Observability | Logs, metrics, traces and provider/realtime health |
| Idempotency | Booking, cancellation, payment, webhook and queue mutation operations |

These are engineering targets and should be validated against the selected infrastructure during architecture/design.

---

# 30. Architecture Requirements

Recommended MVP architecture:

```text
Customer PWA
Salon Dashboard
Staff PWA
Check-In Kiosk
       ↓
CDN / WAF / API Gateway
       ↓
Application API + Realtime Gateway
       ↓
Modular Monolith
 ├─ Identity / Tenant Access
 ├─ Booking
 ├─ Availability
 ├─ Queue / Dispatch
 ├─ Scheduling / ETA
 ├─ Payments
 ├─ Notifications
 ├─ Demand / Staffing (later)
 ├─ Analytics
 └─ Admin / Billing
       ↓
Authoritative Database
Cache / Ephemeral State
Durable Event Queue
Object Storage
       ↓
Email / SMS / Push / Payment Providers
```

The source recommends:

- modular monolith first
- authoritative relational datastore
- cache only for reconstructible state
- durable async event handling
- WebSocket/SSE realtime
- managed deployment where practical

Do not introduce independent microservices in the MVP without a measured need.

---

# 31. Database Integrity Requirements

Confirmed booking state must never exist only in cache.

Temporary/cache data may include:

- slot holds
- computed ETA cache
- rate-limit counters
- active connection mapping
- pub/sub fan-out

Authoritative records must live in the selected primary database.

Resource reservation must support concurrency-safe non-overlap semantics.

The approved architecture must document exactly how the chosen database guarantees this invariant.

---

# 32. Error Handling

All APIs must use a documented error model.

At minimum distinguish:

- validation failure
- authentication failure
- authorization failure
- tenant mismatch
- resource not found
- stale version/state
- slot unavailable
- hold expired
- invalid queue transition
- payment failure
- provider unavailable
- rate limit
- conflict
- internal failure

Client messages must be safe and useful without exposing sensitive implementation details.

---

# 33. Idempotency Requirements

Idempotency is mandatory for high-risk mutation paths:

- appointment creation
- appointment cancellation
- rescheduling where applicable
- queue join/mutations where duplicate delivery is possible
- payment creation
- refund initiation
- payment webhooks
- notification-trigger processing where appropriate

Repeated identical requests must not produce duplicate bookings, duplicate charges, or duplicate state transitions.

---

# 34. Audit Requirements

Audit at minimum:

- privileged login/security events
- role/permission changes
- tenant/location configuration changes
- policy changes
- manual queue overrides
- manual ETA adjustments
- support impersonation
- payment/refund administrative actions
- appointment overrides
- sensitive customer-data access where required by approved policy

Audit records should be append-oriented and protected against casual modification.

---

# 35. Observability

Track:

- API errors/latency
- booking conflicts
- booking failures
- hold expiry
- queue lag
- ETA recalculation failures
- ETA error
- WebSocket connection/reconnect health
- notification delivery/failure
- payment/webhook failure
- provider latency
- database slow queries
- job retry/dead-letter state
- cross-tenant authorization denials
- audit pipeline health

---

# 36. Deployment Requirements

Maintain separate:

```text
development
staging
production
```

CI/CD should validate, where applicable:

- unit tests
- integration tests
- API/contract tests
- static security checks
- dependency scanning
- migration validation
- build
- lint/type checks
- concurrency tests for critical code

Use feature flags for risky queue/ETA behavior.

Database changes must support safe deployment/rollback strategy.

Have:

- backup policy
- restoration procedure
- incident runbook
- secret rotation procedure
- rollback procedure

---

# 37. MVP Included Scope

Include:

- multi-tenant salon/location setup
- staff, skills, shifts
- services and durations
- resources/chairs
- customer PWA
- appointment booking
- temporary holds
- concurrency protection
- appointment opening waitlist
- live virtual walk-in queue
- ETA range and recalculation
- unified salon dashboard
- staff start/complete/break controls
- QR/kiosk check-in
- SMS/email-ready notification architecture
- cancellation/rescheduling
- configurable cancellation/deposit policy
- payment-provider integration
- basic weekend analytics
- RBAC/security/audit baseline
- platform subscription/admin controls
- limited safe offline staff support

---

# 38. Explicitly Deferred Scope

Do not build during initial MVP unless separately approved:

- public consumer marketplace
- payroll
- full inventory system
- sophisticated loyalty
- AI voice receptionist
- generative AI
- advanced revenue optimization
- native iOS/Android customer apps
- full POS replacement
- enterprise SSO
- multi-region active-active
- complex commission engine
- advanced demand ML
- cross-city consumer discovery
- franchise BI warehouse
- broad third-party ecosystem

---

# 39. Pilot Strategy

A production pilot should include varied salons across:

- team size
- weekend demand pattern
- appointment/walk-in mix
- service duration variation
- customer staff loyalty
- location type

Suggested staged pilot:

1. Measure existing baseline.
2. Enable virtual queue.
3. Measure physical wait moved off-site.
4. Enable active dispatch/staff recommendations later.
5. Measure whether total system delay also changes.

This prevents incorrectly attributing remote waiting to true queue reduction.

---

# 40. Pilot Success Metrics

Suggested pilot objectives from the source requirements include:

- meaningful reduction in median weekend in-shop wait
- ETA median absolute error trending toward an acceptable operational range
- zero capacity-loss/double-booking incidents
- high initiation rate for eligible critical notifications
- high staff adoption of start/end service actions
- declining manual dispatcher overrides
- no material deterioration in appointment punctuality

These are pilot objectives, not customer promises.

---

# 41. Release Blockers

The MVP must not be considered production ready if any of the following remain unresolved:

- known cross-tenant data exposure
- double-booking race condition
- raw card data stored by the application
- unvalidated payment webhooks
- uncontrolled privileged impersonation
- invalid queue transitions possible through public API
- realtime cross-tenant subscription leakage
- no audit trail for critical overrides
- critical authentication bypass
- booking confirmation based only on stale client availability
- known critical data-loss issue
- no backup/recovery plan
- core workflows cannot be tested reliably

---

# 42. Acceptance Criteria by Module

## Foundation
- isolated project boundary exists
- existing product unchanged
- configuration validation works
- structured errors/logging exist
- test framework works

## Identity / Tenancy
- tenant-scoped access enforced
- cross-tenant tests pass
- roles enforced
- privileged actions auditable

## Master Data
- locations/services/staff/resources tenant scoped
- shifts/breaks validated
- service eligibility works

## Booking
- availability reflects real constraints
- booking holds expire
- double-booking concurrency test passes
- booking creation is idempotent

## Queue
- state machine enforced
- append-only event history recorded
- invalid transitions rejected

## ETA
- produces range
- recalculates on required events
- respects appointments/staff/resources
- stores model/version metadata

## Realtime
- scoped subscriptions
- reconnect behavior
- stale-state recovery
- no cross-tenant leakage

## Customer PWA
- live wait visible
- appointment and queue choices clear
- mobile-first
- accessibility target addressed

## Salon Dashboard
- queue/staff/appointments unified
- overrides authorized and audited

## Staff PWA
- start/complete/break flows simple
- actions update authoritative operational state

## Notifications
- provider abstraction
- retries
- delivery status
- deduplication

## Payments
- no raw card storage
- signed webhook validation
- idempotency
- refunds/status tracked

## Cancellation / Waitlist
- policy evaluated
- capacity released safely
- candidate offers expire
- refill remains concurrency safe

## Offline
- only safe mutations allowed
- idempotent reconciliation
- no offline confirmed future booking

## Security
- tenant isolation
- IDOR controls
- rate limiting where required
- log redaction
- audit coverage

## Deployment
- dev/staging/prod strategy
- backups
- observability
- rollback
- load testing of peak scenarios

---

# 43. Development Completion Definition

A module is complete only when:

1. requirements are implemented
2. validation exists
3. authorization exists
4. tenant boundaries are enforced
5. errors are handled
6. logging/audit requirements are covered
7. automated tests exist
8. relevant tests were actually executed
9. documentation matches implementation
10. no existing-product files were modified
11. no critical unresolved blocker remains

---

# 44. Final Product Strategy

Build in this order conceptually:

1. Create one accurate operational model of staff, services, appointments, walk-ins, progress, shifts, breaks and resources.
2. Protect booking capacity transactionally.
3. Build the live queue on top of that capacity model.
4. Calculate explainable ETA ranges.
5. Expose the state through low-friction customer, salon and staff experiences.
6. Use notifications to move unnecessary physical waiting outside the salon.
7. Measure actual service durations, arrival patterns and peak demand.
8. Only after sufficient evidence exists, add demand forecasting and staffing optimization.
9. Expand into marketplace, loyalty, broad POS, payroll or advanced AI only after the core value proposition is validated.

The defensible product opportunity is:

```text
Appointments
+
Walk-Ins
+
Live Predicted Wait
+
Remote Waiting
+
Staff-Capacity Optimization
```
