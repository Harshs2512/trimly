# Online Salon Appointment and Queue Management System
## Existing Product Analysis + New Application Development Prompt Pack

> Source basis: Analysis of the uploaded **“Online Salon Appointment and Queue-Management System”** PDF.
>
> Core implementation rule: **Do not modify the existing product codebase.** Treat it as read-only reference material and build the new salon system in a completely isolated application directory or separate repository.

---

# 1. What the PDF is asking you to build

The new product should **not be only another salon appointment-booking application**.

Its main differentiation is a **hybrid orchestration system** combining:

- Scheduled appointments
- Live walk-ins
- Virtual queues
- Continuously changing ETA ranges
- Staff/resource capacity
- Customer notifications
- Later-stage staffing optimization

The system should treat appointments and walk-ins as **one shared capacity-management problem**.

The recommended product surfaces are:

| Area | Main responsibility |
|---|---|
| Customer PWA | Search/select salon, view live wait, book appointment, join virtual queue, check in, cancel/reschedule, payments |
| Salon Dashboard | Unified appointment + walk-in timeline, queue control, staff status, delays, manual overrides |
| Staff PWA | Today schedule, next customer, start/complete service, late/no-show, break/unavailable |
| Platform Admin | Salon onboarding, tenants, subscriptions, users/roles, audit logs, provider/webhook failures |
| Booking Engine | Availability, temporary holds, conflict prevention, resources, appointments |
| Queue Engine | Virtual walk-ins, queue state transitions, dispatch |
| ETA Engine | Continuously recalculated service ranges |
| Realtime Layer | WebSocket/SSE updates |
| Notification Engine | SMS/email/push reminders and queue alerts |
| Payment Engine | Deposits, prepayment, card-on-file/no-show protection |
| Analytics | Waiting time, ETA accuracy, utilization, weekend demand |
| Optimization | Later staffing and demand recommendations |

The PDF architecture connects:

- Customer PWA
- Salon Dashboard
- Staff PWA
- Kiosk

through API/realtime gateways into:

- Booking
- Queue/Dispatch
- Scheduling & ETA
- Payments
- Notifications
- Demand/Staffing
- Identity
- Admin

The core domain entities are approximately:

```text
TENANT
  ↓
LOCATION
  ↓
STAFF
  ↓
SERVICE
  ↓
APPOINTMENT
  ↓
QUEUE_ENTRY
  ↓
WAIT_ESTIMATE
  ↓
PAYMENT
  ↓
NOTIFICATION
  ↓
AUDIT_LOG
```

with supporting entities such as:

- Shifts
- Staff skills
- Resources
- Appointment items
- Resource reservations
- Queue events

---

# 2. Critical rule for the existing product

Give this instruction to **every coding agent prompt**:

> **The existing application is reference-only. You may inspect it but you must not modify, delete, rename, format, migrate, upgrade, install dependencies into, or otherwise alter any existing source file, configuration file, database migration, package-lock file, environment file, asset or directory. All new implementation must live inside the explicitly designated new application directory/repository.**

Use a strict workspace boundary such as:

```text
/existing-product     READ ONLY
/salon-platform       NEW APPLICATION / WRITE ALLOWED
```

---

# 3. Recommended prompt execution order

Do not use one enormous instruction such as:

```text
Analyze app and create salon system from PDF.
```

Instead, use a module-by-module workflow:

```text
PROMPT 00 - Existing Product Read-Only Analysis
PROMPT 01 - Gap Analysis: Existing Product vs PDF
PROMPT 02 - New Application Architecture

MODULE 01 - Project Foundation
MODULE 02 - Multi-tenancy + Authentication + RBAC
MODULE 03 - Salon / Location / Service / Staff / Resource Management
MODULE 04 - Booking & Availability Engine
MODULE 05 - Virtual Walk-in Queue
MODULE 06 - ETA & Dispatch Engine
MODULE 07 - Customer PWA
MODULE 08 - Salon Operations Dashboard
MODULE 09 - Staff PWA
MODULE 10 - Realtime Infrastructure
MODULE 11 - Notification System
MODULE 12 - Payments
MODULE 13 - Cancellation / Rescheduling / Waitlist Refill
MODULE 14 - QR / Kiosk Check-in
MODULE 15 - Platform Admin
MODULE 16 - Analytics & Reporting
MODULE 17 - Offline Behaviour
MODULE 18 - Security / Privacy / Audit
MODULE 19 - Testing / Observability / Deployment
MODULE 20 - Pilot Metrics & Hardening

LATER
MODULE 21 - Demand Forecasting
MODULE 22 - Staffing Optimizer
MODULE 23 - Multi-location Balancing
MODULE 24 - Advanced Integrations
```

---

# 4. MASTER GOVERNANCE PROMPT

```text
You are acting as the lead software architect and senior full-stack engineer for a new Online Salon Appointment and Queue Management SaaS application.

There is already an existing production/product codebase in this workspace.

CRITICAL SAFETY RULE:

THE EXISTING PRODUCT IS STRICTLY READ-ONLY.

You may:

- inspect source code
- inspect project structure
- inspect package files
- inspect database models
- inspect APIs
- inspect UI components
- inspect authentication
- inspect workflows
- inspect documentation
- inspect environment variable names without exposing secret values
- understand reusable architecture patterns

You must NOT:

- modify existing source files
- modify existing configuration
- modify existing package.json
- modify lock files
- upgrade existing packages
- install packages into the existing application
- run automated formatting against existing files
- rename files
- move files
- delete files
- create database migrations for the existing application
- modify its database schema
- modify its APIs
- change its authentication
- change its behaviour
- change its UI
- commit changes into the existing application

All implementation for the new Salon Appointment and Queue Management System must be created in a completely isolated application directory or separate repository.

Suggested boundary:

/existing-product     READ ONLY
/salon-platform       NEW APPLICATION / WRITE ALLOWED

If the actual repository structure differs, identify an equivalent safe boundary before writing anything.

Before making changes:

1. Inspect the repository.
2. Identify the existing application boundaries.
3. Produce a READ-ONLY inventory.
4. State exactly which new directory/files you intend to create.
5. Verify that none belong to the existing product.
6. Only then start implementation.

PRODUCT OBJECTIVE

Build a multi-tenant B2B SaaS salon/barbershop management platform whose primary differentiator is:

Scheduled appointments
+
live walk-ins
+
virtual queue
+
continuously updated ETA range
+
remote waiting
+
staff/resource capacity orchestration.

The system must treat appointments and walk-ins as one shared capacity-management problem.

Do not reduce the solution to a traditional booking calendar.

APPLICATION SURFACES

1. Customer PWA
2. Salon Dashboard
3. Staff PWA
4. Check-in/Kiosk interface
5. Platform Administration

CORE MODULES

- Identity and Tenant Access
- Salon/Location management
- Staff/skills/shifts
- Services and duration
- Resources/chairs
- Booking
- Availability
- Queue/Dispatch
- ETA engine
- Realtime updates
- Notifications
- Payments
- Cancellation/rescheduling
- Waitlist
- Analytics
- Platform billing/admin
- Audit logging

ENGINEERING PRINCIPLES

Use:

- modular architecture
- strict module boundaries
- secure authentication
- authorization on every privileged operation
- tenant-scoped access
- server-side validation
- idempotent write operations
- transactional capacity reservation
- structured logging
- error handling
- sanitization
- rate limiting where applicable
- audit logging
- automated tests
- accessibility-conscious UI
- responsive PWA design

Avoid premature microservices.

Do not introduce sophisticated AI unless specifically requested.

The initial ETA engine should be deterministic/statistical and explainable.

DATA SAFETY

Never expose:

- passwords
- OTP values
- authentication tokens
- API secrets
- payment credentials
- environment secrets
- raw card data

All logs must redact sensitive information.

PAYMENT RULE

Raw card number or CVV must never be stored by this application.

Use provider tokenization/hosted checkout patterns.

REALTIME RULE

The authoritative state always remains server-side.

WebSocket/SSE/push notifications only communicate changes.

Never treat push notification payloads as authoritative application state.

IMPLEMENTATION PROCESS

For every module:

1. Analyze dependency on previously implemented modules.
2. Define use cases.
3. Define business rules.
4. Define data model.
5. Define API contract.
6. Define authorization.
7. Define validation.
8. Define UI states.
9. Define error states.
10. Implement backend.
11. Implement frontend.
12. Add tests.
13. Add logging/auditing.
14. Document assumptions.
15. Provide changed-file list.

Do not modify unrelated code.

When something required by a module has not yet been implemented, define an interface/adaptor rather than introducing hidden coupling.
```

---

# 5. PROMPT 00 — Analyze Existing Product Without Changing Anything

```text
Perform a comprehensive READ-ONLY analysis of the existing application.

DO NOT WRITE OR MODIFY ANY CODE.

The purpose of this exercise is to understand my current product before designing a separate Salon Appointment and Queue Management application.

Analyze:

1. Repository structure
2. Framework and version
3. Frontend architecture
4. Backend architecture
5. Database
6. Authentication
7. Authorization/RBAC
8. API structure
9. State management
10. Realtime implementation
11. Notification implementation
12. Payment implementation
13. File/media storage
14. Logging
15. Error handling
16. Validation
17. Security controls
18. Multi-tenant architecture
19. Existing admin panel
20. Existing customer-facing functionality
21. Existing staff/employee functionality
22. Existing appointment functionality
23. Existing queue/waitlist functionality
24. Reporting/analytics
25. Deployment architecture
26. Testing architecture
27. PWA/offline implementation
28. Coding conventions
29. Shared/reusable UI patterns
30. Known technical debt visible from the code

For every major module provide:

- directory
- important files
- responsibility
- dependencies
- APIs
- data models
- security considerations
- implementation quality
- potential reusable ideas

IMPORTANT:

Do not claim something exists unless verified in the code.

Classify findings as:

VERIFIED
PARTIALLY VERIFIED
NOT FOUND
UNKNOWN

Produce these sections:

A. Executive summary
B. Technology stack
C. Architecture diagram in Mermaid
D. Directory/module map
E. Authentication/authorization map
F. Database model summary
G. API inventory
H. UI/application surface inventory
I. Realtime/notifications/payments
J. Security review
K. Code quality observations
L. Existing functionality relevant to salon application
M. Components/concepts that can be reused conceptually
N. Components that should NOT be reused
O. Risks
P. Questions requiring product-owner clarification

Again:

DO NOT CHANGE THE EXISTING PRODUCT.
```

---

# 6. PROMPT 01 — Existing Product vs PDF Gap Analysis

```text
Using:

1. the completed READ-ONLY analysis of the existing application
2. the Online Salon Appointment and Queue-Management System requirements

perform a detailed GAP ANALYSIS.

Do not modify code.

Create a matrix containing:

Requirement
PDF requirement
Existing product capability
Status
Reusable concept
New implementation required
Dependency
Risk
Priority

Use these statuses:

EXISTS
PARTIAL
MISSING
NOT APPLICABLE

Analyze at minimum:

Customer PWA
Salon dashboard
Staff PWA
Platform admin
Multi-tenancy
Locations
Services
Service duration
Staff
Staff skills
Staff shifts
Staff breaks
Resources/chairs
Appointment booking
Slot availability
Temporary booking hold
Concurrency prevention
Walk-in queue
Virtual queue
Queue states
Queue dispatch
ETA range
ETA recalculation
Realtime updates
Remote waiting
Check-in
QR check-in
Kiosk
Cancellation
Rescheduling
Cancellation policy
Deposits
Prepayment
Card-on-file
No-show handling
Appointment waitlist
Cancellation refill
SMS
Email
Push notifications
Payment integration
Audit logging
Offline staff operation
Analytics
Weekend analytics
Staff utilization
ETA accuracy analytics
Platform subscriptions
Feature flags
Provider/webhook health
Privacy controls
RBAC
Tenant isolation
Rate limiting
Observability
Backups/recovery

Then produce:

1. Existing functionality we should retain untouched.
2. Functionality that can inspire the new system.
3. Missing modules.
4. Architectural conflicts.
5. Recommended implementation order.
6. Dependency graph.
7. MVP boundary.
8. Later-phase features.

IMPORTANT:

Do not recommend changing the existing application.

All missing functionality must be planned for the NEW application.
```

---

# 7. PROMPT 02 — Design New Application Architecture

```text
Design the architecture for the NEW Salon Appointment and Queue Management application.

Do not modify the existing application.

Base the architecture on the requirements already analyzed.

Use a MODULAR MONOLITH for the MVP.

Design internal modules for:

identity
tenants
locations
staff
services
resources
availability
appointments
queue
dispatch
ETA
realtime
notifications
payments
policies
analytics
admin
audit

Create:

1. System context diagram
2. Container/component diagram
3. Module dependency diagram
4. Database domain model
5. API architecture
6. Realtime architecture
7. Background-job/event architecture
8. Authentication architecture
9. Authorization model
10. Tenant-isolation strategy
11. Error-handling architecture
12. Logging architecture
13. Payment abstraction
14. Notification abstraction
15. Deployment architecture
16. Development/staging/production strategy
17. Testing architecture

Important architectural requirements:

- appointments and walk-ins share capacity
- booking confirmation must prevent double booking
- temporary holds must expire
- resources may include staff/chairs/rooms
- queue state is server authoritative
- ETA must be continuously recalculated
- realtime client updates must not become authoritative state
- payment/webhook operations must be idempotent
- all business operations must be tenant scoped

Do not implement features yet.

First produce the complete architecture specification.
```

---

# 8. MODULE 01 — New Project Foundation

```text
Implement ONLY Module 01: New Application Foundation.

Do not modify the existing product.

Create the new application inside the approved isolated directory.

Implement:

- application structure
- module boundaries
- environment configuration
- centralized configuration validation
- database connection
- cache connection if required
- API conventions
- standard response/error format
- request correlation ID
- structured logging
- global error handling
- validation infrastructure
- health endpoint
- readiness endpoint
- authentication interface placeholder
- authorization interface placeholder
- event interface
- notification interface
- payment provider interface
- testing framework
- linting/formatting for NEW app only

Do NOT implement business modules yet.

Deliver:

- created files
- architecture explanation
- setup instructions
- environment variable template
- test results if tests were actually executed
- unresolved dependencies
```

---

# 9. MODULE 02 — Multi-Tenancy, Authentication and RBAC

```text
Implement the Identity, Multi-Tenancy and Authorization module.

Entities/concepts:

TENANT
USER
ROLE
PERMISSION
USER_TENANT
USER_LOCATION
SESSION
AUDIT_LOG

Required roles should initially support:

PLATFORM_ADMIN
SALON_OWNER
SALON_MANAGER
RECEPTIONIST
STAFF

Customer authentication should be separated from salon employee authentication where appropriate.

Requirements:

- tenant isolation
- location-level permissions
- role-based authorization
- authenticated user context
- secure sessions/tokens
- owner/admin MFA-ready architecture
- customer OTP/passwordless-ready abstraction
- session revocation
- audit events
- rate limiting for authentication attempts
- no secrets in logs
- tenant required for every tenant-owned operation

Protect against IDOR.

A user from Salon A must never retrieve data belonging to Salon B by manipulating IDs.

Provide unit and integration tests explicitly attempting cross-tenant access.
```

---

# 10. MODULE 03 — Salon Operations Master Data

```text
Implement salon operational master-data management.

Entities:

TENANT
LOCATION
SERVICE
STAFF
STAFF_LOCATION
STAFF_SERVICE
SHIFT
BREAK
RESOURCE
POLICY

LOCATION should contain:

name
timezone
address
status
operating hours

SERVICE should contain:

name
description
default duration
price
active status
eligible resources if required

STAFF should support:

locations
services/skills
status
availability
working shifts
breaks

RESOURCE examples:

chair
room
equipment

Policies should support future:

cancellation window
deposit requirements
late-arrival grace period
queue grace window
no-show handling

Create:

backend models
validation
services
APIs
authorization
admin UI
tests
audit events

Every record must be tenant scoped.
```

---

# 11. MODULE 04 — Booking and Availability Engine

## 04A — Booking Domain Design

```text
Design the Booking and Availability Engine before coding.

Requirements:

Customer chooses:

location
service
date/time
staff preference:
- specific staff
- any eligible staff

Availability must consider:

staff skills
shift
break
existing appointment
service duration
required resource
resource reservation
staff preference
location
temporary holds

Design:

APPOINTMENT
APPOINTMENT_ITEM
RESOURCE_RESERVATION
BOOKING_HOLD

Define appointment states.

Define concurrency strategy.

Define transactional booking sequence.

Define idempotency strategy.

Define temporary hold expiry.

Define how "Any Staff" is resolved.

Do not implement until the design is internally consistent.
```

## 04B — Booking Backend Implementation

```text
Implement the approved Booking and Availability Engine.

Critical invariant:

TWO USERS MUST NOT BE ABLE TO CONFIRM THE SAME STAFF/RESOURCE CAPACITY.

Booking workflow:

request availability
→ select slot
→ temporary hold
→ optional payment/deposit
→ revalidate availability
→ transactionally reserve capacity
→ confirm appointment
→ send confirmation

Implement idempotency for booking creation.

Expired holds must automatically release capacity.

All authorization and tenant validation must happen server-side.

Provide concurrency tests simulating multiple requests attempting to reserve the same capacity.
```

## 04C — Booking UI

```text
Implement customer appointment booking UI.

Flow:

Choose location
→ Choose service
→ When?
→ Later
→ Available times
→ Staff preference
→ Review
→ Deposit/payment if required
→ Confirmation

Required UX:

loading states
no availability
slot became unavailable
payment failure
network failure
retry
accessible keyboard behaviour
mobile-first responsive layout

Do not expose implementation/database identifiers unnecessarily.
```

---

# 12. MODULE 05 — Virtual Walk-In Queue

```text
Implement the Virtual Walk-In Queue module.

A customer must be able to:

view current estimated wait
join remotely
receive ETA
check status
check in
leave queue

Queue states:

WAITING
APPROACHING
CALLED
CHECKED_IN
IN_SERVICE
COMPLETED

Terminal states:

CANCELLED
EXPIRED
NO_SHOW

Maintain:

QUEUE_ENTRY current state

and append-only:

QUEUE_EVENT history

Every transition must:

- validate permitted previous state
- record timestamp
- record actor
- append QUEUE_EVENT
- trigger ETA recalculation when relevant
- trigger notifications when relevant

Implement configurable grace-period behaviour.

Do not display only "number of people ahead" as the primary customer metric because staff capability, appointments and service duration make simple queue position misleading.
```

---

# 13. MODULE 06 — ETA and Dispatch Engine

```text
Implement ETA Engine V1.

Do NOT use generative AI or opaque machine learning.

The engine must simulate the earliest feasible staff assignment.

Inputs:

queue entries
service requested
staff skills
staff status
current service expected completion
future booked appointments
staff shifts
breaks
staff preference
service duration
resource constraints
check-in status
grace period

Return:

predicted service start
lower-bound ETA
upper-bound ETA
recommended customer arrival time
confidence indicator
model version
calculated timestamp

Example customer representation:

Estimated service:
12:35 - 12:45

Estimated wait:
24 - 34 minutes

Recommended arrival:
12:27

The output should be a RANGE rather than false minute-level precision.

Persist estimates in:

WAIT_ESTIMATE

but never treat an old estimate as authoritative after relevant queue state changes.

Recalculate when:

staff starts service
staff completes service
staff becomes unavailable
staff starts/ends break
appointment changes
walk-in joins
walk-in leaves
customer checks in
customer misses grace period
service duration changes materially

Create unit tests for scheduling edge cases.
```

---

# 14. MODULE 07 — Customer PWA

```text
Build the Customer PWA.

Primary screen should quickly answer:

What services are available?
How long is the wait?
Can I join the queue?
Can I reserve an appointment?

Customer functionality:

salon/location view
services
live estimated waits
appointment availability
join virtual queue
guest/OTP-ready workflow
staff preference
booking
queue status
recommended arrival
check-in
cancel
reschedule
leave queue
payment/deposit
booking history
queue history
notification preferences

Keep friction extremely low.

The user should not be forced to install a native application simply to see live wait information.

Design mobile-first.

Target WCAG 2.2 AA.

Include:

loading
empty
error
offline
stale-ETA
cancelled
called
approaching
checked-in
in-service
completed states.
```

---

# 15. MODULE 08 — Salon Operations Dashboard

```text
Create the Salon Operations Dashboard.

The main screen must combine:

WALK-IN QUEUE
STAFF STATUS
UPCOMING APPOINTMENTS
DELAYS/RISKS

into one operational view.

Example layout:

Saturday - current time
7 waiting
Median ETA

Column 1:
Walk-in Queue

Column 2:
Staff

Column 3:
Upcoming Appointments / Risk

Salon actions:

manual queue add
drag/drop appointment where safe
assign/reassign staff
take next
mark customer arrived
call customer
postpone missed customer
mark staff unavailable
move break
mark appointment late/no-show
manual ETA adjustment with audit reason

The receptionist must have safe override capability.

Every override must be audited.

Do not allow UI actions to bypass server-side capacity or authorization checks.
```

---

# 16. MODULE 09 — Staff PWA

```text
Build the Staff PWA.

The interface should be extremely simple because stylists/barbers should not spend time managing complex software.

Primary actions:

NEXT CUSTOMER
START SERVICE
COMPLETE SERVICE
RUNNING LATE
BREAK
UNAVAILABLE

Show:

today's appointments
assigned queue customers
next customer
expected duration
customer/service notes where permitted

Every start/complete action should update the queue/ETA engine.

Make buttons large and mobile-friendly.

Prevent accidental duplicate actions.

Use idempotency for service-state changes.

Implement limited offline support later through the offline module.
```

---

# 17. MODULE 10 — Realtime Infrastructure

```text
Implement realtime queue and appointment updates.

Use an abstraction supporting:

WebSocket for salon/staff operational screens

and either:

SSE
or appropriate realtime subscription

for customer active queue screens.

Events should include:

QUEUE_JOINED
QUEUE_UPDATED
QUEUE_STATE_CHANGED
ETA_UPDATED
STAFF_STATUS_CHANGED
APPOINTMENT_CREATED
APPOINTMENT_UPDATED
APPOINTMENT_CANCELLED
CUSTOMER_CALLED

Requirements:

reconnection handling
authentication
tenant/location scoping
subscription authorization
heartbeat/connection health
event identifiers
deduplication
fallback polling

Never expose one tenant's events to another tenant.

The realtime channel is transport only.

Clients should fetch authoritative state when necessary.
```

---

# 18. MODULE 11 — Notification Engine

```text
Implement Notification Engine with provider abstraction.

Channels:

EMAIL
SMS
PUSH
future WhatsApp

Events:

appointment confirmed
appointment reminder
appointment changed
appointment cancelled
queue joined
ETA changed significantly
approaching
leave-for-salon
you are next
customer called
opening available from waitlist
payment receipt

Store:

notification type
recipient reference
provider
status
attempt count
provider reference
timestamps
failure reason

Implement retry strategy.

Do not repeatedly send duplicate critical notifications.

Marketing communication consent must be independent from transactional service notifications.
```

---

# 19. MODULE 12 — Payments

```text
Implement a provider-agnostic Payment module.

Supported policy types:

PAY_IN_SALON
DEPOSIT
FULL_PREPAYMENT
CARD_ON_FILE_NO_SHOW_PROTECTION

The application must never store:

raw card number
CVV

Use payment provider tokens/references.

Entities should record:

appointment
amount
currency
provider
processor reference
payment status
refund status
timestamps

Webhook processing must implement:

signature verification
idempotency
replay protection
logging without sensitive data
safe retry behaviour

Create a PaymentProvider interface so another provider can later be added without rewriting appointment logic.
```

---

# 20. MODULE 13 — Cancellation, Rescheduling and Waitlist Refill

```text
Implement cancellation and rescheduling.

Cancellation policy must support configurable:

free cancellation window
fixed fee
percentage fee
deposit forfeiture
no-show charge
manager waiver

Flow:

Cancel request
→ evaluate policy
→ calculate fee/refund
→ process required transaction
→ cancel appointment
→ release staff/resources
→ identify matching waitlist candidates
→ notify candidate
→ create temporary offer
→ if accepted, create replacement booking
→ otherwise offer next candidate

All money calculations and booking releases must be transactional/idempotent where appropriate.

Keep complete audit history.
```

---

# 21. MODULE 14 — QR and Kiosk Check-In

```text
Implement salon QR and kiosk check-in.

Support:

existing appointment check-in
existing queue-entry check-in
new walk-in queue join
ticket/queue lookup

Never expose full customer lists publicly.

Public waiting displays should use:

first name + masked identifier
ticket number
or privacy-safe alias

Security-sensitive customer queue URLs must use opaque unguessable tokens.

Rate-limit anonymous lookups.
```

---

# 22. MODULE 15 — Platform Admin

```text
Build the Platform Administration application.

Support:

salon onboarding
tenant management
locations
subscription state
users
roles
feature flags
support cases
notification failures
payment webhook failures
provider health
audit logs
subscription controls

Platform admins must never casually impersonate salon users.

If support access is necessary:

- require explicit reason
- time-limit the support session
- log the administrator
- log tenant
- log start/end
- visibly indicate impersonation/support mode
```

---

# 23. MODULE 16 — Analytics

```text
Implement operational analytics.

Track:

median in-shop wait
P90 in-shop wait
total queue delay
remote waiting time
ETA median absolute error
ETA range coverage
queue abandonment
appointment no-show
cancellation refill rate
staff utilization
overtime
appointment punctuality
manual queue overrides
booking conversion
queue conversion
notification delivery
weekend throughput

Important:

Separate:

TOTAL WAITING

from

PHYSICAL IN-SALON WAITING.

A virtual queue may move waiting outside the salon without reducing total system delay.

Do not present this as equivalent operational improvement.
```

---

# 24. MODULE 17 — Offline Staff Behaviour

```text
Implement limited offline support for Staff PWA.

Cache:

current day's assigned appointments
recent queue state

Safe offline mutations:

START SERVICE
COMPLETE SERVICE
allowed service notes

Each offline mutation must include:

timestamp
device ID
idempotency key
local mutation ID

On reconnect:

send mutation
→ detect conflict
→ safely reconcile
→ acknowledge

Do NOT permit guaranteed future appointment creation while offline because capacity may already have been reserved online.

Ambiguous conflicts must be escalated to manager/reception rather than silently overwritten.
```

---

# 25. MODULE 18 — Security, Privacy and Audit Hardening

```text
Perform application-wide security hardening.

Verify:

tenant isolation
RBAC
location-level authorization
IDOR prevention
authentication protection
MFA readiness
CSRF protection where applicable
XSS prevention
injection prevention
input validation
output encoding
rate limiting
OTP abuse prevention
bot protection
secure cookies
session expiration
session revocation
security headers
CORS policy
secrets management
dependency vulnerabilities
payment-data isolation
audit logs
PII-safe logging

Implement privacy capabilities supporting:

customer data export
correction
deletion
retention
marketing opt-out
consent history

Never store sensitive credentials in logs.

Audit every privileged administrative action.
```

---

# 26. MODULE 19 — Testing, Observability and Deployment

```text
Prepare the new application for production deployment.

Testing:

unit tests
integration tests
API contract tests
authorization tests
cross-tenant isolation tests
booking concurrency tests
queue transition tests
ETA tests
payment webhook tests
notification tests
realtime tests
end-to-end tests

Performance tests must simulate peak salon demand, especially weekend bursts.

Observability:

structured logs
metrics
traces
booking failures
payment failures
queue lag
ETA error
notification failures
WebSocket connection health
database slow queries

Deployment:

development
staging
production

Use:

automated migrations
backups
point-in-time recovery where supported
feature flags
progressive rollout
health/readiness checks
rollback strategy

Scheduling/ETA algorithm versions should be feature-flagged so new behaviour can be enabled at selected salons before broad rollout.
```

---

# 27. MODULE 20 — Final MVP Audit

```text
Perform a complete MVP readiness review against the Salon Appointment and Queue Management specification.

Do NOT add new features during this review.

For every requirement classify:

PASS
PARTIAL
FAIL
NOT IMPLEMENTED
DEFERRED

Validate:

Customer PWA
Appointment booking
Availability
Booking concurrency
Walk-in queue
ETA
Realtime
Notifications
Salon dashboard
Staff PWA
Check-in
Cancellation
Rescheduling
Payments
Policies
Admin
RBAC
Tenant isolation
Audit
Analytics
Offline behaviour
Security
Accessibility
Performance
Observability
Recovery

For every issue provide:

severity
affected module
reproduction
risk
recommended fix
MVP blocker yes/no

Finally provide:

1. MVP release blockers
2. Post-MVP issues
3. Security blockers
4. Performance blockers
5. Missing tests
6. Technical debt
7. Deployment checklist
8. Pilot-readiness recommendation

Do not modify the existing product during this process.
```

---

# 28. Features to Keep Out of the First Build

Do not let the coding agent add these to the MVP unless explicitly requested:

- Full consumer marketplace
- Payroll
- Full inventory system
- AI receptionist
- Generative AI features
- Full POS replacement
- Native customer iOS/Android apps
- Advanced ML demand forecasting
- Complex commissions
- Enterprise SSO
- Cross-city discovery
- Advanced loyalty/marketing automation
- Multi-region active-active deployment

These belong in later phases after the operational core has been validated.

---

# 29. Recommended Development Dependency

```text
Existing Product Analysis
        ↓
Gap Analysis
        ↓
New Architecture
        ↓
Foundation
        ↓
Tenant/Auth/RBAC
        ↓
Salon Master Data
        ↓
Booking + Availability
        ↓
Virtual Queue
        ↓
ETA / Dispatch
        ↓
Realtime
        ↓
Customer / Salon / Staff UI
        ↓
Notifications
        ↓
Payments + Cancellation
        ↓
Admin
        ↓
Analytics
        ↓
Offline
        ↓
Security / QA / Production Hardening
```

Do **not** start with the customer UI.

The most critical part of this system is the shared capacity model across:

- Appointments
- Staff
- Resources
- Walk-ins
- Service durations

Build the scheduler, booking engine, queue logic and ETA model first, then build the UI on top of stable domain behavior.

---

# 30. Standard Change Boundary Check

Append this block to the bottom of **every module prompt**:

```text
CHANGE BOUNDARY CHECK

Before completing this task:

1. Run/inspect git status.
2. Verify that no pre-existing application file was modified.
3. List every created/modified file.
4. Identify why each file was needed.
5. Confirm all modifications belong exclusively to the new salon application.
6. If an existing-product file was changed accidentally, revert that change before completing the task.

Never report the task complete while unrelated or existing-product modifications remain.
```

---

# 31. Product Strategy Summary

The implementation sequence should follow this principle:

1. Build one accurate operational model of:
   - Staff
   - Services
   - Appointments
   - Walk-ins
   - Service progress
   - Resources

2. Expose that model to customers as:
   - Live estimated wait
   - Appointment reservation
   - Virtual queue joining

3. Move unnecessary physical waiting outside the salon using:
   - Realtime updates
   - Notifications
   - Recommended arrival times

4. Learn actual operating data:
   - Service durations
   - Lateness
   - Arrival patterns
   - Weekend demand
   - Staff utilization

5. Only after sufficient real-world history exists, add:
   - Demand forecasting
   - Staffing recommendations
   - Cross-location balancing
   - More advanced optimization

The defensible product opportunity is not generic booking. It is:

```text
Appointments
+
Walk-ins
+
Live Predicted Wait
+
Remote Waiting
+
Staff-Capacity Optimization
```
