import { NextResponse } from 'next/server';
import { queueService } from '../../../../../modules/queue/service';
import { etaService } from '../../../../../modules/eta/service';
import { realtimeBus } from '../../../../../modules/realtime/bus';
import { formatErrorResponse } from '../../../../../lib/errors';
import { AuthActor } from '../../../../../modules/identity/types';

export async function POST(
  req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const body = await req.json();

    const actor: AuthActor = body.actor || {
      userId: 'user-staff',
      tenantId: body.tenantId,
      role: body.role || 'STAFF',
      locationIds: [body.locationId],
    };

    const updatedEntry = queueService.transitionStatus(
      actor,
      id,
      body.targetState,
      body.reason
    );

    // Recalculate ETAs
    const updatedEtas = etaService.recalculateLocationEtas(
      updatedEntry.tenantId,
      updatedEntry.locationId
    );

    // Broadcast realtime event
    realtimeBus.publish(
      updatedEntry.tenantId,
      updatedEntry.locationId,
      'queue:updated',
      {
        action: 'TRANSITION',
        entry: updatedEntry,
        etas: updatedEtas,
      }
    );

    return NextResponse.json({ success: true, data: updatedEntry });
  } catch (error: any) {
    return NextResponse.json(formatErrorResponse(error), { status: 400 });
  }
}
