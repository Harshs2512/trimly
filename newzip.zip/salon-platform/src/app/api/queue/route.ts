import { NextResponse } from 'next/server';
import { queueService } from '../../../modules/queue/service';
import { etaService } from '../../../modules/eta/service';
import { realtimeBus } from '../../../modules/realtime/bus';
import { formatErrorResponse } from '../../../lib/errors';
import { AuthActor } from '../../../modules/identity/types';

export async function POST(req: Request) {
  try {
    const body = await req.json();
    
    // In production, actor comes from verified session token/cookie
    const actor: AuthActor = body.actor || {
      userId: body.customerId || 'cust-anon',
      tenantId: body.tenantId,
      role: 'CUSTOMER',
      locationIds: [body.locationId],
    };

    const entry = queueService.joinQueue(actor, {
      tenantId: body.tenantId,
      locationId: body.locationId,
      customerId: body.customerId || 'cust-anon',
      customerName: body.customerName,
      customerPhone: body.customerPhone,
      serviceId: body.serviceId,
      preferredStaffId: body.preferredStaffId,
    });

    // Recalculate ETAs for all active walk-ins in location
    const updatedEtas = etaService.recalculateLocationEtas(entry.tenantId, entry.locationId);

    // Broadcast queue update to subscribers
    realtimeBus.publish(entry.tenantId, entry.locationId, 'queue:updated', {
      action: 'JOINED',
      entry,
      etas: updatedEtas,
    });

    return NextResponse.json({ success: true, data: entry }, { status: 201 });
  } catch (error: any) {
    return NextResponse.json(formatErrorResponse(error), { status: 400 });
  }
}

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const tenantId = searchParams.get('tenantId');
    const locationId = searchParams.get('locationId');

    if (!tenantId || !locationId) {
      return NextResponse.json(
        { success: false, error: { code: 'VALIDATION_ERROR', message: 'tenantId and locationId required' } },
        { status: 400 }
      );
    }

    const actor: AuthActor = {
      userId: 'user-query',
      tenantId,
      role: 'CUSTOMER',
      locationIds: [locationId],
    };

    const entries = queueService.getActiveQueueForLocation(actor, locationId);
    const etas = etaService.recalculateLocationEtas(tenantId, locationId);

    return NextResponse.json({ success: true, data: { entries, etas } });
  } catch (error: any) {
    return NextResponse.json(formatErrorResponse(error), { status: 400 });
  }
}
