import { NextResponse } from 'next/server';
import { identityService } from '@/modules/identity/service';
import { bookingService } from '@/modules/booking/service';
import { formatErrorResponse, UnauthorizedError } from '@/lib/errors';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Missing or invalid Authorization header');
    }

    const token = authHeader.substring(7);
    const userContext = identityService.verifyToken(token);

    const { searchParams } = new URL(request.url);
    const locationId = searchParams.get('locationId') || 'loc-a-1';
    const serviceId = searchParams.get('serviceId') || 'srv-haircut';
    const date = searchParams.get('date') || new Date().toISOString().substring(0, 10);
    const staffId = searchParams.get('staffId') || undefined;

    const slots = bookingService.calculateAvailableSlots(userContext, locationId, serviceId, date, staffId);

    return NextResponse.json({
      success: true,
      data: slots,
    });
  } catch (error) {
    const err = formatErrorResponse(error);
    const statusCode = (error as { statusCode?: number }).statusCode || 500;
    return NextResponse.json(err, { status: statusCode });
  }
}
