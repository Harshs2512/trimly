import { NextResponse } from 'next/server';
import { z } from 'zod';
import { identityService } from '@/modules/identity/service';
import { bookingService } from '@/modules/booking/service';
import { formatErrorResponse, UnauthorizedError, ValidationError } from '@/lib/errors';

const holdSchema = z.object({
  locationId: z.string(),
  serviceId: z.string(),
  staffId: z.string(),
  startTime: z.string(),
  endTime: z.string(),
});

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Missing or invalid Authorization header');
    }

    const token = authHeader.substring(7);
    const userContext = identityService.verifyToken(token);

    const body = await request.json();
    const parsed = holdSchema.safeParse(body);
    if (!parsed.success) {
      throw new ValidationError('Invalid hold request payload', parsed.error.format());
    }

    const { locationId, serviceId, staffId, startTime, endTime } = parsed.data;

    const hold = bookingService.acquireHold(
      userContext,
      locationId,
      serviceId,
      staffId,
      startTime,
      endTime
    );

    return NextResponse.json({
      success: true,
      data: hold,
    });
  } catch (error) {
    const err = formatErrorResponse(error);
    const statusCode = (error as { statusCode?: number }).statusCode || 500;
    return NextResponse.json(err, { status: statusCode });
  }
}
