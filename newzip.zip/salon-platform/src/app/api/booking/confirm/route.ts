import { NextResponse } from 'next/server';
import { z } from 'zod';
import { identityService } from '@/modules/identity/service';
import { bookingService } from '@/modules/booking/service';
import { formatErrorResponse, UnauthorizedError, ValidationError } from '@/lib/errors';

const confirmSchema = z.object({
  holdId: z.string(),
  customerName: z.string().min(2),
  customerPhone: z.string().min(7),
  idempotencyKey: z.string().min(10),
});

export async function POST(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Missing or invalid Authorization header');
    }

    const token = authHeader.substring(7);
    const userContext = identityService.verifyToken(token);

    const body = await request.json();
    const parsed = confirmSchema.safeParse(body);
    if (!parsed.success) {
      throw new ValidationError('Invalid confirmation request payload', parsed.error.format());
    }

    const { holdId, customerName, customerPhone, idempotencyKey } = parsed.data;

    const appointment = bookingService.confirmAppointment(
      userContext,
      holdId,
      customerName,
      customerPhone,
      idempotencyKey
    );

    return NextResponse.json({
      success: true,
      data: appointment,
    });
  } catch (error) {
    const err = formatErrorResponse(error);
    const statusCode = (error as { statusCode?: number }).statusCode || 500;
    return NextResponse.json(err, { status: statusCode });
  }
}
