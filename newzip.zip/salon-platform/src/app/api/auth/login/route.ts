import { NextResponse } from 'next/server';
import { z } from 'zod';
import { identityStore } from '@/modules/identity/store';
import { identityService } from '@/modules/identity/service';
import { logAuditEvent } from '@/modules/identity/audit';
import { formatErrorResponse, UnauthorizedError, ValidationError } from '@/lib/errors';
import { createLogger } from '@/lib/logger';

const logger = createLogger('LoginAPI');

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const parsed = loginSchema.safeParse(body);
    if (!parsed.success) {
      throw new ValidationError('Invalid email or password format', parsed.error.format());
    }

    const { email, password } = parsed.data;
    const user = identityStore.getUserByEmail(email);

    // Mock credential check (In production, verify bcrypt hash)
    if (!user || password !== 'password123') {
      logger.warn('Failed login attempt', { email });
      throw new UnauthorizedError('Invalid credentials');
    }

    const token = identityService.generateToken(user);
    const userContext = {
      userId: user.id,
      tenantId: user.tenantId,
      role: user.role,
      locationIds: user.locationIds,
    };

    logAuditEvent(userContext, 'USER_LOGIN_SUCCESS', 'auth/login');

    return NextResponse.json({
      success: true,
      data: {
        token,
        user: {
          id: user.id,
          email: user.email,
          name: user.name,
          role: user.role,
          tenantId: user.tenantId,
          locationIds: user.locationIds,
        },
      },
    });
  } catch (error) {
    const err = formatErrorResponse(error);
    const statusCode = (error as { statusCode?: number }).statusCode || 500;
    return NextResponse.json(err, { status: statusCode });
  }
}
