import { NextResponse } from 'next/server';
import { identityService } from '@/modules/identity/service';
import { formatErrorResponse, UnauthorizedError } from '@/lib/errors';

export async function GET(request: Request) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('Missing or invalid Authorization header');
    }

    const token = authHeader.substring(7);
    const userContext = identityService.verifyToken(token);

    return NextResponse.json({
      success: true,
      data: {
        context: userContext,
      },
    });
  } catch (error) {
    const err = formatErrorResponse(error);
    const statusCode = (error as { statusCode?: number }).statusCode || 401;
    return NextResponse.json(err, { status: statusCode });
  }
}
