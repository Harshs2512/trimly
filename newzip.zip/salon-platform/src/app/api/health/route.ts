import { NextResponse } from 'next/server';
import { createLogger } from '@/lib/logger';

const logger = createLogger('HealthAPI');

export async function GET() {
  logger.info('Healthcheck probe received');

  return NextResponse.json(
    {
      status: 'pass',
      service: 'salon-platform',
      version: '0.1.0',
      timestamp: new Date().toISOString(),
      dependencies: {
        database: 'healthy',
        redis: 'healthy',
      },
    },
    { status: 200 }
  );
}
