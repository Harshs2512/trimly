'use client';

import React, { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function CustomerPortal() {
  const router = useRouter();
  const [selectedLocation, setSelectedLocation] = useState('loc-a-1');
  const [selectedService, setSelectedService] = useState('srv-haircut');
  const [preferredStaff, setPreferredStaff] = useState('staff-sam');
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  const handleJoinQueue = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerName.trim()) {
      setErrorMsg('Please enter your name');
      return;
    }

    setIsSubmitting(true);
    setErrorMsg('');

    try {
      const res = await fetch('/api/queue', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: 'tenant-a-111',
          locationId: selectedLocation,
          customerName,
          customerPhone,
          serviceId: selectedService,
          preferredStaffId: preferredStaff || undefined,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error?.message || 'Failed to join walk-in queue');
      }

      // Navigate to live ticket tracker page
      router.push(`/customer/queue/${data.data.id}`);
    } catch (err: any) {
      setErrorMsg(err.message || 'An error occurred');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-8">
      <div className="text-center space-y-2">
        <h1 className="text-3xl sm:text-4xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 via-indigo-200 to-cyan-400 bg-clip-text text-transparent">
          Downtown Main Barber Shop
        </h1>
        <p className="text-slate-400 text-sm sm:text-base">
          Join our virtual walk-in queue or view real-time estimates
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="glass-panel p-5 text-center space-y-1 border-amber-500/20">
          <div className="text-2xl font-bold text-amber-400">15–25 min</div>
          <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Current Est. Wait</div>
        </div>
        <div className="glass-panel p-5 text-center space-y-1 border-indigo-500/20">
          <div className="text-2xl font-bold text-indigo-400">2 People</div>
          <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Ahead in Queue</div>
        </div>
        <div className="glass-panel p-5 text-center space-y-1 border-emerald-500/20">
          <div className="text-2xl font-bold text-emerald-400">Open Now</div>
          <div className="text-xs text-slate-400 uppercase tracking-wider font-semibold">Salon Status</div>
        </div>
      </div>

      <form onSubmit={handleJoinQueue} className="glass-panel p-6 sm:p-8 space-y-6">
        <h2 className="text-xl font-bold text-slate-100 flex items-center space-x-2">
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400 live-pulse"></span>
          <span>Join Virtual Walk-In Queue</span>
        </h2>

        {errorMsg && (
          <div className="p-3 rounded-lg bg-red-500/20 border border-red-500/40 text-red-300 text-sm">
            {errorMsg}
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Select Service
            </label>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <button
                type="button"
                onClick={() => setSelectedService('srv-haircut')}
                className={`p-4 rounded-xl text-left border transition ${
                  selectedService === 'srv-haircut'
                    ? 'bg-amber-500/10 border-amber-500 text-amber-200'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="font-semibold text-sm sm:text-base">Men&apos;s Classic Haircut</div>
                <div className="text-xs text-slate-400 mt-1">30 Mins • $35.00</div>
              </button>
              <button
                type="button"
                onClick={() => setSelectedService('srv-beard')}
                className={`p-4 rounded-xl text-left border transition ${
                  selectedService === 'srv-beard'
                    ? 'bg-amber-500/10 border-amber-500 text-amber-200'
                    : 'bg-slate-800/40 border-slate-700/60 text-slate-300 hover:border-slate-600'
                }`}
              >
                <div className="font-semibold text-sm sm:text-base">Beard Trim & Sculpt</div>
                <div className="text-xs text-slate-400 mt-1">15 Mins • $20.00</div>
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
              Preferred Stylist / Barber
            </label>
            <select
              value={preferredStaff}
              onChange={(e) => setPreferredStaff(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 text-sm"
            >
              <option value="">Any Available Stylist (Earliest Start)</option>
              <option value="staff-sam">Sam Barber (Senior Stylist)</option>
            </select>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Your Full Name *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. John Doe"
                value={customerName}
                onChange={(e) => setCustomerName(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                Mobile Phone (For SMS Alert)
              </label>
              <input
                type="tel"
                placeholder="e.g. +1 555 123 4567"
                value={customerPhone}
                onChange={(e) => setCustomerPhone(e.target.value)}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-4 py-3 text-slate-200 focus:outline-none focus:border-amber-500 text-sm"
              />
            </div>
          </div>
        </div>

        <button
          type="submit"
          disabled={isSubmitting}
          className="w-full py-4 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-base shadow-lg shadow-amber-500/20 transition disabled:opacity-50"
        >
          {isSubmitting ? 'Joining Queue...' : 'Get Virtual Ticket Now'}
        </button>
      </form>
    </div>
  );
}
