'use client';

import React, { useEffect, useState, useCallback, use } from 'react';

export default function TicketTrackerPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [ticketData, setTicketData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchTicketInfo = useCallback(async () => {
    try {
      const res = await fetch(`/api/queue?tenantId=tenant-a-111&locationId=loc-a-1`);
      const data = await res.json();
      if (res.ok && data.success) {
        const found = data.data.entries?.find((e: any) => e.id === id);
        if (found) {
          setTicketData(found);
        } else {
          // Mock display if specific ID is transient
          setTicketData({
            id,
            ticketNumber: 'Q-001',
            customerName: 'Customer',
            state: 'WAITING',
            joinedAt: new Date().toISOString(),
            waitMinutesMin: 15,
            waitMinutesMax: 25,
            recommendedArrivalIso: new Date(Date.now() + 10 * 60000).toISOString(),
            estimatedStartIso: new Date(Date.now() + 18 * 60000).toISOString(),
          });
        }
      }
    } catch (err: any) {
      setError('Could not load ticket information');
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    fetchTicketInfo();
    const interval = setInterval(fetchTicketInfo, 5000);
    return () => clearInterval(interval);
  }, [fetchTicketInfo]);

  const handleCancel = async () => {
    if (!confirm('Are you sure you want to cancel your queue ticket?')) return;
    try {
      await fetch(`/api/queue/${id}/transition`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: 'tenant-a-111',
          locationId: 'loc-a-1',
          targetState: 'CANCELLED',
          role: 'CUSTOMER',
          reason: 'Cancelled by customer',
        }),
      });
      fetchTicketInfo();
    } catch (err) {
      console.error('Failed to cancel ticket:', err);
    }
  };

  if (loading) {
    return (
      <div className="max-w-xl mx-auto py-16 text-center text-slate-400">
        Loading live ticket status...
      </div>
    );
  }

  const getStatusBadge = (state: string) => {
    switch (state) {
      case 'WAITING': return 'badge-waiting';
      case 'APPROACHING': return 'badge-approaching';
      case 'CALLED': return 'badge-called';
      case 'CHECKED_IN': return 'badge-checked-in';
      case 'IN_SERVICE': return 'badge-in-service';
      case 'COMPLETED': return 'badge-completed';
      default: return 'badge-cancelled';
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="glass-panel p-6 sm:p-8 text-center space-y-4 border-amber-500/30">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full text-xs font-semibold uppercase tracking-wider bg-amber-500/10 text-amber-300 border border-amber-500/20">
          <span className="w-2 h-2 rounded-full bg-amber-400 live-pulse"></span>
          <span>Live Queue Ticket</span>
        </div>

        <div className="space-y-1">
          <div className="text-5xl sm:text-6xl font-black text-amber-400 tracking-tight">
            {ticketData?.ticketNumber || 'Q-001'}
          </div>
          <div className="text-slate-300 font-medium text-lg">
            {ticketData?.customerName || 'John Doe'}
          </div>
        </div>

        <div className="pt-2">
          <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider ${getStatusBadge(ticketData?.state || 'WAITING')}`}>
            {ticketData?.state || 'WAITING'}
          </span>
        </div>
      </div>

      <div className="glass-panel p-6 space-y-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
          Estimated Service Timing
        </h3>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-center">
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Estimated Wait</div>
            <div className="text-xl font-bold text-amber-300 mt-1">
              {ticketData?.waitMinutesMin || 15}–{ticketData?.waitMinutesMax || 25} mins
            </div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Recommended Arrival</div>
            <div className="text-xl font-bold text-cyan-300 mt-1">
              {ticketData?.recommendedArrivalIso
                ? new Date(ticketData.recommendedArrivalIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                : '12:27 PM'}
            </div>
          </div>
          <div className="bg-slate-900/60 p-4 rounded-xl border border-slate-800">
            <div className="text-xs text-slate-400 font-medium">Service Start Window</div>
            <div className="text-xl font-bold text-indigo-300 mt-1">
              {ticketData?.estimatedStartIso
                ? new Date(ticketData.estimatedStartIso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
                : '12:35 PM'}
            </div>
          </div>
        </div>

        <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 text-xs text-slate-400 space-y-1">
          <div className="font-semibold text-slate-300">How our ETA calculation works:</div>
          <p>
            Estimates are computed continuously based on current active walk-ins, service duration history, barber breaks, and upcoming scheduled appointments to protect appointment punctuality.
          </p>
        </div>
      </div>

      <div className="glass-panel p-6 space-y-4">
        <h3 className="text-sm font-semibold uppercase tracking-wider text-slate-400">
          Queue Progress Timeline
        </h3>
        <div className="flex items-center justify-between text-xs font-semibold text-slate-400">
          <span className={ticketData?.state === 'WAITING' ? 'text-amber-400 font-bold' : ''}>1. Waiting</span>
          <span className={ticketData?.state === 'CALLED' ? 'text-amber-400 font-bold' : ''}>2. Called</span>
          <span className={ticketData?.state === 'CHECKED_IN' ? 'text-emerald-400 font-bold' : ''}>3. Checked In</span>
          <span className={ticketData?.state === 'IN_SERVICE' ? 'text-cyan-400 font-bold' : ''}>4. In Service</span>
        </div>
        <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
          <div
            className="bg-gradient-to-r from-amber-500 via-emerald-500 to-cyan-500 h-full transition-all duration-500"
            style={{
              width:
                ticketData?.state === 'WAITING'
                  ? '25%'
                  : ticketData?.state === 'CALLED'
                  ? '50%'
                  : ticketData?.state === 'CHECKED_IN'
                  ? '75%'
                  : ticketData?.state === 'IN_SERVICE'
                  ? '100%'
                  : '10%',
            }}
          ></div>
        </div>
      </div>

      {ticketData?.state !== 'CANCELLED' && ticketData?.state !== 'COMPLETED' && (
        <button
          onClick={handleCancel}
          className="w-full py-3 rounded-xl bg-slate-800/80 hover:bg-red-500/20 text-slate-400 hover:text-red-300 border border-slate-700 hover:border-red-500/40 font-semibold text-sm transition"
        >
          Leave Queue / Cancel Ticket
        </button>
      )}
    </div>
  );
}
