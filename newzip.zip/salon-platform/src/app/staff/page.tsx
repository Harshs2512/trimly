'use client';

import React, { useEffect, useState } from 'react';

export default function StaffPwaPage() {
  const [staffStatus, setStaffStatus] = useState<'AVAILABLE' | 'ON_BREAK' | 'OFF_DUTY'>('AVAILABLE');
  const [activeQueue, setActiveQueue] = useState<any[]>([]);

  const fetchStaffData = async () => {
    try {
      const res = await fetch('/api/queue?tenantId=tenant-a-111&locationId=loc-a-1');
      const data = await res.json();
      if (res.ok && data.success) {
        setActiveQueue(data.data.entries || []);
      }
    } catch (err) {
      console.error('Error loading staff queue:', err);
    }
  };

  useEffect(() => {
    fetchStaffData();
    const interval = setInterval(fetchStaffData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAction = async (entryId: string, targetState: string) => {
    try {
      await fetch(`/api/queue/${entryId}/transition`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: 'tenant-a-111',
          locationId: 'loc-a-1',
          targetState,
          role: 'STAFF',
        }),
      });
      fetchStaffData();
    } catch (err) {
      console.error(`Staff transition ${targetState} failed:`, err);
    }
  };

  const inServiceCustomer = activeQueue.find((e) => e.state === 'IN_SERVICE');
  const nextUpCustomer = activeQueue.find((e) => e.state === 'WAITING' || e.state === 'CALLED' || e.state === 'CHECKED_IN');

  return (
    <div className="max-w-md mx-auto space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-extrabold text-slate-100">Sam Barber</h1>
          <p className="text-xs text-slate-400">Senior Stylist • Chair #1</p>
        </div>
        <div className="flex bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs font-semibold">
          <button
            onClick={() => setStaffStatus('AVAILABLE')}
            className={`px-3 py-1.5 rounded-lg transition ${
              staffStatus === 'AVAILABLE' ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            Active
          </button>
          <button
            onClick={() => setStaffStatus('ON_BREAK')}
            className={`px-3 py-1.5 rounded-lg transition ${
              staffStatus === 'ON_BREAK' ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
            }`}
          >
            Break
          </button>
        </div>
      </div>

      {inServiceCustomer ? (
        <div className="glass-panel p-6 space-y-4 border-cyan-500/40">
          <div className="flex items-center justify-between">
            <span className="px-3 py-1 rounded-full text-xs font-bold uppercase bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
              Currently Serving
            </span>
            <span className="text-xs font-semibold text-slate-400 live-pulse">In Chair</span>
          </div>

          <div className="space-y-1">
            <div className="text-3xl font-extrabold text-slate-100">{inServiceCustomer.customerName}</div>
            <div className="text-sm text-cyan-300 font-semibold">
              Ticket #{inServiceCustomer.ticketNumber} • Classic Haircut
            </div>
          </div>

          <button
            onClick={() => handleAction(inServiceCustomer.id, 'COMPLETED')}
            className="w-full py-4 rounded-xl bg-gradient-to-r from-emerald-500 to-emerald-600 hover:from-emerald-400 hover:to-emerald-500 text-slate-950 font-bold text-base shadow-lg shadow-emerald-500/20 transition"
          >
            Complete Service
          </button>
        </div>
      ) : (
        <div className="glass-panel p-6 text-center space-y-2 border-slate-800">
          <div className="text-slate-400 text-sm font-medium">Chair is currently empty</div>
          <div className="text-xs text-slate-500">Ready for next walk-in client</div>
        </div>
      )}

      {nextUpCustomer && (
        <div className="glass-panel p-6 space-y-4 border-amber-500/30">
          <div className="flex items-center justify-between">
            <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Next Client Up
            </span>
            <span className="text-xs font-bold text-amber-400">
              Ticket #{nextUpCustomer.ticketNumber}
            </span>
          </div>

          <div className="space-y-1">
            <div className="text-xl font-bold text-slate-100">{nextUpCustomer.customerName}</div>
            <div className="text-xs text-slate-400">
              Status: <span className="text-amber-300 font-semibold">{nextUpCustomer.state}</span> • Est Wait: {nextUpCustomer.waitMinutesMin || 15}m
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            {nextUpCustomer.state === 'WAITING' && (
              <button
                onClick={() => handleAction(nextUpCustomer.id, 'CALLED')}
                className="py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-sm transition"
              >
                Call Client
              </button>
            )}
            <button
              onClick={() => handleAction(nextUpCustomer.id, 'IN_SERVICE')}
              className="py-3 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-sm transition col-span-2 sm:col-span-1"
            >
              Start Service
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
