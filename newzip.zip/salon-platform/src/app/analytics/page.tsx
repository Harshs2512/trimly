'use client';

import React, { useState } from 'react';
import { BarChart3, Clock, Percent, ShieldCheck, UserX, Download, Sparkles } from 'lucide-react';
import { analyticsEngine } from '../../modules/analytics/service';
import { securityService } from '../../modules/security/service';

export default function AnalyticsDashboardPage() {
  const [customerPhone, setCustomerPhone] = useState('');
  const [privacyMessage, setPrivacyMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER' as const,
    locationIds: ['loc-a-1'],
  };

  const analytics = analyticsEngine.generateOperationalAnalytics(ownerContext, 'loc-a-1', 'TODAY');

  const handleExportData = () => {
    if (!customerPhone.trim()) return;
    setPrivacyMessage(null);
    try {
      const data = securityService.exportCustomerData(ownerContext, customerPhone.trim());
      setPrivacyMessage({
        type: 'success',
        text: `Exported privacy bundle for ${customerPhone} (${data.appointments.length} appointments, ${data.queueHistory.length} queue entries).`,
      });
    } catch (err: any) {
      setPrivacyMessage({ type: 'error', text: err.message || 'Export failed.' });
    }
  };

  const handleAnonymizeData = () => {
    if (!customerPhone.trim()) return;
    setPrivacyMessage(null);
    try {
      const res = securityService.anonymizeCustomerData(ownerContext, customerPhone.trim());
      setPrivacyMessage({ type: 'success', text: res.message });
      setCustomerPhone('');
    } catch (err: any) {
      setPrivacyMessage({ type: 'error', text: err.message || 'Anonymization failed.' });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-8 font-sans selection:bg-cyan-500/30">
      {/* Background Glow */}
      <div className="absolute top-0 left-1/3 w-[500px] h-[500px] bg-cyan-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-xs font-semibold mb-2">
              <BarChart3 className="w-3.5 h-3.5" /> Salon Operational Analytics
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white">
              Performance & Capacity Intelligence
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Real-time delay metrics, capacity utilization, ETA accuracy, and privacy tools
            </p>
          </div>

          <div className="bg-slate-900 border border-slate-800 px-4 py-2 rounded-2xl text-xs font-medium text-slate-300">
            Time Range: <span className="text-cyan-400 font-semibold">Today (Live)</span>
          </div>
        </div>

        {/* Metrics Overview Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-6 mb-10">
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Total Wait</span>
              <Clock className="w-5 h-5 text-cyan-400" />
            </div>
            <div className="text-3xl font-extrabold text-white">
              {analytics.delays.averageTotalWaitMinutes} <span className="text-sm font-normal text-slate-400">min</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">Average wait per customer</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Remote Wait</span>
              <Sparkles className="w-5 h-5 text-indigo-400" />
            </div>
            <div className="text-3xl font-extrabold text-indigo-400">
              {analytics.delays.averageRemoteWaitMinutes} <span className="text-sm font-normal text-slate-400">min</span>
            </div>
            <div className="text-xs text-slate-500 mt-1">70% waiting off-site remotely</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Utilization</span>
              <Percent className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400">
              {analytics.utilization.utilizationPercentage}%
            </div>
            <div className="text-xs text-slate-500 mt-1">Staff chair capacity used</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">ETA Accuracy</span>
              <ShieldCheck className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-3xl font-extrabold text-purple-400">
              {analytics.etaAccuracy.accuracyGrade}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              MAE: {analytics.etaAccuracy.meanAbsoluteErrorMinutes} min
            </div>
          </div>
        </div>

        {/* Analytics Details & Privacy Tools Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Operational Breakdown Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl">
            <h2 className="text-xl font-bold text-white mb-6">Delay Breakdown & Capacity Utilization</h2>

            <div className="space-y-6">
              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-300 font-medium">Remote Waiting (Off-Salon)</span>
                  <span className="text-indigo-400 font-semibold">{analytics.delays.averageRemoteWaitMinutes} min</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-indigo-500 to-cyan-500 rounded-full w-[70%]" />
                </div>
              </div>

              <div>
                <div className="flex justify-between text-sm mb-2">
                  <span className="text-slate-300 font-medium">In-Salon Physical Waiting</span>
                  <span className="text-cyan-400 font-semibold">{analytics.delays.averageInSalonWaitMinutes} min</span>
                </div>
                <div className="w-full h-3 rounded-full bg-slate-950 border border-slate-800 overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-cyan-500 to-emerald-500 rounded-full w-[30%]" />
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 grid grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">Total Revenue</div>
                  <div className="text-2xl font-bold text-white">${analytics.totalRevenue}</div>
                </div>
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800">
                  <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">No-Show Rate</div>
                  <div className="text-2xl font-bold text-rose-400">{analytics.noShowRatePercentage}%</div>
                </div>
              </div>
            </div>
          </div>

          {/* Privacy & Data Compliance Tool Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-2xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center">
                  <ShieldCheck className="w-5 h-5 text-cyan-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Customer Data Privacy Tools</h2>
                  <p className="text-xs text-slate-400">GDPR compliance: Data Export & Anonymization</p>
                </div>
              </div>

              {privacyMessage && (
                <div
                  className={`p-4 rounded-2xl mb-6 text-sm flex items-start gap-3 border ${
                    privacyMessage.type === 'success'
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                      : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
                  }`}
                >
                  {privacyMessage.text}
                </div>
              )}

              <div className="space-y-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Customer Phone Number</label>
                  <input
                    type="text"
                    placeholder="e.g. +15551234"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    className="w-full px-4 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    onClick={handleExportData}
                    disabled={!customerPhone.trim()}
                    className="py-3.5 px-4 rounded-2xl bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 font-semibold text-xs flex items-center justify-center gap-2 border border-slate-700 transition-all"
                  >
                    <Download className="w-4 h-4 text-cyan-400" /> Export Data Bundle
                  </button>

                  <button
                    onClick={handleAnonymizeData}
                    disabled={!customerPhone.trim()}
                    className="py-3.5 px-4 rounded-2xl bg-rose-500/10 hover:bg-rose-500/20 border border-rose-500/20 disabled:opacity-50 text-rose-300 font-semibold text-xs flex items-center justify-center gap-2 transition-all"
                  >
                    <UserX className="w-4 h-4 text-rose-400" /> Anonymize PII
                  </button>
                </div>
              </div>
            </div>

            <div className="mt-8 text-xs text-slate-500">
              Personal customer details are anonymized in accordance with Rule 19 of AGENTS.md.
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
