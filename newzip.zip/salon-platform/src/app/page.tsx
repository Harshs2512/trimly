import React from 'react';
import Link from 'next/link';

export default function HomePage() {
  return (
    <div className="space-y-12 py-4">
      {/* Hero Section */}
      <section className="text-center space-y-4 max-w-4xl mx-auto">
        <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs font-semibold uppercase tracking-wider">
          <span className="w-2 h-2 rounded-full bg-amber-400 animate-ping"></span>
          <span>Enterprise Salon Appointment & Virtual Queue System</span>
        </div>
        <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 via-indigo-200 to-cyan-400 bg-clip-text text-transparent leading-tight">
          Orchestrate Salon Capacity in Real-Time
        </h1>
        <p className="text-slate-400 text-base sm:text-xl max-w-2xl mx-auto leading-relaxed">
          Trimly unifies <span className="text-slate-200 font-medium">scheduled appointments</span>, <span className="text-slate-200 font-medium">live walk-ins</span>, and <span className="text-slate-200 font-medium">virtual queues</span> into a continuously updated ETA and capacity dispatch engine.
        </p>
      </section>

      {/* Core Systems Navigation Grid */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* 1. Customer PWA */}
        <Link
          href="/customer"
          className="glass-panel p-6 space-y-4 hover:border-amber-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/20 flex items-center justify-center text-amber-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            📱
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-amber-400 transition">
              Customer PWA & Queue
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Virtual walk-in queue entry, service selection, live ETA range tracker, remote waiting notifications, and ticket status.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-amber-400 space-x-1">
            <span>Launch Customer Portal</span>
            <span>→</span>
          </div>
        </Link>

        {/* 2. Operations Dashboard */}
        <Link
          href="/dashboard"
          className="glass-panel p-6 space-y-4 hover:border-indigo-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            ⚡
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-indigo-400 transition">
              Salon Operations Board
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Live customer queue dispatch, state transitions (Calling, Checked-In, In-Service), staff assignment, and shift controls.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-indigo-400 space-x-1">
            <span>Open Ops Dashboard</span>
            <span>→</span>
          </div>
        </Link>

        {/* 3. Staff PWA */}
        <Link
          href="/staff"
          className="glass-panel p-6 space-y-4 hover:border-cyan-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-cyan-500/10 border border-cyan-500/20 flex items-center justify-center text-cyan-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            ✂️
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-cyan-400 transition">
              Staff Mobile PWA
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Barber/stylist interface for active client management, service timers, client preference notes, and offline mutation syncing.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-cyan-400 space-x-1">
            <span>Open Staff Portal</span>
            <span>→</span>
          </div>
        </Link>

        {/* 4. Kiosk & QR Check-In */}
        <Link
          href="/kiosk"
          className="glass-panel p-6 space-y-4 hover:border-emerald-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            🔳
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-emerald-400 transition">
              QR & Kiosk Check-In
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Self-service tablet kiosk mode. Supports QR code scanning, 4-digit PIN verification, and phone lookup upon arrival.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-emerald-400 space-x-1">
            <span>Launch Kiosk View</span>
            <span>→</span>
          </div>
        </Link>

        {/* 5. Analytics & Intelligence Engine */}
        <Link
          href="/analytics"
          className="glass-panel p-6 space-y-4 hover:border-purple-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center text-purple-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            📊
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-purple-400 transition">
              Analytics & Forecasting
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Operational delay metrics, staff utilization tracking, ETA accuracy scores, hourly demand forecasting, and shift optimizers.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-purple-400 space-x-1">
            <span>View Intelligence Dashboard</span>
            <span>→</span>
          </div>
        </Link>

        {/* 6. Platform Admin */}
        <Link
          href="/admin"
          className="glass-panel p-6 space-y-4 hover:border-rose-500/50 transition duration-300 group block relative overflow-hidden"
        >
          <div className="w-12 h-12 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 font-bold text-xl group-hover:scale-110 transition duration-300">
            🛡️
          </div>
          <div className="space-y-1">
            <h2 className="text-xl font-bold text-slate-100 group-hover:text-rose-400 transition">
              Platform Admin & Audit
            </h2>
            <p className="text-slate-400 text-sm leading-relaxed">
              Multi-tenant management, salon provisioning, location configuration, strict RBAC policy enforcement, and audit logs.
            </p>
          </div>
          <div className="pt-2 flex items-center text-xs font-semibold text-rose-400 space-x-1">
            <span>Open Platform Admin</span>
            <span>→</span>
          </div>
        </Link>
      </section>

      {/* Invariants & Architecture Showcase */}
      <section className="glass-panel p-6 sm:p-8 space-y-6">
        <h3 className="text-xl font-bold text-slate-100 border-b border-slate-800 pb-3">
          Core Engine Architecture & System Invariants
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="space-y-2">
            <div className="text-amber-400 font-semibold text-sm">🔒 Double-Booking Protection</div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Strict multi-tenant capacity holds prevent two clients from reserving overlapping time slots across appointments & walk-ins.
            </p>
          </div>
          <div className="space-y-2">
            <div className="text-indigo-400 font-semibold text-sm">⏱️ Dynamic ETA Engine</div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Statistical, explainable ETA range calculation continuously updates based on active queue depth, staff velocity, and delays.
            </p>
          </div>
          <div className="space-y-2">
            <div className="text-cyan-400 font-semibold text-sm">📲 Offline Reconnection Sync</div>
            <p className="text-slate-400 text-xs leading-relaxed">
              Staff device network resilience queues local state mutations with device IDs & idempotency keys for conflict-free recovery.
            </p>
          </div>
        </div>
      </section>
    </div>
  );
}
