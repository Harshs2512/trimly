'use client';

import React, { useState } from 'react';
import { ShieldCheck, Plus, Building2, UserPlus, Activity, CheckCircle, AlertTriangle, Lock } from 'lucide-react';
import { platformAdminService } from '../../modules/admin/service';

export default function PlatformAdminPortal() {
  const [salonName, setSalonName] = useState('');
  const [domain, setDomain] = useState('');
  const [ownerName, setOwnerName] = useState('');
  const [ownerEmail, setOwnerEmail] = useState('');
  const [initialLocationName, setInitialLocationName] = useState('');
  const [initialLocationAddress, setInitialLocationAddress] = useState('');

  const [provisionMessage, setProvisionMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [provisionedTenant, setProvisionedTenant] = useState<any>(null);

  const platformAdminActor = {
    userId: 'user-admin-root',
    tenantId: 'platform-root',
    role: 'PLATFORM_ADMIN' as const,
    locationIds: ['*'],
  };

  const health = platformAdminService.getPlatformHealth(platformAdminActor);

  const handleProvision = (e: React.FormEvent) => {
    e.preventDefault();
    setProvisionMessage(null);

    try {
      const result = platformAdminService.provisionTenant(platformAdminActor, {
        salonName,
        domain,
        ownerEmail,
        ownerName,
        ownerPhone: '+15550000',
        initialLocationName,
        initialLocationAddress,
      });

      setProvisionedTenant(result);
      setProvisionMessage({
        type: 'success',
        text: `Tenant '${salonName}' provisioned successfully with Tenant ID ${result.tenantId}!`,
      });

      // Clear Form
      setSalonName('');
      setDomain('');
      setOwnerName('');
      setOwnerEmail('');
      setInitialLocationName('');
      setInitialLocationAddress('');
    } catch (err: any) {
      setProvisionMessage({
        type: 'error',
        text: err.message || 'Provisioning failed.',
      });
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-8 font-sans selection:bg-purple-500/30">
      {/* Background Glow */}
      <div className="absolute top-0 right-1/4 w-[500px] h-[500px] bg-purple-600/10 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-6xl mx-auto relative z-10">
        {/* Header */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-8 pb-6 border-b border-slate-800">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold mb-2">
              <ShieldCheck className="w-3.5 h-3.5" /> Platform Admin Portal
            </div>
            <h1 className="text-3xl font-extrabold tracking-tight text-white">
              Tenant Provisioning & System Health
            </h1>
            <p className="text-sm text-slate-400 mt-1">
              Onboard new salons, manage platform subscriptions, and monitor platform status
            </p>
          </div>

          <div className="flex items-center gap-2 bg-slate-900 border border-slate-800 px-4 py-2 rounded-2xl text-xs font-medium text-slate-300">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse" /> System Status: HEALTHY
          </div>
        </div>

        {/* Health Metrics Summary Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Total Tenants</span>
              <Building2 className="w-5 h-5 text-purple-400" />
            </div>
            <div className="text-3xl font-extrabold text-white">{health.totalTenants}</div>
            <div className="text-xs text-slate-500 mt-1">Provisioned salons</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Active Status</span>
              <CheckCircle className="w-5 h-5 text-emerald-400" />
            </div>
            <div className="text-3xl font-extrabold text-emerald-400">{health.activeTenants}</div>
            <div className="text-xs text-slate-500 mt-1">Live operational tenants</div>
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 backdrop-blur-xl">
            <div className="flex items-center justify-between mb-2">
              <span className="text-xs text-slate-400 font-medium uppercase tracking-wider">Suspended</span>
              <AlertTriangle className="w-5 h-5 text-amber-400" />
            </div>
            <div className="text-3xl font-extrabold text-slate-200">{health.suspendedTenants}</div>
            <div className="text-xs text-slate-500 mt-1">Inactive or past due</div>
          </div>
        </div>

        {/* Main Grid: Provisioning Wizard & Managed Tenants */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Provisioning Wizard Card */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-10 h-10 rounded-2xl bg-purple-500/10 border border-purple-500/20 flex items-center justify-center">
                <Plus className="w-5 h-5 text-purple-400" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-white">Provision New Salon</h2>
                <p className="text-xs text-slate-400">Setup tenant, owner account & main location</p>
              </div>
            </div>

            {provisionMessage && (
              <div
                className={`p-4 rounded-2xl mb-6 text-sm flex items-start gap-3 border ${
                  provisionMessage.type === 'success'
                    ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                    : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
                }`}
              >
                {provisionMessage.text}
              </div>
            )}

            <form onSubmit={handleProvision} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Salon Name</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Metro Barber Lounge"
                  value={salonName}
                  onChange={(e) => setSalonName(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Custom Domain (Optional)</label>
                <input
                  type="text"
                  placeholder="e.g. metrobarber.trimly.app"
                  value={domain}
                  onChange={(e) => setDomain(e.target.value)}
                  className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Owner Name</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Marcus Vance"
                    value={ownerName}
                    onChange={(e) => setOwnerName(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Owner Email</label>
                  <input
                    type="email"
                    required
                    placeholder="owner@metrobarber.com"
                    value={ownerEmail}
                    onChange={(e) => setOwnerEmail(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Initial Location</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Downtown Main Branch"
                    value={initialLocationName}
                    onChange={(e) => setInitialLocationName(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
                <div>
                  <label className="block text-xs font-semibold uppercase text-slate-400 mb-1.5">Location Address</label>
                  <input
                    type="text"
                    required
                    placeholder="500 Main Street"
                    value={initialLocationAddress}
                    onChange={(e) => setInitialLocationAddress(e.target.value)}
                    className="w-full px-4 py-3 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 text-sm focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-4 rounded-2xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-sm shadow-xl shadow-purple-600/30 transition-all mt-4"
              >
                Provision Salon Tenant
              </button>
            </form>
          </div>

          {/* Tenant Status Management */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-8 backdrop-blur-xl flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-10 h-10 rounded-2xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center">
                  <Activity className="w-5 h-5 text-indigo-400" />
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">Active Tenants & RBAC</h2>
                  <p className="text-xs text-slate-400">Multi-tenant isolation & status control</p>
                </div>
              </div>

              {/* Seeded Tenant List */}
              <div className="space-y-4">
                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white text-sm">Downtown Barber Shop</div>
                    <div className="text-xs text-slate-500">ID: tenant-a-111 • Plan: GROWTH</div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                    ACTIVE
                  </span>
                </div>

                <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center justify-between">
                  <div>
                    <div className="font-semibold text-white text-sm">Elite Hair Salon</div>
                    <div className="text-xs text-slate-500">ID: tenant-b-222 • Plan: STARTER</div>
                  </div>
                  <span className="px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs font-semibold">
                    ACTIVE
                  </span>
                </div>

                {provisionedTenant && (
                  <div className="p-4 rounded-2xl bg-slate-950 border border-purple-500/30 flex items-center justify-between animate-in fade-in">
                    <div>
                      <div className="font-semibold text-white text-sm">Newly Provisioned Tenant</div>
                      <div className="text-xs text-purple-400 font-mono">ID: {provisionedTenant.tenantId}</div>
                    </div>
                    <span className="px-3 py-1 rounded-full bg-purple-500/10 border border-purple-500/20 text-purple-400 text-xs font-semibold">
                      {provisionedTenant.status}
                    </span>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-8 p-4 rounded-2xl bg-slate-950/60 border border-slate-800 flex items-center gap-3 text-xs text-slate-400">
              <Lock className="w-4 h-4 text-purple-400 shrink-0" />
              <span>Strict Role-Based Access Control enforced. Non-PLATFORM_ADMIN users are forbidden from accessing tenant provisioning APIs.</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
