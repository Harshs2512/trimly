'use client';

import React, { useState } from 'react';
import { QrCode, Hash, CheckCircle2, AlertCircle, Sparkles, ArrowLeft, RefreshCw, UserCheck } from 'lucide-react';
import { checkInService } from '../../modules/checkin/service';

export default function KioskCheckInPage() {
  const [activeTab, setActiveTab] = useState<'pin' | 'qr'>('pin');
  const [pin, setPin] = useState('');
  const [qrCodeData, setQrCodeData] = useState('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error'; text: string } | null>(null);
  const [checkInResult, setCheckInResult] = useState<any>(null);
  const [isProcessing, setIsProcessing] = useState(false);

  const handleKeyPress = (digit: string) => {
    if (pin.length < 4) {
      setPin((prev) => prev + digit);
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
  };

  const handleClear = () => {
    setPin('');
    setStatusMessage(null);
    setCheckInResult(null);
  };

  const handlePinSubmit = () => {
    if (pin.length !== 4) {
      setStatusMessage({ type: 'error', text: 'Please enter a complete 4-digit PIN code.' });
      return;
    }

    setIsProcessing(true);
    setStatusMessage(null);

    try {
      // Process PIN Check-In
      const res = checkInService.checkInViaPin('tenant-a-111', 'loc-a-1', pin);
      setCheckInResult(res);
      setStatusMessage({ type: 'success', text: res.message });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Invalid PIN code. Please verify with reception.' });
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQrSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!qrCodeData.trim()) return;

    setIsProcessing(true);
    setStatusMessage(null);

    try {
      const res = checkInService.checkInViaQr('tenant-a-111', 'loc-a-1', qrCodeData.trim());
      setCheckInResult(res);
      setStatusMessage({ type: 'success', text: res.message });
    } catch (err: any) {
      setStatusMessage({ type: 'error', text: err.message || 'Invalid QR Token.' });
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col items-center justify-center p-4 sm:p-8 font-sans selection:bg-indigo-500/30">
      {/* Background Decorative Blur */}
      <div className="absolute top-1/4 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-indigo-600/10 rounded-full blur-3xl pointer-events-none" />

      {/* Main Kiosk Container */}
      <div className="relative w-full max-w-xl bg-slate-900/80 border border-slate-800 rounded-3xl p-6 sm:p-10 shadow-2xl backdrop-blur-xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5" /> Self-Service Salon Kiosk
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold tracking-tight bg-gradient-to-r from-white via-slate-200 to-slate-400 bg-clip-text text-transparent">
            Welcome to Downtown Barber
          </h1>
          <p className="text-sm text-slate-400 mt-2">
            Check in for your appointment or virtual queue entry
          </p>
        </div>

        {/* Check-In Mode Selector Tabs */}
        {!checkInResult && (
          <div className="flex bg-slate-950/60 p-1.5 rounded-2xl border border-slate-800 mb-8">
            <button
              onClick={() => {
                setActiveTab('pin');
                handleClear();
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium text-sm transition-all ${
                activeTab === 'pin'
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Hash className="w-4 h-4" /> 4-Digit PIN Code
            </button>
            <button
              onClick={() => {
                setActiveTab('qr');
                handleClear();
              }}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-medium text-sm transition-all ${
                activeTab === 'qr'
                  ? 'bg-gradient-to-r from-indigo-600 to-violet-600 text-white shadow-lg shadow-indigo-600/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <QrCode className="w-4 h-4" /> Scan QR Code
            </button>
          </div>
        )}

        {/* Status Alerts */}
        {statusMessage && (
          <div
            className={`p-4 rounded-2xl mb-6 flex items-start gap-3 border text-sm ${
              statusMessage.type === 'success'
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300'
                : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
            }`}
          >
            {statusMessage.type === 'success' ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
            ) : (
              <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            )}
            <div>{statusMessage.text}</div>
          </div>
        )}

        {/* Confirmation Screen */}
        {checkInResult ? (
          <div className="text-center py-6 animate-in fade-in zoom-in-95 duration-200">
            <div className="w-20 h-20 rounded-full bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center mx-auto mb-6">
              <UserCheck className="w-10 h-10 text-emerald-400" />
            </div>
            <h2 className="text-2xl font-bold text-white mb-2">
              Checked In Successfully!
            </h2>
            <p className="text-slate-300 text-lg font-medium mb-6">
              Welcome, <span className="text-emerald-400 font-semibold">{checkInResult.customerName}</span>
            </p>

            {checkInResult.ticketNumber && (
              <div className="bg-slate-950/80 border border-slate-800 rounded-2xl p-4 max-w-xs mx-auto mb-6">
                <div className="text-xs text-slate-500 uppercase tracking-wider mb-1">Queue Ticket</div>
                <div className="text-4xl font-extrabold text-indigo-400 tracking-tight">{checkInResult.ticketNumber}</div>
              </div>
            )}

            <button
              onClick={handleClear}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-medium transition-all"
            >
              <RefreshCw className="w-4 h-4" /> Next Customer
            </button>
          </div>
        ) : activeTab === 'pin' ? (
          /* Keypad Input UI */
          <div className="flex flex-col items-center">
            {/* PIN Display */}
            <div className="flex gap-4 mb-8">
              {[0, 1, 2, 3].map((idx) => (
                <div
                  key={idx}
                  className={`w-14 h-16 rounded-2xl border flex items-center justify-center text-2xl font-bold transition-all ${
                    pin.length > idx
                      ? 'border-indigo-500 bg-indigo-500/10 text-indigo-300 shadow-lg shadow-indigo-500/10'
                      : 'border-slate-800 bg-slate-950/40 text-slate-600'
                  }`}
                >
                  {pin.length > idx ? '•' : ''}
                </div>
              ))}
            </div>

            {/* Keypad Buttons Grid */}
            <div className="grid grid-cols-3 gap-3.5 w-full max-w-xs mb-6">
              {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
                <button
                  key={num}
                  onClick={() => handleKeyPress(num)}
                  className="h-14 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 active:scale-95 text-slate-100 text-xl font-semibold border border-slate-700/50 transition-all flex items-center justify-center"
                >
                  {num}
                </button>
              ))}
              <button
                onClick={handleClear}
                className="h-14 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold border border-slate-800 transition-all"
              >
                Clear
              </button>
              <button
                onClick={() => handleKeyPress('0')}
                className="h-14 rounded-2xl bg-slate-800/80 hover:bg-slate-700/80 active:scale-95 text-slate-100 text-xl font-semibold border border-slate-700/50 transition-all flex items-center justify-center"
              >
                0
              </button>
              <button
                onClick={handleBackspace}
                className="h-14 rounded-2xl bg-slate-900 hover:bg-slate-800 text-slate-400 text-xs font-semibold border border-slate-800 transition-all flex items-center justify-center"
              >
                <ArrowLeft className="w-5 h-5" />
              </button>
            </div>

            {/* Submit Button */}
            <button
              onClick={handlePinSubmit}
              disabled={pin.length !== 4 || isProcessing}
              className="w-full max-w-xs py-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold text-base shadow-xl shadow-indigo-600/30 transition-all"
            >
              {isProcessing ? 'Verifying...' : 'Check In Now'}
            </button>
          </div>
        ) : (
          /* QR Scanner Tab UI */
          <form onSubmit={handleQrSubmit} className="flex flex-col items-center">
            <div className="w-full p-8 border-2 border-dashed border-indigo-500/30 rounded-3xl bg-indigo-500/5 flex flex-col items-center justify-center text-center mb-6">
              <QrCode className="w-16 h-16 text-indigo-400 mb-4 animate-pulse" />
              <p className="text-sm text-slate-300 font-medium mb-1">
                Scan your QR code using the kiosk scanner
              </p>
              <p className="text-xs text-slate-500">
                Or enter QR token data below
              </p>
            </div>

            <input
              type="text"
              placeholder="e.g. qr_tena_qentry_123"
              value={qrCodeData}
              onChange={(e) => setQrCodeData(e.target.value)}
              className="w-full px-4 py-3.5 rounded-2xl bg-slate-950 border border-slate-800 text-slate-100 placeholder:text-slate-600 focus:outline-none focus:border-indigo-500 mb-6 text-sm"
            />

            <button
              type="submit"
              disabled={!qrCodeData.trim() || isProcessing}
              className="w-full py-4 rounded-2xl bg-gradient-to-r from-indigo-600 to-violet-600 hover:from-indigo-500 hover:to-violet-500 disabled:opacity-50 text-white font-semibold text-base shadow-xl shadow-indigo-600/30 transition-all"
            >
              {isProcessing ? 'Verifying QR Token...' : 'Scan & Check In'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
