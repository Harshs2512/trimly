import './globals.css';
import React from 'react';
import Link from 'next/link';

export const metadata = {
  title: 'Trimly Salon Platform',
  description: 'Online Salon Appointment & Virtual Walk-In Queue Management System',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body className="bg-slate-950 text-slate-100 min-h-screen flex flex-col">
        <header className="border-b border-slate-800 bg-slate-900/80 backdrop-blur sticky top-0 z-50">
          <div className="max-w-7xl mx-auto px-4 py-3 flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-tr from-amber-500 to-indigo-500 flex items-center justify-center font-bold text-slate-950 shadow-md">
                T
              </div>
              <span className="font-bold text-lg tracking-tight bg-gradient-to-r from-amber-400 via-indigo-300 to-cyan-400 bg-clip-text text-transparent">
                Trimly Platform
              </span>
            </div>
            <nav className="flex items-center space-x-3 text-xs sm:text-sm font-medium overflow-x-auto py-1">
              <Link
                href="/"
                className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition shrink-0"
              >
                Home
              </Link>
              <Link
                href="/customer"
                className="px-2.5 py-1.5 rounded-lg bg-amber-500/10 hover:bg-amber-500/20 text-amber-300 border border-amber-500/20 transition shrink-0"
              >
                Customer PWA
              </Link>
              <Link
                href="/dashboard"
                className="px-2.5 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-200 border border-indigo-500/30 transition shrink-0"
              >
                Salon Operations
              </Link>
              <Link
                href="/staff"
                className="px-2.5 py-1.5 rounded-lg bg-cyan-600/30 hover:bg-cyan-600/50 text-cyan-200 border border-cyan-500/30 transition shrink-0"
              >
                Staff PWA
              </Link>
              <Link
                href="/kiosk"
                className="px-2.5 py-1.5 rounded-lg bg-emerald-600/30 hover:bg-emerald-600/50 text-emerald-200 border border-emerald-500/30 transition shrink-0"
              >
                Kiosk
              </Link>
              <Link
                href="/analytics"
                className="px-2.5 py-1.5 rounded-lg bg-purple-600/30 hover:bg-purple-600/50 text-purple-200 border border-purple-500/30 transition shrink-0"
              >
                Analytics
              </Link>
              <Link
                href="/admin"
                className="px-2.5 py-1.5 rounded-lg bg-rose-600/30 hover:bg-rose-600/50 text-rose-200 border border-rose-500/30 transition shrink-0"
              >
                Admin
              </Link>
            </nav>
          </div>
        </header>
        <main className="flex-1 max-w-7xl w-full mx-auto p-4 sm:p-6 lg:p-8">
          {children}
        </main>
      </body>
    </html>
  );
}
