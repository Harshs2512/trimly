'use client';

import React, { useEffect, useState } from 'react';

export default function SalonDashboard() {
  const [queueEntries, setQueueEntries] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOperationalData = async () => {
    try {
      const res = await fetch('/api/queue?tenantId=tenant-a-111&locationId=loc-a-1');
      const data = await res.json();
      if (res.ok && data.success) {
        setQueueEntries(data.data.entries || []);
      }
    } catch (err) {
      console.error('Failed to load dashboard data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOperationalData();
    const interval = setInterval(fetchOperationalData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleTransition = async (entryId: string, targetState: string) => {
    try {
      await fetch(`/api/queue/${entryId}/transition`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          tenantId: 'tenant-a-111',
          locationId: 'loc-a-1',
          targetState,
          role: 'SALON_MANAGER',
          reason: `Manager triggered ${targetState}`,
        }),
      });
      fetchOperationalData();
    } catch (err) {
      console.error(`Transition to ${targetState} failed:`, err);
    }
  };

  const getBadgeClass = (state: string) => {
    switch (state) {
      case 'WAITING': return 'badge-waiting';
      case 'APPROACHING': return 'badge-approaching';
      case 'CALLED': return 'badge-called';
      case 'CHECKED_IN': return 'badge-checked-in';
      case 'IN_SERVICE': return 'badge-in-service';
      case 'COMPLETED': return 'badge-completed';
      default: return 'badge-cancelled';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight bg-gradient-to-r from-amber-400 to-indigo-300 bg-clip-text text-transparent">
            Salon Operations Dashboard
          </h1>
          <p className="text-slate-400 text-sm">
            Live combined walk-in queue and scheduled appointments orchestration
          </p>
        </div>
        <div className="flex items-center space-x-3 text-xs font-semibold">
          <span className="px-3 py-1.5 rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 flex items-center space-x-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 live-pulse"></span>
            <span>Realtime Socket Active</span>
          </span>
          <button
            onClick={fetchOperationalData}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition"
          >
            Refresh
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel p-4 border-indigo-500/20">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Active Queue</div>
          <div className="text-2xl font-bold text-indigo-400 mt-1">{queueEntries.length} Walk-Ins</div>
        </div>
        <div className="glass-panel p-4 border-amber-500/20">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Avg Wait Time</div>
          <div className="text-2xl font-bold text-amber-400 mt-1">18 Mins</div>
        </div>
        <div className="glass-panel p-4 border-cyan-500/20">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">In Service</div>
          <div className="text-2xl font-bold text-cyan-400 mt-1">
            {queueEntries.filter((e) => e.state === 'IN_SERVICE').length} Clients
          </div>
        </div>
        <div className="glass-panel p-4 border-emerald-500/20">
          <div className="text-xs text-slate-400 font-semibold uppercase tracking-wider">Staff On Duty</div>
          <div className="text-2xl font-bold text-emerald-400 mt-1">1 Barber</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 glass-panel p-6 space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-bold text-slate-100 flex items-center space-x-2">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-400 live-pulse"></span>
              <span>Live Walk-In Queue ({queueEntries.length})</span>
            </h2>
            <span className="text-xs text-slate-400">Ordered by ETA & Priority</span>
          </div>

          {queueEntries.length === 0 ? (
            <div className="p-8 text-center text-slate-400 text-sm bg-slate-900/40 rounded-xl border border-slate-800">
              No walk-in queue entries currently active.
            </div>
          ) : (
            <div className="space-y-3">
              {queueEntries.map((entry) => (
                <div
                  key={entry.id}
                  className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4 glass-card-hover"
                >
                  <div className="flex items-start space-x-3">
                    <div className="w-12 h-12 rounded-xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center font-bold text-amber-400 text-sm">
                      {entry.ticketNumber}
                    </div>
                    <div>
                      <div className="font-semibold text-slate-100 flex items-center space-x-2">
                        <span>{entry.customerName}</span>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold uppercase ${getBadgeClass(entry.state)}`}>
                          {entry.state}
                        </span>
                      </div>
                      <div className="text-xs text-slate-400 mt-1">
                        Service: {entry.serviceId === 'srv-beard' ? 'Beard Trim' : "Men's Classic Haircut"} • Est: {entry.waitMinutesMin || 15}–{entry.waitMinutesMax || 25}m
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    {entry.state === 'WAITING' && (
                      <button
                        onClick={() => handleTransition(entry.id, 'CALLED')}
                        className="px-3 py-1.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs transition"
                      >
                        Call Customer
                      </button>
                    )}
                    {entry.state === 'CALLED' && (
                      <button
                        onClick={() => handleTransition(entry.id, 'CHECKED_IN')}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition"
                      >
                        Check In
                      </button>
                    )}
                    {(entry.state === 'CHECKED_IN' || entry.state === 'CALLED') && (
                      <button
                        onClick={() => handleTransition(entry.id, 'IN_SERVICE')}
                        className="px-3 py-1.5 rounded-lg bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition"
                      >
                        Start Service
                      </button>
                    )}
                    {entry.state === 'IN_SERVICE' && (
                      <button
                        onClick={() => handleTransition(entry.id, 'COMPLETED')}
                        className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs transition"
                      >
                        Complete Service
                      </button>
                    )}
                    {entry.state !== 'COMPLETED' && entry.state !== 'CANCELLED' && (
                      <button
                        onClick={() => handleTransition(entry.id, 'NO_SHOW')}
                        className="px-2 py-1.5 rounded-lg bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-300 text-xs transition"
                      >
                        No-Show
                      </button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="glass-panel p-6 space-y-4">
          <h2 className="text-lg font-bold text-slate-100">
            Scheduled Appointments Today
          </h2>
          <div className="p-4 rounded-xl bg-slate-900/60 border border-slate-800 space-y-2">
            <div className="flex items-center justify-between text-sm font-semibold text-slate-200">
              <span>John Customer</span>
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                14:00 - 14:30
              </span>
            </div>
            <div className="text-xs text-slate-400">
              Staff: Sam Barber • Classic Haircut
            </div>
          </div>
          <div className="p-4 rounded-xl bg-slate-900/40 border border-slate-800/80 text-xs text-slate-400 space-y-1">
            <div className="font-semibold text-indigo-300">Appointment Capacity Lock</div>
            <p>
              The dispatch engine automatically reserves Sam Barber&apos;s capacity from 14:00 to 14:30, ensuring walk-ins do not cause schedule delays.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
