import { z } from 'zod';

const envSchema = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  PORT: z.string().default('3001'),
  JWT_SECRET: z.string().min(16, 'JWT_SECRET must be at least 16 characters long').default('dev_secret_key_at_least_16_chars_long'),
  SESSION_EXPIRY_SECONDS: z.string().default('86400').transform(val => parseInt(val, 10)),
  DATABASE_URL: z.string().url().default('postgresql://postgres:postgres@localhost:5432/salon_platform'),
  REDIS_URL: z.string().default('redis://localhost:6379'),
  LOG_LEVEL: z.enum(['debug', 'info', 'warn', 'error']).default('info'),
  ENABLE_VIRTUAL_QUEUE: z.string().default('true').transform(val => val === 'true'),
  ENABLE_ETA_ENGINE: z.string().default('true').transform(val => val === 'true'),
  ENABLE_NOTIFICATIONS: z.string().default('true').transform(val => val === 'true'),
});

export type AppConfig = z.infer<typeof envSchema>;

export function parseConfig(env: Record<string, string | undefined> = process.env): AppConfig {
  const result = envSchema.safeParse(env);
  if (!result.success) {
    console.error('❌ Environment configuration validation failed:', result.error.format());
    throw new Error('Invalid environment configuration');
  }
  return result.data;
}

export const config = parseConfig();
