export class BaseError extends Error {
  public readonly statusCode: number;
  public readonly code: string;
  public readonly details?: unknown;

  constructor(message: string, statusCode: number, code: string, details?: unknown) {
    super(message);
    this.name = this.constructor.name;
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    Object.setPrototypeOf(this, new.target.prototype);
  }
}

export class ValidationError extends BaseError {
  constructor(message: string, details?: unknown) {
    super(message, 400, 'VALIDATION_ERROR', details);
  }
}

export class UnauthorizedError extends BaseError {
  constructor(message = 'Authentication required') {
    super(message, 401, 'UNAUTHORIZED');
  }
}

export class ForbiddenError extends BaseError {
  constructor(message = 'Access forbidden for current role or tenant') {
    super(message, 403, 'FORBIDDEN');
  }
}

export class TenantIsolationError extends BaseError {
  constructor(message = 'Cross-tenant resource access violation') {
    super(message, 403, 'TENANT_ISOLATION_VIOLATION');
  }
}

export class AuthorizationError extends BaseError {
  constructor(message = 'Authorization failed') {
    super(message, 403, 'AUTHORIZATION_ERROR');
  }
}

export class NotFoundError extends BaseError {
  constructor(resource = 'Resource') {
    super(`${resource} not found`, 404, 'NOT_FOUND');
  }
}

export class CapacityConcurrencyError extends BaseError {
  constructor(message = 'Selected time slot or staff capacity was just booked by another request') {
    super(message, 409, 'CAPACITY_CONCURRENCY_CONFLICT');
  }
}

export class InvalidQueueTransitionError extends BaseError {
  constructor(message = 'Invalid queue state transition requested') {
    super(message, 422, 'INVALID_QUEUE_TRANSITION');
  }
}

export function formatErrorResponse(error: unknown) {
  if (error instanceof BaseError) {
    return {
      success: false,
      error: {
        code: error.code,
        message: error.message,
        details: error.details,
      },
    };
  }

  const err = error as Error;
  return {
    success: false,
    error: {
      code: 'INTERNAL_SERVER_ERROR',
      message: err.message || 'An unexpected error occurred',
    },
  };
}
