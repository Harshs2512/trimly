export interface DelayMetrics {
  averageTotalWaitMinutes: number;
  averageRemoteWaitMinutes: number;
  averageInSalonWaitMinutes: number;
  sampleCount: number;
}

export interface CapacityUtilizationMetrics {
  totalCapacitySlots: number;
  bookedCapacitySlots: number;
  utilizationPercentage: number;
}

export interface EtaAccuracyMetrics {
  sampleCount: number;
  meanAbsoluteErrorMinutes: number;
  accuracyGrade: 'HIGH' | 'MODERATE' | 'LOW';
}

export interface PseudonymizedCustomerRecord {
  customerHash: string; // Hash of phone/email for privacy preservation
  totalBookings: number;
  totalWalkIns: number;
  completedVisits: number;
  noShowCount: number;
}

export interface SalonOperationalAnalytics {
  tenantId: string;
  locationId: string;
  timeRange: string; // e.g. 'TODAY', 'LAST_7_DAYS'
  delays: DelayMetrics;
  utilization: CapacityUtilizationMetrics;
  etaAccuracy: EtaAccuracyMetrics;
  totalAppointments: number;
  completedAppointments: number;
  cancelledAppointments: number;
  noShowCount: number;
  cancellationRatePercentage: number;
  noShowRatePercentage: number;
  totalRevenue: number;
  generatedAtIso: string;
}
