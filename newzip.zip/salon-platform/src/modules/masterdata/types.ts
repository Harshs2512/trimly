export interface LocationRecord {
  id: string;
  tenantId: string;
  name: string;
  timezone: string; // IANA timezone e.g. 'America/New_York', 'Asia/Kolkata'
  address: string;
  operatingHours: {
    dayOfWeek: number; // 0 = Sunday, 1 = Monday ... 6 = Saturday
    openTime: string;  // HH:mm format
    closeTime: string; // HH:mm format
    isOpen: boolean;
  }[];
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
}

export interface ServiceRecord {
  id: string;
  tenantId: string;
  name: string;
  description: string;
  defaultDurationMin: number; // Service duration in minutes
  price: number;
  active: boolean;
  requiredResourceType?: 'CHAIR' | 'ROOM' | 'SPECIAL_EQUIPMENT';
  createdAt: string;
}

export interface ShiftRecord {
  id: string;
  tenantId: string;
  staffId: string;
  locationId: string;
  dayOfWeek: number;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
}

export interface BreakRecord {
  id: string;
  tenantId: string;
  staffId: string;
  startTime: string; // HH:mm
  endTime: string;   // HH:mm
  label: string;      // e.g. 'Lunch Break'
}

export interface StaffRecord {
  id: string;
  tenantId: string;
  name: string;
  locationIds: string[];
  serviceIds: string[]; // Skills / services eligible to perform
  status: 'AVAILABLE' | 'IN_SERVICE' | 'ON_BREAK' | 'OFF_DUTY';
  shifts: ShiftRecord[];
  breaks: BreakRecord[];
  createdAt: string;
}

export interface ResourceRecord {
  id: string;
  tenantId: string;
  locationId: string;
  name: string;
  type: 'CHAIR' | 'ROOM' | 'SPECIAL_EQUIPMENT';
  status: 'AVAILABLE' | 'IN_USE' | 'MAINTENANCE';
}

export interface PolicyRecord {
  id: string;
  tenantId: string;
  locationId: string;
  cancellationWindowHours: number;
  depositRequired: boolean;
  depositPercentage: number;
  lateArrivalGraceMinutes: number;
  queueGraceMinutes: number;
}
