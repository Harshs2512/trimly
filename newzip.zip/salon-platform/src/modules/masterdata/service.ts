import { identityService } from '../identity/service';
import { UserContext } from '../identity/types';
import { NotFoundError } from '../../lib/errors';
import { masterDataStore } from './store';
import { LocationRecord, ServiceRecord, StaffRecord, PolicyRecord } from './types';

export class MasterDataService {
  public clear(): void {
    masterDataStore.clear();
  }

  public createLocation(actor: UserContext, data: any): LocationRecord {
    return masterDataStore.createLocation(actor, data);
  }

  public createService(actor: UserContext, data: any): ServiceRecord {
    return masterDataStore.createService(actor, data);
  }

  public createStaff(actor: UserContext, data: any): StaffRecord {
    return masterDataStore.createStaff(actor, data);
  }

  /**
   * Retrieves locations for the tenant context.
   */
  public getTenantLocations(actor: UserContext): LocationRecord[] {
    identityService.validateTenantAccess(actor, actor.tenantId);
    return masterDataStore.getLocationsByTenant(actor.tenantId);
  }

  /**
   * Retrieves specific location with tenant isolation check.
   */
  public getLocation(actor: UserContext, locationId: string): LocationRecord {
    identityService.validateTenantAccess(actor, actor.tenantId);
    const location = masterDataStore.getLocationById(locationId);
    if (!location) throw new NotFoundError('Location');
    
    identityService.validateTenantAccess(actor, location.tenantId);
    return location;
  }

  /**
   * Retrieves active services for tenant.
   */
  public getTenantServices(actor: UserContext): ServiceRecord[] {
    identityService.validateTenantAccess(actor, actor.tenantId);
    return masterDataStore.getServicesByTenant(actor.tenantId);
  }

  /**
   * Retrieves staff members eligible for a given location and service.
   */
  public getEligibleStaff(
    actor: UserContext,
    locationId: string,
    serviceId?: string
  ): StaffRecord[] {
    identityService.validateTenantAccess(actor, actor.tenantId);
    const allStaff = masterDataStore.getStaffByTenant(actor.tenantId);

    return allStaff.filter((staff) => {
      const isAssignedLocation = staff.locationIds.includes(locationId);
      const isEligibleService = !serviceId || staff.serviceIds.includes(serviceId);
      return isAssignedLocation && isEligibleService && staff.status !== 'OFF_DUTY';
    });
  }

  /**
   * Retrieves location operational policy.
   */
  public getLocationPolicy(actor: UserContext, locationId: string): PolicyRecord {
    identityService.validateTenantAccess(actor, actor.tenantId);
    const policy = masterDataStore.getPolicyByLocation(actor.tenantId, locationId);
    if (!policy) throw new NotFoundError('Location Policy');
    return policy;
  }
}

export const masterDataService = new MasterDataService();
