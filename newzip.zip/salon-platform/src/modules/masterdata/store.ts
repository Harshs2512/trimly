import {
  LocationRecord,
  ServiceRecord,
  StaffRecord,
  ResourceRecord,
  PolicyRecord,
} from './types';

class MasterDataStore {
  private locations = new Map<string, LocationRecord>();
  private services = new Map<string, ServiceRecord>();
  private staff = new Map<string, StaffRecord>();
  private resources = new Map<string, ResourceRecord>();
  private policies = new Map<string, PolicyRecord>();

  constructor() {
    this.seedDefaults();
  }

  public clear(): void {
    this.locations.clear();
    this.services.clear();
    this.staff.clear();
    this.resources.clear();
    this.policies.clear();
    this.seedDefaults();
  }

  private seedDefaults() {
    // Seed Location for Tenant A
    const locA: LocationRecord = {
      id: 'loc-a-1',
      tenantId: 'tenant-a-111',
      name: 'Downtown Main Barber Shop',
      timezone: 'America/New_York',
      address: '100 Main St, New York, NY',
      operatingHours: Array.from({ length: 7 }, (_, day) => ({
        dayOfWeek: day,
        openTime: '09:00',
        closeTime: '19:00',
        isOpen: day !== 0, // Closed Sunday
      })),
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };
    this.locations.set(locA.id, locA);

    // Seed Services for Tenant A
    const haircut: ServiceRecord = {
      id: 'srv-haircut',
      tenantId: 'tenant-a-111',
      name: "Men's Classic Haircut",
      description: 'Standard haircut and styling',
      defaultDurationMin: 30,
      price: 35.0,
      active: true,
      requiredResourceType: 'CHAIR',
      createdAt: new Date().toISOString(),
    };
    const beardTrim: ServiceRecord = {
      id: 'srv-beard',
      tenantId: 'tenant-a-111',
      name: 'Beard Trim & Sculpt',
      description: 'Beard trimming and hot towel',
      defaultDurationMin: 15,
      price: 20.0,
      active: true,
      requiredResourceType: 'CHAIR',
      createdAt: new Date().toISOString(),
    };
    this.services.set(haircut.id, haircut);
    this.services.set(beardTrim.id, beardTrim);

    // Seed Barber Staff for Tenant A
    const staffSam: StaffRecord = {
      id: 'staff-sam',
      tenantId: 'tenant-a-111',
      name: 'Sam Barber',
      locationIds: ['loc-a-1'],
      serviceIds: ['srv-haircut', 'srv-beard'],
      status: 'AVAILABLE',
      shifts: [
        {
          id: 'shift-sam-1',
          tenantId: 'tenant-a-111',
          staffId: 'staff-sam',
          locationId: 'loc-a-1',
          dayOfWeek: 6, // Saturday
          startTime: '09:00',
          endTime: '17:00',
        },
      ],
      breaks: [
        {
          id: 'break-sam-1',
          tenantId: 'tenant-a-111',
          staffId: 'staff-sam',
          startTime: '13:00',
          endTime: '13:30',
          label: 'Lunch Break',
        },
      ],
      createdAt: new Date().toISOString(),
    };
    this.staff.set(staffSam.id, staffSam);

    // Seed Resource Chair 1
    const chair1: ResourceRecord = {
      id: 'res-chair-1',
      tenantId: 'tenant-a-111',
      locationId: 'loc-a-1',
      name: 'Barber Chair #1',
      type: 'CHAIR',
      status: 'AVAILABLE',
    };
    this.resources.set(chair1.id, chair1);

    // Seed Policy for Tenant A
    const policyA: PolicyRecord = {
      id: 'pol-a-1',
      tenantId: 'tenant-a-111',
      locationId: 'loc-a-1',
      cancellationWindowHours: 24,
      depositRequired: false,
      depositPercentage: 0,
      lateArrivalGraceMinutes: 10,
      queueGraceMinutes: 10,
    };
    this.policies.set(policyA.id, policyA);
  }

  public addLocation(location: LocationRecord): void {
    this.locations.set(location.id, location);
  }

  public createLocation(actor: any, data: any): LocationRecord {
    const loc: LocationRecord = {
      id: data.id || `loc-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      tenantId: actor.tenantId,
      name: data.name,
      timezone: data.timezone || 'UTC',
      address: data.address || '',
      operatingHours: [],
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };
    this.locations.set(loc.id, loc);
    return loc;
  }

  public createService(actor: any, data: any): ServiceRecord {
    const srv: ServiceRecord = {
      id: data.id || `srv-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`,
      tenantId: actor.tenantId,
      name: data.name,
      description: data.description || '',
      defaultDurationMin: data.durationMinutes || 30,
      price: data.priceCents ? data.priceCents / 100 : 35,
      active: true,
      createdAt: new Date().toISOString(),
    };
    this.services.set(srv.id, srv);
    return srv;
  }

  public createStaff(actor: any, data: any): StaffRecord {
    const stf: StaffRecord = {
      id: data.id || data.userId || `staff-${Date.now()}`,
      tenantId: actor.tenantId,
      name: data.name,
      locationIds: data.locationIds || [],
      serviceIds: data.serviceIds || [],
      status: data.isActive ? 'AVAILABLE' : 'OFF_DUTY',
      shifts: [],
      breaks: [],
      createdAt: new Date().toISOString(),
    };
    this.staff.set(stf.id, stf);
    return stf;
  }

  public listStaff(tenantId: string, locationId: string): StaffRecord[] {
    return Array.from(this.staff.values()).filter(
      (s) => s.tenantId === tenantId && s.locationIds.includes(locationId)
    );
  }

  public listServices(tenantId: string): ServiceRecord[] {
    return this.getServicesByTenant(tenantId);
  }

  // Location Methods
  public getLocationsByTenant(tenantId: string): LocationRecord[] {
    return Array.from(this.locations.values()).filter(l => l.tenantId === tenantId);
  }

  public getLocationById(id: string): LocationRecord | undefined {
    return this.locations.get(id);
  }

  // Service Methods
  public getServicesByTenant(tenantId: string): ServiceRecord[] {
    return Array.from(this.services.values()).filter(s => s.tenantId === tenantId && s.active);
  }

  public getServiceById(id: string): ServiceRecord | undefined {
    return this.services.get(id);
  }

  // Staff Methods
  public getStaffByTenant(tenantId: string): StaffRecord[] {
    return Array.from(this.staff.values()).filter(s => s.tenantId === tenantId);
  }

  public getStaffById(id: string): StaffRecord | undefined {
    return this.staff.get(id);
  }

  // Resource Methods
  public getResourcesByTenant(tenantId: string): ResourceRecord[] {
    return Array.from(this.resources.values()).filter(r => r.tenantId === tenantId);
  }

  // Policy Methods
  public getPolicyByLocation(tenantId: string, locationId: string): PolicyRecord | undefined {
    return Array.from(this.policies.values()).find(p => p.tenantId === tenantId && p.locationId === locationId);
  }
}

export const masterDataStore = new MasterDataStore();
