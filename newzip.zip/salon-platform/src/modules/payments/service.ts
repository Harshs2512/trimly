import {
  TokenizedPaymentRequest,
  PaymentResult,
  PaymentProcessorAdapter,
  WebhookPayload,
} from './types';
import { createLogger } from '../../lib/logger';
import { TenantIsolationError } from '../../lib/errors';

const logger = createLogger('PaymentService');

export class MockPaymentProcessorAdapter implements PaymentProcessorAdapter {
  private webhookSecret = 'whsec_test_secret_123';

  async chargeToken(request: TokenizedPaymentRequest): Promise<{ processorReference: string; success: boolean }> {
    // Simulated tokenized processing
    const ref = `ch_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    return { processorReference: ref, success: true };
  }

  verifyWebhookSignature(rawBody: string, signature: string, secret: string): boolean {
    return signature === `sig_${secret}` || signature === 'valid_test_signature';
  }

  async refund(processorReference: string, amount: number): Promise<{ refundReference: string; success: boolean }> {
    const ref = `re_${Date.now()}_${Math.random().toString(36).substr(2, 6)}`;
    return { refundReference: ref, success: true };
  }
}

export class PaymentService {
  public static getInstance(): PaymentService {
    const g = globalThis as any;
    if (!g.__PAYMENT_SERVICE_SINGLETON__) {
      g.__PAYMENT_SERVICE_SINGLETON__ = new PaymentService();
    }
    return g.__PAYMENT_SERVICE_SINGLETON__;
  }

  private processor: PaymentProcessorAdapter;
  private payments = new Map<string, PaymentResult>(); // paymentId -> PaymentResult
  private idempotencyStore = new Map<string, PaymentResult>(); // idempotencyKey -> PaymentResult
  private processedWebhookEvents = new Set<string>();

  constructor(processor?: PaymentProcessorAdapter) {
    this.processor = processor || new MockPaymentProcessorAdapter();
  }

  async processTokenizedPayment(request: TokenizedPaymentRequest): Promise<PaymentResult> {
    // 1. Idempotency Check
    if (this.idempotencyStore.has(request.idempotencyKey)) {
      logger.info('Idempotent payment request returned existing result', {
        idempotencyKey: request.idempotencyKey,
        tenantId: request.tenantId,
      });
      return this.idempotencyStore.get(request.idempotencyKey)!;
    }

    // 2. Policy Enforcement
    if (request.policy === 'PAY_IN_SALON') {
      const payInSalonResult: PaymentResult = {
        paymentId: `pay_in_salon_${Date.now()}`,
        tenantId: request.tenantId,
        appointmentId: request.appointmentId,
        status: 'PENDING',
        processorReference: 'N/A',
        amountCharged: 0,
        currency: request.currency,
        createdAtIso: new Date().toISOString(),
      };
      this.idempotencyStore.set(request.idempotencyKey, payInSalonResult);
      this.payments.set(payInSalonResult.paymentId, payInSalonResult);
      return payInSalonResult;
    }

    // 3. Process via Tokenized Processor
    const chargeResponse = await this.processor.chargeToken(request);

    if (!chargeResponse.success) {
      const failedResult: PaymentResult = {
        paymentId: `pay_failed_${Date.now()}`,
        tenantId: request.tenantId,
        appointmentId: request.appointmentId,
        status: 'FAILED',
        processorReference: chargeResponse.processorReference || 'FAILED',
        amountCharged: 0,
        currency: request.currency,
        createdAtIso: new Date().toISOString(),
      };
      return failedResult;
    }

    const succeededResult: PaymentResult = {
      paymentId: `pay_${Date.now()}_${Math.random().toString(36).substr(2, 5)}`,
      tenantId: request.tenantId,
      appointmentId: request.appointmentId,
      status: 'SUCCEEDED',
      processorReference: chargeResponse.processorReference,
      amountCharged: request.amount,
      currency: request.currency,
      createdAtIso: new Date().toISOString(),
    };

    this.payments.set(succeededResult.paymentId, succeededResult);
    this.idempotencyStore.set(request.idempotencyKey, succeededResult);

    logger.info('Payment charge succeeded', {
      paymentId: succeededResult.paymentId,
      tenantId: request.tenantId,
      appointmentId: request.appointmentId,
      amount: request.amount,
    });

    return succeededResult;
  }

  processWebhook(payload: WebhookPayload, webhookSecret: string): { success: boolean; message: string } {
    // 1. Signature Verification
    const isValid = this.processor.verifyWebhookSignature(JSON.stringify(payload.data), payload.signature, webhookSecret);
    if (!isValid) {
      logger.warn('Invalid webhook signature rejected', {
        webhookId: payload.id,
        tenantId: payload.data.tenantId,
      });
      return { success: false, message: 'Invalid webhook signature' };
    }

    // 2. Duplicate / Replay Protection
    if (this.processedWebhookEvents.has(payload.id)) {
      logger.info('Duplicate webhook event ignored', {
        webhookId: payload.id,
      });
      return { success: true, message: 'Event already processed' };
    }
    this.processedWebhookEvents.add(payload.id);

    // 3. Authoritative Reconciliation
    let found = false;
    for (const [id, payment] of this.payments.entries()) {
      if (payment.processorReference === payload.data.processorReference) {
        payment.status = payload.data.status;
        found = true;
        logger.info('Payment status reconciled via webhook', {
          paymentId: id,
          newStatus: payload.data.status,
        });
        break;
      }
    }

    return { success: true, message: found ? 'Reconciled' : 'Event recorded' };
  }

  async refundPayment(requestingTenantId: string, paymentId: string, amount: number): Promise<PaymentResult> {
    const payment = this.payments.get(paymentId);
    if (!payment) {
      throw new Error(`Payment record ${paymentId} not found`);
    }

    if (requestingTenantId !== payment.tenantId) {
      throw new TenantIsolationError(`Access denied to payment record for tenant ${payment.tenantId}`);
    }

    const refundRes = await this.processor.refund(payment.processorReference, amount);
    if (refundRes.success) {
      payment.status = 'REFUNDED';
      logger.info('Payment refunded successfully', {
        paymentId,
        tenantId: payment.tenantId,
        refundAmount: amount,
      });
    }

    return payment;
  }

  getTenantPayments(requestingTenantId: string, targetTenantId: string): PaymentResult[] {
    if (requestingTenantId !== targetTenantId) {
      throw new TenantIsolationError(`Access denied to payments for tenant ${targetTenantId}`);
    }

    const results: PaymentResult[] = [];
    for (const payment of this.payments.values()) {
      if (payment.tenantId === targetTenantId) {
        results.push(payment);
      }
    }
    return results;
  }

  clear(): void {
    this.payments.clear();
    this.idempotencyStore.clear();
    this.processedWebhookEvents.clear();
  }
}

export const paymentService = PaymentService.getInstance();
