export type PaymentPolicyType =
  | 'PAY_IN_SALON'
  | 'DEPOSIT'
  | 'FULL_PREPAYMENT'
  | 'CARD_ON_FILE_NO_SHOW_PROTECTION';

export interface TokenizedPaymentRequest {
  tenantId: string;
  appointmentId: string;
  amount: number;
  currency: string;
  processorToken: string; // Tokenized reference from Stripe / Razorpay / Square
  policy: PaymentPolicyType;
  idempotencyKey: string;
}

export interface PaymentResult {
  paymentId: string;
  tenantId: string;
  appointmentId: string;
  status: 'SUCCEEDED' | 'PENDING' | 'FAILED' | 'REFUNDED';
  processorReference: string;
  amountCharged: number;
  currency: string;
  createdAtIso: string;
}

export interface WebhookPayload {
  id: string;
  event: string;
  signature: string;
  data: {
    processorReference: string;
    appointmentId: string;
    tenantId: string;
    amount: number;
    status: 'SUCCEEDED' | 'FAILED' | 'REFUNDED';
  };
}

export interface PaymentProcessorAdapter {
  chargeToken(request: TokenizedPaymentRequest): Promise<{ processorReference: string; success: boolean }>;
  verifyWebhookSignature(rawBody: string, signature: string, secret: string): boolean;
  refund(processorReference: string, amount: number): Promise<{ refundReference: string; success: boolean }>;
}
