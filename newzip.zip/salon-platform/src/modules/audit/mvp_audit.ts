import { identityService } from '../identity/service';
import { bookingService } from '../booking/service';
import { queueService } from '../queue/service';
import { paymentService } from '../payments/service';
import { notificationService } from '../notifications/service';
import { securityService } from '../security/service';
import { offlineMutationEngine } from '../offline/service';
import { realtimeBus } from '../realtime/bus';
import { createLogger } from '../../lib/logger';

const logger = createLogger('MvpReadinessAuditor');

export interface AuditCheckResult {
  invariantId: string;
  name: string;
  passed: boolean;
  message: string;
}

export interface MvpAuditReport {
  overallStatus: 'PASSED' | 'BLOCKED';
  totalChecks: number;
  passedChecks: number;
  failedChecks: number;
  checks: AuditCheckResult[];
  auditedAtIso: string;
}

export class MvpReadinessAuditor {
  public static async runAudit(): Promise<MvpAuditReport> {
    const checks: AuditCheckResult[] = [];

    // Check 1: Tenant Isolation
    try {
      identityService.validateTenantAccess(
        { userId: 'u1', tenantId: 'tenant-a', role: 'SALON_OWNER', locationIds: ['loc-a-1'] },
        'tenant-a'
      );
      let caught = false;
      try {
        identityService.validateTenantAccess(
          { userId: 'u1', tenantId: 'tenant-a', role: 'SALON_OWNER', locationIds: ['loc-a-1'] },
          'tenant-b'
        );
      } catch {
        caught = true;
      }
      checks.push({
        invariantId: 'INV_01_TENANT_ISOLATION',
        name: 'Strict Multi-Tenant Isolation',
        passed: caught,
        message: caught ? 'Cross-tenant access correctly blocked' : 'Isolation check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_01_TENANT_ISOLATION', name: 'Strict Multi-Tenant Isolation', passed: false, message: e.message });
    }

    // Check 2: Booking Concurrency & Double Booking Prevention
    try {
      bookingService.clear();
      const actor = { userId: 'u1', tenantId: 'tenant-a-111', role: 'SALON_OWNER' as const, locationIds: ['loc-a-1'] };
      const start = new Date(Date.now() + 3600000).toISOString();
      const end = new Date(Date.now() + 5400000).toISOString();

      const h1 = bookingService.acquireHold(actor, 'loc-a-1', 'srv-haircut', 'staff-sam', start, end);
      let h2Failed = false;
      try {
        bookingService.acquireHold(actor, 'loc-a-1', 'srv-haircut', 'staff-sam', start, end);
      } catch {
        h2Failed = true;
      }
      checks.push({
        invariantId: 'INV_02_BOOKING_CONCURRENCY',
        name: 'Double-Booking Capacity Reservation Prevention',
        passed: h1 && h2Failed,
        message: h1 && h2Failed ? 'Concurrent capacity hold correctly blocked' : 'Capacity check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_02_BOOKING_CONCURRENCY', name: 'Double-Booking Capacity Reservation Prevention', passed: false, message: e.message });
    }

    // Check 3: Queue State Machine Validity
    try {
      queueService.clear();
      const actor = { userId: 'u1', tenantId: 'tenant-a-111', role: 'SALON_OWNER' as const, locationIds: ['loc-a-1'] };
      const entry = queueService.joinQueue(actor, {
        tenantId: 'tenant-a-111',
        locationId: 'loc-a-1',
        customerName: 'Audit Cust',
        customerPhone: '+15550099',
        serviceId: 'srv-haircut',
      });

      let invalidStateCaught = false;
      try {
        queueService.transitionStatus(actor, entry.id, 'COMPLETED', 'Invalid jump');
      } catch {
        invalidStateCaught = true;
      }

      checks.push({
        invariantId: 'INV_03_QUEUE_STATE_MACHINE',
        name: 'Queue State Machine Graph Enforcement',
        passed: invalidStateCaught,
        message: invalidStateCaught ? 'Invalid queue state jump rejected' : 'Queue state check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_03_QUEUE_STATE_MACHINE', name: 'Queue State Machine Graph Enforcement', passed: false, message: e.message });
    }

    // Check 4: Realtime Tenant Scoping
    try {
      let crossTenantLeak = false;
      const unsubscribe = realtimeBus.subscribe(
        { userId: 'u2', tenantId: 'tenant-b-222', role: 'SALON_OWNER', locationIds: ['loc-b-1'] },
        'sub-client-b',
        'loc-b-1',
        () => {
          crossTenantLeak = true;
        }
      );

      realtimeBus.publish('tenant-a-111', 'loc-a-1', 'queue:updated', { test: 1 });

      unsubscribe();

      checks.push({
        invariantId: 'INV_04_REALTIME_SCOPING',
        name: 'Realtime Multi-Tenant Event Scoping',
        passed: !crossTenantLeak,
        message: !crossTenantLeak ? 'Events scoped strictly to tenant channel' : 'Cross-tenant leak detected',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_04_REALTIME_SCOPING', name: 'Realtime Multi-Tenant Event Scoping', passed: false, message: e.message });
    }

    // Check 5: Payment Idempotency & Webhooks
    try {
      paymentService.clear();
      const req = {
        idempotencyKey: 'idem-audit-1',
        tenantId: 'tenant-a-111',
        appointmentId: 'apt-audit-1',
        amount: 50,
        currency: 'USD',
        processorToken: 'tok_test',
        policy: 'FULL_PREPAYMENT' as const,
      };

      const res1 = await paymentService.processTokenizedPayment(req);
      const res2 = await paymentService.processTokenizedPayment(req);

      const passed = res1.paymentId === res2.paymentId && res1.status === 'SUCCEEDED';
      checks.push({
        invariantId: 'INV_05_PAYMENT_IDEMPOTENCY',
        name: 'Tokenized Payment Idempotency',
        passed,
        message: passed ? 'Duplicate payment request returned idempotent result' : 'Payment idempotency check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_05_PAYMENT_IDEMPOTENCY', name: 'Tokenized Payment Idempotency', passed: false, message: e.message });
    }

    // Check 6: Notification Deduplication
    try {
      notificationService.clear();
      const payload = {
        tenantId: 'tenant-a-111',
        recipient: '+15559988',
        channel: 'SMS' as const,
        template: 'APPOINTMENT_CONFIRMED' as const,
        deduplicationKey: 'audit-dedup-1',
        data: { text: 'test' },
      };

      const n1 = await notificationService.dispatchNotification(payload);
      const n2 = await notificationService.dispatchNotification(payload);

      const passed = n1.status === 'SENT' && n2.status === 'DEDUPLICATED';
      checks.push({
        invariantId: 'INV_06_NOTIFICATION_DEDUPLICATION',
        name: 'Notification Cooldown Deduplication',
        passed,
        message: passed ? 'Duplicate notification suppressed within cooldown' : 'Deduplication check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_06_NOTIFICATION_DEDUPLICATION', name: 'Notification Cooldown Deduplication', passed: false, message: e.message });
    }

    // Check 7: Offline Mutation Reconnection
    try {
      offlineMutationEngine.clear();
      queueService.clear();
      const actor = { userId: 'u1', tenantId: 'tenant-a-111', role: 'SALON_OWNER' as const, locationIds: ['loc-a-1'] };
      const q = queueService.joinQueue(actor, {
        tenantId: 'tenant-a-111',
        locationId: 'loc-a-1',
        customerName: 'Offline Cust',
        customerPhone: '+15558877',
        serviceId: 'srv-haircut',
      });

      queueService.transitionStatus(actor, q.id, 'CHECKED_IN', 'Ready');

      const syncRes = offlineMutationEngine.syncOfflineMutations(actor, [
        {
          localMutationId: 'mut-1',
          deviceId: 'dev-1',
          tenantId: 'tenant-a-111',
          locationId: 'loc-a-1',
          operation: 'START_SERVICE',
          targetId: q.id,
          payload: {},
          timestampIso: new Date().toISOString(),
          idempotencyKey: 'idem-mut-1',
        },
      ]);

      const passed = syncRes.appliedCount === 1;
      checks.push({
        invariantId: 'INV_07_OFFLINE_SYNC_SAFETY',
        name: 'Offline Reconnection Sync Safety',
        passed,
        message: passed ? 'Offline mutation applied safely on reconnect' : 'Offline sync check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_07_OFFLINE_SYNC_SAFETY', name: 'Offline Reconnection Sync Safety', passed: false, message: e.message });
    }

    // Check 8: Privacy Anonymization
    try {
      securityService.clear();
      const actor = { userId: 'u1', tenantId: 'tenant-a-111', role: 'SALON_OWNER' as const, locationIds: ['loc-a-1'] };
      const res = securityService.anonymizeCustomerData(actor, '+15558877');

      checks.push({
        invariantId: 'INV_08_PRIVACY_COMPLIANCE',
        name: 'Customer Privacy Export & Anonymization',
        passed: res.success,
        message: res.success ? 'Customer data anonymization verified' : 'Privacy check failed',
      });
    } catch (e: any) {
      checks.push({ invariantId: 'INV_08_PRIVACY_COMPLIANCE', name: 'Customer Privacy Export & Anonymization', passed: false, message: e.message });
    }

    const total = checks.length;
    const passedCount = checks.filter((c) => c.passed).length;
    const failedCount = total - passedCount;
    const overallStatus = failedCount === 0 ? 'PASSED' : 'BLOCKED';

    logger.info('Completed programmatic MVP Readiness Audit', {
      overallStatus,
      totalChecks: total,
      passedChecks: passedCount,
      failedChecks: failedCount,
    });

    return {
      overallStatus,
      totalChecks: total,
      passedChecks: passedCount,
      failedChecks: failedCount,
      checks,
      auditedAtIso: new Date().toISOString(),
    };
  }
}
