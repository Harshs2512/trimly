export type NotificationChannel = 'EMAIL' | 'SMS' | 'PUSH';

export type NotificationTemplate =
  | 'APPOINTMENT_CONFIRMED'
  | 'APPOINTMENT_REMINDER'
  | 'APPOINTMENT_CANCELLED'
  | 'QUEUE_JOINED'
  | 'QUEUE_APPROACHING'
  | 'CUSTOMER_CALLED'
  | 'ETA_UPDATED'
  | 'PAYMENT_RECEIPT'
  | 'WAITLIST_OPENING';

export interface NotificationPayload {
  tenantId: string;
  recipient: string; // Phone or Email or Push token
  channel: NotificationChannel;
  template: NotificationTemplate;
  data: Record<string, string | number>;
  deduplicationKey?: string;
}

export interface NotificationResult {
  notificationId: string;
  tenantId: string;
  channel: NotificationChannel;
  recipient: string;
  template: NotificationTemplate;
  status: 'QUEUED' | 'SENT' | 'FAILED' | 'DEDUPLICATED';
  providerReference?: string;
  sentAtIso: string;
  error?: string;
}

export interface NotificationProviderAdapter {
  send(payload: NotificationPayload): Promise<{ providerReference: string }>;
}
