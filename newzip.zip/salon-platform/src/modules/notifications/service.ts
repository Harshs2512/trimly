import {
  NotificationPayload,
  NotificationResult,
  NotificationProviderAdapter,
} from './types';
import { createLogger } from '../../lib/logger';
import { TenantIsolationError } from '../../lib/errors';

const logger = createLogger('NotificationService');

class MockNotificationProviderAdapter implements NotificationProviderAdapter {
  async send(payload: NotificationPayload): Promise<{ providerReference: string }> {
    const ref = `mock-prov-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`;
    return { providerReference: ref };
  }
}

export class NotificationService {
  public static getInstance(): NotificationService {
    const g = globalThis as any;
    if (!g.__NOTIFICATION_SERVICE_SINGLETON__) {
      g.__NOTIFICATION_SERVICE_SINGLETON__ = new NotificationService();
    }
    return g.__NOTIFICATION_SERVICE_SINGLETON__;
  }

  private provider: NotificationProviderAdapter;
  private logs: NotificationResult[] = [];
  private deduplicationMap = new Map<string, number>(); // deduplicationKey -> timestamp
  private cooldownMs = 60000; // 60s cooldown

  constructor(provider?: NotificationProviderAdapter) {
    this.provider = provider || new MockNotificationProviderAdapter();
  }

  async dispatchNotification(payload: NotificationPayload): Promise<NotificationResult> {
    const now = Date.now();
    const nowIso = new Date(now).toISOString();

    // Check deduplication
    if (payload.deduplicationKey) {
      const lastSent = this.deduplicationMap.get(payload.deduplicationKey);
      if (lastSent && now - lastSent < this.cooldownMs) {
        logger.info('Duplicate notification suppressed', {
          tenantId: payload.tenantId,
          template: payload.template,
          deduplicationKey: payload.deduplicationKey,
        });

        const deduplicatedResult: NotificationResult = {
          notificationId: `notif-dedup-${now}-${Math.random().toString(36).substr(2, 5)}`,
          tenantId: payload.tenantId,
          channel: payload.channel,
          recipient: payload.recipient,
          template: payload.template,
          status: 'DEDUPLICATED',
          sentAtIso: nowIso,
        };

        this.logs.push(deduplicatedResult);
        return deduplicatedResult;
      }
      this.deduplicationMap.set(payload.deduplicationKey, now);
    }

    try {
      const response = await this.provider.send(payload);
      const result: NotificationResult = {
        notificationId: `notif-${now}-${Math.random().toString(36).substr(2, 5)}`,
        tenantId: payload.tenantId,
        channel: payload.channel,
        recipient: payload.recipient,
        template: payload.template,
        status: 'SENT',
        providerReference: response.providerReference,
        sentAtIso: nowIso,
      };

      this.logs.push(result);

      logger.info(`Notification sent via ${payload.channel}`, {
        tenantId: payload.tenantId,
        recipient: payload.recipient,
        template: payload.template,
      });

      return result;
    } catch (err: any) {
      const failedResult: NotificationResult = {
        notificationId: `notif-fail-${now}-${Math.random().toString(36).substr(2, 5)}`,
        tenantId: payload.tenantId,
        channel: payload.channel,
        recipient: payload.recipient,
        template: payload.template,
        status: 'FAILED',
        error: err.message || 'Dispatch failed',
        sentAtIso: nowIso,
      };

      this.logs.push(failedResult);
      return failedResult;
    }
  }

  getTenantNotificationLogs(requestingTenantId: string, targetTenantId: string): NotificationResult[] {
    if (requestingTenantId !== targetTenantId) {
      logger.warn('Cross-tenant notification log access blocked', {
        requestingTenantId,
        targetTenantId,
      });
      throw new TenantIsolationError(`Access denied to tenant notification logs for ${targetTenantId}`);
    }

    return this.logs.filter((log) => log.tenantId === targetTenantId);
  }

  clearLogs(): void {
    this.logs = [];
    this.deduplicationMap.clear();
  }

  clear(): void {
    this.clearLogs();
  }
}

export const notificationService = NotificationService.getInstance();
