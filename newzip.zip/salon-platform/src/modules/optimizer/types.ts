export type StaffingStatus = 'OPTIMAL' | 'UNDERSTAFFED' | 'OVERSTAFFED';

export interface ShiftRecommendation {
  hourStr: string;
  requiredStaffCount: number;
  currentScheduledStaffCount: number;
  status: StaffingStatus;
  actionRecommended: string;
}

export interface StaffingOptimizationReport {
  tenantId: string;
  locationId: string;
  dateStr: string;
  recommendations: ShiftRecommendation[];
  optimalRosterCount: number;
  expectedWaitTimeReductionMin: number;
  generatedAtIso: string;
}
