import { CheckInToken, CheckInResult, CheckInType } from './types';
import { createLogger } from '../../lib/logger';
import { ValidationError, NotFoundError, TenantIsolationError } from '../../lib/errors';
import { queueStore } from '../queue/store';
import { bookingStore } from '../booking/store';
import { realtimeBus } from '../realtime/bus';

const logger = createLogger('CheckInService');

export class CheckInService {
  public static getInstance(): CheckInService {
    const g = globalThis as any;
    if (!g.__CHECKIN_SERVICE_SINGLETON__) {
      g.__CHECKIN_SERVICE_SINGLETON__ = new CheckInService();
    }
    return g.__CHECKIN_SERVICE_SINGLETON__;
  }

  private tokensByQr = new Map<string, CheckInToken>(); // qrCodeData -> CheckInToken
  private tokensByPin = new Map<string, CheckInToken>(); // tenantId:locationId:pin -> CheckInToken

  public generateCheckInToken(
    tenantId: string,
    locationId: string,
    targetId: string,
    targetType: CheckInType
  ): CheckInToken {
    // Generate 4-digit PIN Code
    const pinCode = Math.floor(1000 + Math.random() * 9000).toString();
    const qrCodeData = `qr_${tenantId.substring(0, 4)}_${targetId}_${Date.now()}`;
    const now = Date.now();
    const expiresAtIso = new Date(now + 12 * 3600 * 1000).toISOString(); // 12h validity

    const token: CheckInToken = {
      tokenId: `chktok-${now}-${Math.random().toString(36).substring(2, 6)}`,
      tenantId,
      locationId,
      targetId,
      targetType,
      pinCode,
      qrCodeData,
      expiresAtIso,
      createdAtIso: new Date(now).toISOString(),
    };

    this.tokensByQr.set(qrCodeData, token);
    const pinKey = `${tenantId}:${locationId}:${pinCode}`;
    this.tokensByPin.set(pinKey, token);

    logger.info('Generated check-in QR and PIN token', {
      tenantId,
      locationId,
      targetId,
      targetType,
      pinCode,
    });

    return token;
  }

  public checkInViaQr(tenantId: string, locationId: string, qrCodeData: string): CheckInResult {
    const token = this.tokensByQr.get(qrCodeData);
    if (!token) {
      throw new NotFoundError('Check-in QR Token');
    }

    return this.processCheckInToken(tenantId, locationId, token);
  }

  public checkInViaPin(tenantId: string, locationId: string, pinCode: string): CheckInResult {
    const pinKey = `${tenantId}:${locationId}:${pinCode}`;
    const token = this.tokensByPin.get(pinKey);
    if (!token) {
      throw new ValidationError(`Invalid check-in PIN code: ${pinCode}`);
    }

    return this.processCheckInToken(tenantId, locationId, token);
  }

  private processCheckInToken(tenantId: string, locationId: string, token: CheckInToken): CheckInResult {
    if (token.tenantId !== tenantId) {
      throw new TenantIsolationError(`Check-in token belongs to another tenant.`);
    }

    if (token.locationId !== locationId) {
      throw new ValidationError(`Check-in token is registered for a different location.`);
    }

    if (new Date().toISOString() > token.expiresAtIso) {
      throw new ValidationError(`Check-in token has expired.`);
    }

    const nowIso = new Date().toISOString();
    let customerName = 'Customer';
    let ticketNumber: string | undefined;

    if (token.targetType === 'QUEUE_ENTRY') {
      const entry = queueStore.getById(token.targetId);
      if (!entry) throw new NotFoundError(`Queue entry ${token.targetId}`);

      // Allow transition from WAITING / APPROACHING / CALLED to CHECKED_IN
      if (['WAITING', 'APPROACHING', 'CALLED'].includes(entry.state)) {
        queueStore.transitionState(entry.id, 'CHECKED_IN', 'SYSTEM_KIOSK', 'Customer self-service check-in');
      }
      customerName = entry.customerName;
      ticketNumber = entry.ticketNumber;

      realtimeBus.publish(tenantId, locationId, 'queue:updated', {
        queueEntryId: entry.id,
        newStatus: 'CHECKED_IN',
      });
    } else if (token.targetType === 'APPOINTMENT') {
      const apt = bookingStore.getAppointment(token.targetId);
      if (!apt) throw new NotFoundError(`Appointment ${token.targetId}`);

      apt.status = 'CHECKED_IN';
      customerName = apt.customerName;

      realtimeBus.publish(tenantId, locationId, 'appointment:updated', {
        appointmentId: apt.id,
        newStatus: 'CHECKED_IN',
      });
    }

    logger.info('Check-in completed successfully', {
      tenantId,
      locationId,
      targetId: token.targetId,
      targetType: token.targetType,
      customerName,
    });

    return {
      success: true,
      targetId: token.targetId,
      targetType: token.targetType,
      customerName,
      ticketNumber,
      checkedInAtIso: nowIso,
      message: `Welcome, ${customerName}! You have been checked in successfully.`,
    };
  }

  public clear(): void {
    this.tokensByQr.clear();
    this.tokensByPin.clear();
  }
}

export const checkInService = CheckInService.getInstance();
