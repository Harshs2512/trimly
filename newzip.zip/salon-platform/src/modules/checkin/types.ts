export type CheckInType = 'APPOINTMENT' | 'QUEUE_ENTRY';

export interface CheckInToken {
  tokenId: string;
  tenantId: string;
  locationId: string;
  targetId: string; // appointmentId or queueEntryId
  targetType: CheckInType;
  pinCode: string; // 4-digit PIN
  qrCodeData: string; // Secure token string for QR scanner
  expiresAtIso: string;
  createdAtIso: string;
}

export interface CheckInResult {
  success: boolean;
  targetId: string;
  targetType: CheckInType;
  customerName: string;
  ticketNumber?: string;
  checkedInAtIso: string;
  message: string;
}
