export type DemandRiskLevel = 'LOW' | 'MODERATE' | 'HIGH' | 'CAPACITY_BOTTLENECK';

export interface HourlyDemandForecast {
  hourStr: string; // e.g. '10:00'
  predictedWalkIns: number;
  predictedBookings: number;
  totalPredictedCustomers: number;
  expectedCapacityUtilPercent: number;
  riskLevel: DemandRiskLevel;
}

export interface DemandForecastReport {
  tenantId: string;
  locationId: string;
  targetDateStr: string;
  hourlyForecasts: HourlyDemandForecast[];
  peakHours: string[];
  totalPredictedVolume: number;
  generatedAtIso: string;
}
