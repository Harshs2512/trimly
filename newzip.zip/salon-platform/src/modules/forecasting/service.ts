import {
  DemandForecastReport,
  HourlyDemandForecast,
  DemandRiskLevel,
} from './types';
import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { masterDataService } from '../masterdata/service';
import { createLogger } from '../../lib/logger';

const logger = createLogger('DemandForecastingEngine');

export class DemandForecastingEngine {
  public static getInstance(): DemandForecastingEngine {
    const g = globalThis as any;
    if (!g.__DEMAND_FORECASTING_ENGINE_SINGLETON__) {
      g.__DEMAND_FORECASTING_ENGINE_SINGLETON__ = new DemandForecastingEngine();
    }
    return g.__DEMAND_FORECASTING_ENGINE_SINGLETON__;
  }

  public generateDemandForecast(
    actor: UserContext,
    locationId: string,
    targetDateStr: string
  ): DemandForecastReport {
    identityService.validateTenantAccess(actor, actor.tenantId);
    masterDataService.getLocation(actor, locationId);

    const hours = ['09:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];
    const hourlyForecasts: HourlyDemandForecast[] = [];
    const peakHours: string[] = [];
    let totalPredictedVolume = 0;

    for (let i = 0; i < hours.length; i++) {
      const hourStr = hours[i];
      // Peak hours around 11:00 AM and 3:00 PM
      const isPeak = hourStr === '11:00' || hourStr === '15:00' || hourStr === '16:00';
      const predictedBookings = isPeak ? 4 : 2;
      const predictedWalkIns = isPeak ? 3 : 1;
      const total = predictedBookings + predictedWalkIns;
      totalPredictedVolume += total;

      const util = Math.min(100, Math.round((total / 6) * 100)); // 6 capacity slots per hour
      let riskLevel: DemandRiskLevel = 'LOW';
      if (util >= 100) {
        riskLevel = 'CAPACITY_BOTTLENECK';
        peakHours.push(hourStr);
      } else if (util >= 75) {
        riskLevel = 'HIGH';
        if (!peakHours.includes(hourStr)) peakHours.push(hourStr);
      } else if (util >= 50) {
        riskLevel = 'MODERATE';
      }

      hourlyForecasts.push({
        hourStr,
        predictedWalkIns,
        predictedBookings,
        totalPredictedCustomers: total,
        expectedCapacityUtilPercent: util,
        riskLevel,
      });
    }

    logger.info('Generated demand forecast report', {
      tenantId: actor.tenantId,
      locationId,
      targetDateStr,
      totalPredictedVolume,
      peakHourCount: peakHours.length,
    });

    return {
      tenantId: actor.tenantId,
      locationId,
      targetDateStr,
      hourlyForecasts,
      peakHours,
      totalPredictedVolume,
      generatedAtIso: new Date().toISOString(),
    };
  }
}

export const demandForecastingEngine = DemandForecastingEngine.getInstance();
