import { SystemRole } from './types';

export interface TenantRecord {
  id: string;
  name: string;
  domain?: string;
  subscriptionPlan: 'STARTER' | 'GROWTH' | 'SCALE' | 'ENTERPRISE';
  status: 'ACTIVE' | 'SUSPENDED';
  createdAt: string;
}

export interface UserRecord {
  id: string;
  tenantId: string;
  email: string;
  passwordHash: string;
  name: string;
  role: SystemRole;
  locationIds: string[];
  status: 'ACTIVE' | 'INACTIVE';
  createdAt: string;
}

export interface AuditLogRecord {
  id: string;
  tenantId: string;
  actorId: string;
  action: string;
  resource: string;
  details?: Record<string, unknown>;
  ipAddress?: string;
  timestamp: string;
}

// In-Memory Domain Data Store for Identity & Multi-tenancy (Database Adapter Abstraction)
class IdentityStore {
  private tenants = new Map<string, TenantRecord>();
  private users = new Map<string, UserRecord>();
  private auditLogs: AuditLogRecord[] = [];

  constructor() {
    this.seedDefaults();
  }

  public addTenant(tenant: Partial<TenantRecord> & { id: string; name: string }): TenantRecord {
    const record: TenantRecord = {
      id: tenant.id,
      name: tenant.name,
      domain: tenant.domain,
      subscriptionPlan: tenant.subscriptionPlan || 'STARTER',
      status: tenant.status || 'ACTIVE',
      createdAt: tenant.createdAt || new Date().toISOString(),
    };
    this.tenants.set(record.id, record);
    return record;
  }

  public addUser(user: Partial<UserRecord> & { id: string; tenantId: string; email: string; name: string; role: SystemRole }): UserRecord {
    const record: UserRecord = {
      id: user.id,
      tenantId: user.tenantId,
      email: user.email,
      passwordHash: user.passwordHash || '$2a$10$e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z',
      name: user.name,
      role: user.role,
      locationIds: user.locationIds || [],
      status: user.status || 'ACTIVE',
      createdAt: user.createdAt || new Date().toISOString(),
    };
    this.users.set(record.id, record);
    return record;
  }

  private seedDefaults() {
    // Seed Tenant A (Downtown Barber Shop)
    const tenantA: TenantRecord = {
      id: 'tenant-a-111',
      name: 'Downtown Barber Shop',
      subscriptionPlan: 'GROWTH',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };
    this.tenants.set(tenantA.id, tenantA);

    // Seed Tenant B (Elite Hair Salon)
    const tenantB: TenantRecord = {
      id: 'tenant-b-222',
      name: 'Elite Hair Salon',
      subscriptionPlan: 'STARTER',
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };
    this.tenants.set(tenantB.id, tenantB);

    // Seed Salon Owner for Tenant A
    this.users.set('user-owner-a', {
      id: 'user-owner-a',
      tenantId: 'tenant-a-111',
      email: 'owner@downtownbarber.com',
      passwordHash: '$2a$10$e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z', // Mock hash for 'password123'
      name: 'Alice Owner',
      role: 'SALON_OWNER',
      locationIds: ['loc-a-1'],
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    });

    // Seed Barber Staff for Tenant A
    this.users.set('user-staff-a', {
      id: 'user-staff-a',
      tenantId: 'tenant-a-111',
      email: 'sam@downtownbarber.com',
      passwordHash: '$2a$10$e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z',
      name: 'Sam Barber',
      role: 'STAFF',
      locationIds: ['loc-a-1'],
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    });

    // Seed Owner for Tenant B
    this.users.set('user-owner-b', {
      id: 'user-owner-b',
      tenantId: 'tenant-b-222',
      email: 'owner@elitesalon.com',
      passwordHash: '$2a$10$e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z1Z1Z1Z1Z1e8wY8rX1Z1Z',
      name: 'Bob Owner',
      role: 'SALON_OWNER',
      locationIds: ['loc-b-1'],
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    });
  }

  public getTenant(tenantId: string): TenantRecord | undefined {
    return this.tenants.get(tenantId);
  }

  public getUserByEmail(email: string): UserRecord | undefined {
    return Array.from(this.users.values()).find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public getUserById(userId: string): UserRecord | undefined {
    return this.users.get(userId);
  }

  public addAuditLog(log: AuditLogRecord): void {
    this.auditLogs.push(log);
  }

  public getAuditLogsForTenant(tenantId: string): AuditLogRecord[] {
    return this.auditLogs.filter(l => l.tenantId === tenantId);
  }
}

export const identityStore = new IdentityStore();
