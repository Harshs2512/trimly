import { createLogger } from '../../lib/logger';
import { identityStore, AuditLogRecord } from './store';
import { UserContext } from './types';

const logger = createLogger('AuditModule');

export function logAuditEvent(
  actor: UserContext,
  action: string,
  resource: string,
  details?: Record<string, unknown>,
  ipAddress?: string
): AuditLogRecord {
  const auditRecord: AuditLogRecord = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
    tenantId: actor.tenantId,
    actorId: actor.userId,
    action,
    resource,
    details,
    ipAddress,
    timestamp: new Date().toISOString(),
  };

  identityStore.addAuditLog(auditRecord);
  logger.info(`AUDIT_EVENT: ${action} on ${resource}`, {
    tenantId: actor.tenantId,
    actorId: actor.userId,
    action,
  });

  return auditRecord;
}

export function getAuditLogsForTenant(tenantId: string): AuditLogRecord[] {
  return identityStore.getAuditLogsForTenant(tenantId);
}
