export type SystemRole =
  | 'PLATFORM_ADMIN'
  | 'SALON_OWNER'
  | 'SALON_MANAGER'
  | 'RECEPTIONIST'
  | 'STAFF';

export interface UserContext {
  userId: string;
  tenantId: string;
  role: SystemRole;
  locationIds: string[];
}

export type AuthActor = UserContext | {
  userId: string;
  tenantId: string;
  role: SystemRole | 'CUSTOMER';
  locationIds: string[];
};

export interface SessionInfo {
  sessionId: string;
  userId: string;
  tenantId: string;
  role: SystemRole;
  expiresAt: string;
}

export interface AuthResponse {
  user: {
    id: string;
    email: string;
    name: string;
    role: SystemRole;
    tenantId: string;
  };
  token: string;
}
