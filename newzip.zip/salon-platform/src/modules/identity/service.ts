import { config } from '../../lib/config';
import { UnauthorizedError, ForbiddenError, TenantIsolationError, NotFoundError } from '../../lib/errors';
import { createLogger } from '../../lib/logger';
import { identityStore, UserRecord } from './store';
import { SystemRole, UserContext } from './types';

const logger = createLogger('IdentityService');

// Role hierarchy definition
const ROLE_HIERARCHY: Record<SystemRole, number> = {
  STAFF: 1,
  RECEPTIONIST: 2,
  SALON_MANAGER: 3,
  SALON_OWNER: 4,
  PLATFORM_ADMIN: 5,
};

export class IdentityService {
  /**
   * Generates a signed token string for a user context.
   */
  public generateToken(user: UserRecord): string {
    const payload = {
      userId: user.id,
      tenantId: user.tenantId,
      role: user.role,
      locationIds: user.locationIds,
      issuedAt: Date.now(),
    };
    // Base64Url token encoding for lightweight HMAC/JWT abstraction
    const jsonStr = JSON.stringify(payload);
    const token = Buffer.from(jsonStr).toString('base64url');
    return token;
  }

  /**
   * Verifies and decodes token into UserContext.
   */
  public verifyToken(token: string): UserContext {
    try {
      const jsonStr = Buffer.from(token, 'base64url').toString('utf8');
      const payload = JSON.parse(jsonStr) as UserContext & { issuedAt: number };
      
      const user = identityStore.getUserById(payload.userId);
      if (!user || user.status !== 'ACTIVE') {
        throw new UnauthorizedError('User session is invalid or user is inactive');
      }

      return {
        userId: user.id,
        tenantId: user.tenantId,
        role: user.role,
        locationIds: user.locationIds,
      };
    } catch (err) {
      if (err instanceof UnauthorizedError) throw err;
      throw new UnauthorizedError('Malformed or invalid access token');
    }
  }

  /**
   * Enforces that the requesting actor belongs strictly to the target tenant.
   * Throws TenantIsolationError on cross-tenant access attempt.
   */
  public validateTenantAccess(actorContext: UserContext, targetTenantId: string): void {
    if (actorContext.role === 'PLATFORM_ADMIN') return; // Platform admin bypasses for global admin tasks

    if (actorContext.tenantId !== targetTenantId) {
      logger.warn('Cross-tenant violation detected', {
        actorId: actorContext.userId,
        actorTenant: actorContext.tenantId,
        targetTenant: targetTenantId,
      });
      throw new TenantIsolationError(`Access denied: User from tenant ${actorContext.tenantId} cannot access resources of tenant ${targetTenantId}`);
    }
  }

  /**
   * Enforces role requirements.
   */
  public validateMinimumRole(actorContext: UserContext, requiredRole: SystemRole): void {
    const actorLevel = ROLE_HIERARCHY[actorContext.role] || 0;
    const requiredLevel = ROLE_HIERARCHY[requiredRole] || 0;

    if (actorLevel < requiredLevel) {
      throw new ForbiddenError(`Insufficient privileges: Requires role ${requiredRole} or higher, but actor has ${actorContext.role}`);
    }
  }

  /**
   * Enforces location scoping for staff/receptionists.
   */
  public validateLocationAccess(actorContext: UserContext, targetLocationId: string): void {
    if (actorContext.role === 'PLATFORM_ADMIN' || actorContext.role === 'SALON_OWNER') return;

    if (!actorContext.locationIds.includes(targetLocationId)) {
      throw new ForbiddenError(`Actor is not assigned to location ${targetLocationId}`);
    }
  }
}

export const identityService = new IdentityService();
