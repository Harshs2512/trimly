export interface LocationLoadSummary {
  locationId: string;
  locationName: string;
  address: string;
  activeQueueCount: number;
  averageWaitMinutes: number;
  capacityStatus: 'NORMAL' | 'BUSY' | 'HIGH_BOTTLENECK';
}

export interface LocationRecommendation {
  locationId: string;
  locationName: string;
  address: string;
  estimatedWaitMinutes: number;
  travelTimeMinutes: number;
  netTimeSavingsMinutes: number;
  isRecommended: boolean;
  reason: string;
}

export interface MultiLocationBalancingReport {
  tenantId: string;
  primaryLocationId: string;
  primaryWaitMinutes: number;
  recommendations: LocationRecommendation[];
  generatedAtIso: string;
}
