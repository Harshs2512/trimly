import {
  MultiLocationBalancingReport,
  LocationRecommendation,
} from './types';
import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { masterDataService } from '../masterdata/service';
import { masterDataStore } from '../masterdata/store';
import { queueStore } from '../queue/store';
import { createLogger } from '../../lib/logger';

const logger = createLogger('MultiLocationBalancingEngine');

export class MultiLocationBalancingEngine {
  public static getInstance(): MultiLocationBalancingEngine {
    const g = globalThis as any;
    if (!g.__MULTI_LOCATION_BALANCING_ENGINE_SINGLETON__) {
      g.__MULTI_LOCATION_BALANCING_ENGINE_SINGLETON__ = new MultiLocationBalancingEngine();
    }
    return g.__MULTI_LOCATION_BALANCING_ENGINE_SINGLETON__;
  }

  public recommendNearbyLocations(
    actor: UserContext,
    primaryLocationId: string
  ): MultiLocationBalancingReport {
    identityService.validateTenantAccess(actor, actor.tenantId);
    const primaryLoc = masterDataService.getLocation(actor, primaryLocationId);

    const primaryQueue = queueStore.listByLocation(actor.tenantId, primaryLocationId);
    const primaryActive = primaryQueue.filter((e) => e.state === 'WAITING' || e.state === 'APPROACHING' || e.state === 'CALLED');
    const primaryWaitMinutes = primaryActive.length * 15; // 15 min per queue entry

    const allLocations = masterDataStore.getLocationsByTenant(actor.tenantId);
    const recommendations: LocationRecommendation[] = [];

    for (const loc of allLocations) {
      if (loc.id === primaryLocationId) continue;

      const altQueue = queueStore.listByLocation(actor.tenantId, loc.id);
      const altActive = altQueue.filter((e) => e.state === 'WAITING' || e.state === 'APPROACHING' || e.state === 'CALLED');
      const estimatedWaitMinutes = altActive.length * 15;
      const travelTimeMinutes = 10; // Mock 10 min drive/walk between salon branches
      const totalAltTimeMinutes = estimatedWaitMinutes + travelTimeMinutes;
      const netTimeSavingsMinutes = Math.max(0, primaryWaitMinutes - totalAltTimeMinutes);

      const isRecommended = primaryWaitMinutes > 20 && netTimeSavingsMinutes >= 5;
      const reason = isRecommended
        ? `Save ${netTimeSavingsMinutes} mins by visiting ${loc.name} (${travelTimeMinutes} min drive).`
        : `Primary location wait is manageable or alternative branch drive time exceeds savings.`;

      recommendations.push({
        locationId: loc.id,
        locationName: loc.name,
        address: loc.address,
        estimatedWaitMinutes,
        travelTimeMinutes,
        netTimeSavingsMinutes,
        isRecommended,
        reason,
      });
    }

    logger.info('Generated multi-location balancing report', {
      tenantId: actor.tenantId,
      primaryLocationId,
      primaryWaitMinutes,
      recommendationCount: recommendations.length,
    });

    return {
      tenantId: actor.tenantId,
      primaryLocationId,
      primaryWaitMinutes,
      recommendations,
      generatedAtIso: new Date().toISOString(),
    };
  }
}

export const multiLocationBalancingEngine = MultiLocationBalancingEngine.getInstance();
