export interface AvailabilitySlotQuery {
  tenantId: string;
  locationId: string;
  serviceId: string;
  staffId?: string; // Optional: specific staff or 'any'
  date: string; // YYYY-MM-DD
}

export interface TimeSlot {
  startTime: string; // ISO 8601
  endTime: string;   // ISO 8601
  staffId: string;
  resourceId?: string;
  isAvailable: boolean;
}

export interface BookingHoldRequest {
  tenantId: string;
  locationId: string;
  serviceId: string;
  staffId: string;
  startTime: string;
  endTime: string;
  ttlSeconds?: number; // Default 300 seconds (5 mins)
}

export interface BookingHoldResult {
  holdId: string;
  expiresAt: string;
  isAcquired: boolean;
}
