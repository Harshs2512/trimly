import {
  RateLimitCheckResult,
  CustomerDataExport,
  AnonymizationResult,
} from './types';
import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { createLogger } from '../../lib/logger';
import { bookingStore } from '../booking/store';
import { queueStore } from '../queue/store';

const logger = createLogger('SecurityService');

export class SecurityService {
  public static getInstance(): SecurityService {
    const g = globalThis as any;
    if (!g.__SECURITY_SERVICE_SINGLETON__) {
      g.__SECURITY_SERVICE_SINGLETON__ = new SecurityService();
    }
    return g.__SECURITY_SERVICE_SINGLETON__;
  }

  private rateLimitHits = new Map<string, { count: number; resetAt: number }>();
  private revokedSessions = new Set<string>();

  public checkRateLimit(key: string, maxHits = 5, windowMs = 60000): RateLimitCheckResult {
    const now = Date.now();
    const hit = this.rateLimitHits.get(key);

    if (!hit || now > hit.resetAt) {
      this.rateLimitHits.set(key, { count: 1, resetAt: now + windowMs });
      return {
        allowed: true,
        remainingHits: maxHits - 1,
        resetAtIso: new Date(now + windowMs).toISOString(),
      };
    }

    if (hit.count >= maxHits) {
      logger.warn('Rate limit exceeded', { key, maxHits });
      return {
        allowed: false,
        remainingHits: 0,
        resetAtIso: new Date(hit.resetAt).toISOString(),
      };
    }

    hit.count++;
    return {
      allowed: true,
      remainingHits: maxHits - hit.count,
      resetAtIso: new Date(hit.resetAt).toISOString(),
    };
  }

  public revokeSession(sessionId: string): void {
    this.revokedSessions.add(sessionId);
    logger.info('Session revoked', { sessionId });
  }

  public isSessionValid(sessionId: string): boolean {
    return !this.revokedSessions.has(sessionId);
  }

  public exportCustomerData(actor: UserContext, customerPhone: string): CustomerDataExport {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const appointments = bookingStore
      .getAppointmentsByTenant(actor.tenantId)
      .filter((a) => a.customerPhone === customerPhone);

    const queueHistory = queueStore
      .listByLocation(actor.tenantId, 'loc-a-1')
      .filter((q) => q.customerPhone === customerPhone);

    logger.info('Exported customer privacy data bundle', {
      tenantId: actor.tenantId,
      customerPhone,
      appointmentCount: appointments.length,
    });

    return {
      customerIdentifier: customerPhone,
      appointments,
      queueHistory,
      exportedAtIso: new Date().toISOString(),
    };
  }

  public anonymizeCustomerData(actor: UserContext, customerPhone: string): AnonymizationResult {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const appointments = bookingStore
      .getAppointmentsByTenant(actor.tenantId)
      .filter((a) => a.customerPhone === customerPhone);

    let anonymizedCount = 0;
    for (const apt of appointments) {
      apt.customerName = 'ANONYMIZED_CUSTOMER';
      apt.customerPhone = '+0000000000';
      anonymizedCount++;
    }

    const queueEntries = queueStore
      .listByLocation(actor.tenantId, 'loc-a-1')
      .filter((q) => q.customerPhone === customerPhone);

    for (const q of queueEntries) {
      q.customerName = 'ANONYMIZED_CUSTOMER';
      q.customerPhone = '+0000000000';
      anonymizedCount++;
    }

    logger.info('Anonymized customer personal details for privacy compliance', {
      tenantId: actor.tenantId,
      anonymizedCount,
    });

    return {
      success: true,
      recordsAnonymizedCount: anonymizedCount,
      anonymizedAtIso: new Date().toISOString(),
      message: `Successfully anonymized ${anonymizedCount} customer record(s).`,
    };
  }

  public clear(): void {
    this.rateLimitHits.clear();
    this.revokedSessions.clear();
  }
}

export const securityService = SecurityService.getInstance();
