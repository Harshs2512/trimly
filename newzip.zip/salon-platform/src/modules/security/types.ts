export interface RateLimitCheckResult {
  allowed: boolean;
  remainingHits: number;
  resetAtIso: string;
}

export interface CustomerDataExport {
  customerIdentifier: string;
  appointments: any[];
  queueHistory: any[];
  exportedAtIso: string;
}

export interface AnonymizationResult {
  success: boolean;
  recordsAnonymizedCount: number;
  anonymizedAtIso: string;
  message: string;
}
