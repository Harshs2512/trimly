import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { queueStore } from '../queue/store';
import { notificationService } from '../notifications/service';
import { createLogger } from '../../lib/logger';

const logger = createLogger('WaitlistRefillEngine');

export interface WaitlistRefillNotification {
  notifiedCustomerId?: string;
  recipientPhone?: string;
  ticketNumber?: string;
  status: 'NOTIFIED' | 'NO_WAITING_CUSTOMERS';
}

export class WaitlistRefillEngine {
  /**
   * Scans waiting queue entries and notifies eligible customer about opened capacity.
   */
  static async notifyNextInWaitlist(
    actor: UserContext,
    locationId: string,
    freedSlotIso: string
  ): Promise<WaitlistRefillNotification> {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const activeEntries = queueStore.listByLocation(actor.tenantId, locationId);
    const waitingEntries = activeEntries.filter((e) => e.state === 'WAITING');

    if (waitingEntries.length === 0) {
      logger.info('No waiting customers in queue for freed slot', {
        tenantId: actor.tenantId,
        locationId,
        freedSlotIso,
      });
      return { status: 'NO_WAITING_CUSTOMERS' };
    }

    // Sort by ticket number / creation time
    waitingEntries.sort((a, b) => a.ticketNumber.localeCompare(b.ticketNumber));
    const nextCustomer = waitingEntries[0];

    // Trigger notification
    await notificationService.dispatchNotification({
      tenantId: actor.tenantId,
      recipient: nextCustomer.customerPhone || '+15550000',
      channel: 'SMS',
      template: 'WAITLIST_OPENING',
      deduplicationKey: `waitlist-${nextCustomer.id}-${freedSlotIso}`,
      data: {
        ticketNumber: nextCustomer.ticketNumber,
        customerName: nextCustomer.customerName,
        freedSlotIso,
      },
    });

    logger.info('Notified waitlisted customer of available capacity', {
      tenantId: actor.tenantId,
      locationId,
      ticketNumber: nextCustomer.ticketNumber,
      customerPhone: nextCustomer.customerPhone,
    });

    return {
      status: 'NOTIFIED',
      notifiedCustomerId: nextCustomer.customerId,
      recipientPhone: nextCustomer.customerPhone,
      ticketNumber: nextCustomer.ticketNumber,
    };
  }
}
