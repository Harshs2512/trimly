export type AppointmentStatus =
  | 'PENDING'
  | 'CONFIRMED'
  | 'CHECKED_IN'
  | 'IN_SERVICE'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'NO_SHOW';

export interface BookingHoldRecord {
  id: string;
  tenantId: string;
  locationId: string;
  serviceId: string;
  staffId: string;
  startTime: string; // ISO 8601
  endTime: string;   // ISO 8601
  expiresAt: string; // ISO 8601
  status: 'ACTIVE' | 'EXPIRED' | 'CONVERTED';
  createdAt: string;
}

export interface ResourceReservationRecord {
  id: string;
  tenantId: string;
  locationId: string;
  staffId: string;
  resourceId?: string;
  startTime: string; // ISO 8601
  endTime: string;   // ISO 8601
  referenceType: 'HOLD' | 'APPOINTMENT' | 'WALK_IN';
  referenceId: string;
}

export interface AppointmentItemRecord {
  id: string;
  appointmentId: string;
  serviceId: string;
  staffId: string;
  durationMin: number;
  price: number;
}

export interface AppointmentRecord {
  id: string;
  tenantId: string;
  locationId: string;
  customerId: string;
  customerName: string;
  customerPhone: string;
  status: AppointmentStatus;
  startTime: string; // ISO 8601
  endTime: string;   // ISO 8601
  items: AppointmentItemRecord[];
  idempotencyKey: string;
  createdAt: string;
}
