import {
  BookingHoldRecord,
  ResourceReservationRecord,
  AppointmentRecord,
} from './types';
import { CapacityConcurrencyError } from '../../lib/errors';
import { createLogger } from '../../lib/logger';

const logger = createLogger('BookingStorePostgres');

let PoolClass: any = null;
try {
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const pgModule = require('pg');
  PoolClass = pgModule.Pool;
} catch {
  PoolClass = null;
}

class BookingStore {
  private holds = new Map<string, BookingHoldRecord>();
  private reservations = new Map<string, ResourceReservationRecord>();
  private appointments = new Map<string, AppointmentRecord>();
  private idempotencyKeys = new Map<string, AppointmentRecord>();
  
  private pool: any = null;
  private pgConnected = false;

  constructor() {
    this.initPgPool();
  }

  private initPgPool(): void {
    const connectionString = process.env.DATABASE_URL;
    if (connectionString && PoolClass) {
      try {
        this.pool = new PoolClass({
          connectionString,
          connectionTimeoutMillis: 2000,
          idleTimeoutMillis: 10000,
          max: 10,
        });
      } catch (err) {
        logger.warn('Failed to initialize PostgreSQL pool, using in-memory store', { error: err });
      }
    }
  }

  public isPgAvailable(): boolean {
    return this.pgConnected && this.pool !== null;
  }

  public async checkPgHealth(): Promise<boolean> {
    if (!this.pool) return false;
    try {
      const client = await this.pool.connect();
      await client.query('SELECT 1');
      client.release();
      this.pgConnected = true;
      return true;
    } catch {
      this.pgConnected = false;
      return false;
    }
  }

  public clear(): void {
    this.holds.clear();
    this.reservations.clear();
    this.appointments.clear();
    this.idempotencyKeys.clear();
  }

  public createAppointment(data: {
    tenantId: string;
    locationId: string;
    holdId: string;
    serviceId: string;
    staffId: string;
    customerId?: string;
    customerName: string;
    customerPhone: string;
    startIso: string;
    endIso: string;
    idempotencyKey: string;
  }): AppointmentRecord {
    const appointmentId = `apt-${Date.now()}-${Math.random().toString(36).substring(2, 5)}`;
    const apt: AppointmentRecord = {
      id: appointmentId,
      tenantId: data.tenantId,
      locationId: data.locationId,
      customerId: data.customerId || 'cust-anon',
      customerName: data.customerName,
      customerPhone: data.customerPhone,
      status: 'CONFIRMED',
      startTime: data.startIso,
      endTime: data.endIso,
      idempotencyKey: data.idempotencyKey,
      items: [
        {
          id: `item-1`,
          appointmentId: appointmentId,
          serviceId: data.serviceId,
          staffId: data.staffId,
          durationMin: 30,
          price: 35.0,
        },
      ],
      createdAt: new Date().toISOString(),
    };
    this.addAppointment(apt);
    return apt;
  }

  public listByLocation(tenantId: string, locationId: string): AppointmentRecord[] {
    return Array.from(this.appointments.values()).filter(
      (a) => a.tenantId === tenantId && a.locationId === locationId
    );
  }

  public getAppointment(id: string): AppointmentRecord | undefined {
    return this.appointments.get(id);
  }

  public cleanupExpiredHolds(): void {
    const now = new Date().toISOString();
    for (const [id, hold] of this.holds.entries()) {
      if (hold.status === 'ACTIVE' && hold.expiresAt <= now) {
        hold.status = 'EXPIRED';
        for (const [resId, res] of this.reservations.entries()) {
          if (res.referenceType === 'HOLD' && res.referenceId === hold.id) {
            this.reservations.delete(resId);
          }
        }
      }
    }
  }

  public getActiveReservationsForStaff(
    tenantId: string,
    locationId: string,
    staffId: string
  ): ResourceReservationRecord[] {
    this.cleanupExpiredHolds();
    return Array.from(this.reservations.values()).filter(
      (r) =>
        r.tenantId === tenantId &&
        r.locationId === locationId &&
        r.staffId === staffId
    );
  }

  public addHold(hold: BookingHoldRecord): void {
    this.holds.set(hold.id, hold);
    const reservation: ResourceReservationRecord = {
      id: `res-hold-${hold.id}`,
      tenantId: hold.tenantId,
      locationId: hold.locationId,
      staffId: hold.staffId,
      startTime: hold.startTime,
      endTime: hold.endTime,
      referenceType: 'HOLD',
      referenceId: hold.id,
    };
    this.reservations.set(reservation.id, reservation);
  }

  public removeHoldReservation(holdId: string): void {
    this.reservations.delete(`res-hold-${holdId}`);
    for (const [resId, res] of this.reservations.entries()) {
      if (res.referenceType === 'HOLD' && res.referenceId === holdId) {
        this.reservations.delete(resId);
      }
    }
  }

  public getHold(holdId: string): BookingHoldRecord | undefined {
    this.cleanupExpiredHolds();
    return this.holds.get(holdId);
  }

  public addAppointment(apt: AppointmentRecord): void {
    this.appointments.set(apt.id, apt);
    this.idempotencyKeys.set(apt.idempotencyKey, apt);

    for (const item of apt.items) {
      const reservation: ResourceReservationRecord = {
        id: `res-apt-${apt.id}-${item.id}`,
        tenantId: apt.tenantId,
        locationId: apt.locationId,
        staffId: item.staffId,
        startTime: apt.startTime,
        endTime: apt.endTime,
        referenceType: 'APPOINTMENT',
        referenceId: apt.id,
      };
      this.reservations.set(reservation.id, reservation);
    }
  }

  public cancelAppointment(appointmentId: string): boolean {
    const apt = this.appointments.get(appointmentId);
    if (!apt) return false;

    apt.status = 'CANCELLED';

    for (const [resId, res] of this.reservations.entries()) {
      if (res.referenceType === 'APPOINTMENT' && res.referenceId === appointmentId) {
        this.reservations.delete(resId);
      }
    }

    return true;
  }

  public getAppointmentByIdempotencyKey(key: string): AppointmentRecord | undefined {
    return this.idempotencyKeys.get(key);
  }

  public getAppointmentsByTenant(tenantId: string): AppointmentRecord[] {
    return Array.from(this.appointments.values()).filter(a => a.tenantId === tenantId);
  }

  /**
   * PostgreSQL-based transactional booking confirmation with EXCLUSION constraint enforcement.
   */
  public async confirmAppointmentPg(
    client: PoolClient,
    data: {
      appointmentId: string;
      tenantId: string;
      locationId: string;
      holdId: string;
      customerId: string;
      customerName: string;
      customerPhone: string;
      staffId: string;
      serviceId: string;
      startTimeIso: string;
      endTimeIso: string;
      idempotencyKey: string;
    }
  ): Promise<AppointmentRecord> {
    try {
      await client.query('BEGIN');

      // 1. Idempotency Check
      const idempotencyRes = await client.query(
        'SELECT * FROM appointments WHERE idempotency_key = $1 FOR UPDATE',
        [data.idempotencyKey]
      );
      if (idempotencyRes.rows.length > 0) {
        await client.query('COMMIT');
        const row = idempotencyRes.rows[0];
        return {
          id: row.id,
          tenantId: row.tenant_id,
          locationId: row.location_id,
          customerId: row.customer_id,
          customerName: row.customer_name,
          customerPhone: row.customer_phone,
          status: row.status,
          startTime: row.start_time,
          endTime: row.end_time,
          idempotencyKey: row.idempotency_key,
          items: [],
          createdAt: row.created_at,
        };
      }

      // 2. Insert Exclusion Reservation (Fails with code 23P01 on capacity overlap)
      const resId = `res-${data.appointmentId}`;
      await client.query(
        `INSERT INTO resource_reservations (id, tenant_id, location_id, resource_type, resource_id, start_time, end_time, appointment_id)
         VALUES ($1, $2, $3, $4, $5, $6, $7, NULL)`,
        [resId, data.tenantId, data.locationId, 'STAFF', data.staffId, data.startTimeIso, data.endTimeIso]
      );

      // 3. Insert Appointment Record
      await client.query(
        `INSERT INTO appointments (id, tenant_id, location_id, customer_id, customer_name, customer_phone, staff_id, service_id, start_time, end_time, status, idempotency_key)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)`,
        [
          data.appointmentId,
          data.tenantId,
          data.locationId,
          data.customerId,
          data.customerName,
          data.customerPhone,
          data.staffId,
          data.serviceId,
          data.startTimeIso,
          data.endTimeIso,
          'CONFIRMED',
          data.idempotencyKey,
        ]
      );

      // 4. Update Reservation with Appointment FK
      await client.query(
        'UPDATE resource_reservations SET appointment_id = $1 WHERE id = $2',
        [data.appointmentId, resId]
      );

      await client.query('COMMIT');

      const aptRecord: AppointmentRecord = {
        id: data.appointmentId,
        tenantId: data.tenantId,
        locationId: data.locationId,
        customerId: data.customerId,
        customerName: data.customerName,
        customerPhone: data.customerPhone,
        status: 'CONFIRMED',
        startTime: data.startTimeIso,
        endTime: data.endTimeIso,
        idempotencyKey: data.idempotencyKey,
        items: [
          {
            id: `item-${data.appointmentId}`,
            appointmentId: data.appointmentId,
            serviceId: data.serviceId,
            staffId: data.staffId,
            durationMin: 30,
            price: 35.0,
          },
        ],
        createdAt: new Date().toISOString(),
      };

      return aptRecord;
    } catch (error: any) {
      await client.query('ROLLBACK');
      if (error.code === '23P01' || error.code === '23505') {
        throw new CapacityConcurrencyError('Selected time slot or staff capacity was just booked by another request');
      }
      throw error;
    }
  }

  public getPool(): Pool | null {
    return this.pool;
  }
}

export const bookingStore = new BookingStore();

