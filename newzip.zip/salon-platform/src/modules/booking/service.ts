import { identityService } from '../identity/service';
import { masterDataService } from '../masterdata/service';
import { UserContext } from '../identity/types';
import { CapacityConcurrencyError, ValidationError, NotFoundError } from '../../lib/errors';
import { createLogger } from '../../lib/logger';
import { bookingStore } from './store';
import { TimeSlot } from '../availability/types';
import { AppointmentRecord, BookingHoldRecord } from './types';
import { notificationService } from '../notifications/service';
import { WaitlistRefillEngine } from './waitlist';

const logger = createLogger('BookingEngine');

export class BookingService {
  public clear(): void {
    bookingStore.clear();
  }

  public createAppointment(data: any): AppointmentRecord {
    return bookingStore.createAppointment(data);
  }

  /**
   * Evaluates whether a requested staff member interval overlaps any existing reservation or break.
   */
  public isIntervalAvailable(
    tenantId: string,
    locationId: string,
    staffId: string,
    startTimeIso: string,
    endTimeIso: string,
    ignoreHoldId?: string
  ): boolean {
    const existingReservations = bookingStore.getActiveReservationsForStaff(tenantId, locationId, staffId);
    
    const reqStart = new Date(startTimeIso).getTime();
    const reqEnd = new Date(endTimeIso).getTime();

    for (const res of existingReservations) {
      if (ignoreHoldId && res.referenceType === 'HOLD' && res.referenceId === ignoreHoldId) {
        continue;
      }
      const resStart = new Date(res.startTime).getTime();
      const resEnd = new Date(res.endTime).getTime();

      // Interval overlap condition: reqStart < resEnd && reqEnd > resStart
      if (reqStart < resEnd && reqEnd > resStart) {
        return false;
      }
    }
    return true;
  }

  /**
   * Calculates available time slots for a service and date.
   */
  public calculateAvailableSlots(
    actor: UserContext,
    locationId: string,
    serviceId: string,
    dateStr: string, // YYYY-MM-DD
    preferredStaffId?: string
  ): TimeSlot[] {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const location = masterDataService.getLocation(actor, locationId);
    const service = masterDataService.getTenantServices(actor).find(s => s.id === serviceId);
    if (!service) throw new NotFoundError('Service');

    const eligibleStaff = masterDataService.getEligibleStaff(actor, locationId, serviceId);
    const targetStaff = preferredStaffId
      ? eligibleStaff.filter(s => s.id === preferredStaffId)
      : eligibleStaff;

    if (targetStaff.length === 0) return [];

    const slots: TimeSlot[] = [];
    const durationMs = service.defaultDurationMin * 60 * 1000;

    // Generate potential slots between 09:00 and 17:00 at 30 min step intervals
    const baseDate = new Date(`${dateStr}T09:00:00Z`);

    for (let step = 0; step < 16; step++) { // 8 hours = 16 30-min slots
      const slotStart = new Date(baseDate.getTime() + step * 30 * 60 * 1000);
      const slotEnd = new Date(slotStart.getTime() + durationMs);

      const slotStartIso = slotStart.toISOString();
      const slotEndIso = slotEnd.toISOString();

      for (const staffMember of targetStaff) {
        // Check if staff has break overlapping slot
        const hasBreak = staffMember.breaks.some(b => {
          const breakStart = new Date(`${dateStr}T${b.startTime}:00Z`).getTime();
          const breakEnd = new Date(`${dateStr}T${b.endTime}:00Z`).getTime();
          return slotStart.getTime() < breakEnd && slotEnd.getTime() > breakStart;
        });

        if (hasBreak) continue;

        const available = this.isIntervalAvailable(
          actor.tenantId,
          locationId,
          staffMember.id,
          slotStartIso,
          slotEndIso
        );

        if (available) {
          slots.push({
            startTime: slotStartIso,
            endTime: slotEndIso,
            staffId: staffMember.id,
            isAvailable: true,
          });
        }
      }
    }

    return slots;
  }

  /**
   * Acquires a temporary hold (5 minutes TTL) on capacity.
   */
  public acquireHold(
    actor: UserContext,
    locationId: string,
    serviceId: string,
    staffId: string,
    startTimeIso: string,
    endTimeIso: string
  ): BookingHoldRecord {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const isFree = this.isIntervalAvailable(actor.tenantId, locationId, staffId, startTimeIso, endTimeIso);
    if (!isFree) {
      throw new CapacityConcurrencyError('Requested capacity interval is no longer available');
    }

    const hold: BookingHoldRecord = {
      id: `hold-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tenantId: actor.tenantId,
      locationId,
      serviceId,
      staffId,
      startTime: startTimeIso,
      endTime: endTimeIso,
      expiresAt: new Date(Date.now() + 5 * 60 * 1000).toISOString(), // 5 minutes TTL
      status: 'ACTIVE',
      createdAt: new Date().toISOString(),
    };

    bookingStore.addHold(hold);
    logger.info('Acquired temporary booking hold', { holdId: hold.id, staffId, startTimeIso });
    return hold;
  }

  /**
   * Transactionally confirms an appointment, verifying idempotency and capacity locks.
   */
  public async confirmAppointment(
    actor: UserContext,
    holdId: string,
    customerName: string,
    customerPhone: string,
    idempotencyKey: string
  ): Promise<AppointmentRecord> {
    identityService.validateTenantAccess(actor, actor.tenantId);

    // 1. Idempotency Check
    const existing = bookingStore.getAppointmentByIdempotencyKey(idempotencyKey);
    if (existing) {
      logger.info('Idempotent appointment request returned existing record', { idempotencyKey });
      return existing;
    }

    // 2. Retrieve & Validate Hold
    const hold = bookingStore.getHold(holdId);
    if (!hold || hold.status !== 'ACTIVE') {
      throw new ValidationError('Booking hold has expired or is invalid. Please select slot again');
    }

    identityService.validateTenantAccess(actor, hold.tenantId);

    // 3. Authoritative Re-check Capacity
    const capacityFree = this.isIntervalAvailable(
      actor.tenantId,
      hold.locationId,
      hold.staffId,
      hold.startTime,
      hold.endTime,
      holdId // Ignore current hold
    );

    if (!capacityFree) {
      throw new CapacityConcurrencyError('Capacity conflict: Another request acquired this time slot');
    }

    // 4. Create Appointment Record
    const service = masterDataService.getTenantServices(actor).find(s => s.id === hold.serviceId);

    const appointment: AppointmentRecord = {
      id: `apt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tenantId: actor.tenantId,
      locationId: hold.locationId,
      customerId: `cust-${Date.now()}`,
      customerName,
      customerPhone,
      status: 'CONFIRMED',
      startTime: hold.startTime,
      endTime: hold.endTime,
      items: [
        {
          id: `item-${Date.now()}`,
          appointmentId: '',
          serviceId: hold.serviceId,
          staffId: hold.staffId,
          durationMin: service ? service.defaultDurationMin : 30,
          price: service ? service.price : 35.0,
        },
      ],
      idempotencyKey,
      createdAt: new Date().toISOString(),
    };

    appointment.items[0].appointmentId = appointment.id;
    hold.status = 'CONVERTED';
    bookingStore.removeHoldReservation(hold.id);

    bookingStore.addAppointment(appointment);
    logger.info('Appointment confirmed successfully', { appointmentId: appointment.id, idempotencyKey });

    // Send confirmation notification
    await notificationService.dispatchNotification({
      tenantId: actor.tenantId,
      recipient: customerPhone,
      channel: 'SMS',
      template: 'APPOINTMENT_CONFIRMED',
      deduplicationKey: `apt-confirm-${appointment.id}`,
      data: {
        appointmentId: appointment.id,
        customerName,
        startTimeIso: hold.startTime,
      },
    });

    return appointment;
  }

  /**
   * Cancels an appointment, releases capacity lock, calculates refund policy eligibility,
   * notifies customer, and triggers waitlist refill engine.
   */
  public async cancelAppointment(
    actor: UserContext,
    appointmentId: string,
    reason?: string
  ): Promise<{ appointment: AppointmentRecord; refundEligible: boolean; refundPercentage: number }> {
    const appointment = bookingStore.getAppointment(appointmentId);
    if (!appointment) throw new NotFoundError(`Appointment ${appointmentId}`);

    identityService.validateTenantAccess(actor, appointment.tenantId);

    const success = bookingStore.cancelAppointment(appointmentId);
    if (!success) throw new ValidationError('Failed to cancel appointment');

    // Calculate cancellation policy (e.g. >2 hours prior to start = 100% refund eligible)
    const startTimeMs = new Date(appointment.startTime).getTime();
    const nowMs = Date.now();
    const hoursNotice = (startTimeMs - nowMs) / (1000 * 60 * 60);

    const refundEligible = hoursNotice >= 2;
    const refundPercentage = refundEligible ? 100 : 0;

    logger.info('Appointment cancelled', {
      appointmentId,
      tenantId: actor.tenantId,
      reason,
      refundEligible,
      hoursNotice,
    });

    // Notify customer
    await notificationService.dispatchNotification({
      tenantId: actor.tenantId,
      recipient: appointment.customerPhone,
      channel: 'SMS',
      template: 'APPOINTMENT_CANCELLED',
      deduplicationKey: `apt-cancel-${appointment.id}`,
      data: {
        appointmentId: appointment.id,
        customerName: appointment.customerName,
        reason: reason || 'Customer request',
      },
    });

    // Trigger Waitlist Refill Engine for freed slot
    await WaitlistRefillEngine.notifyNextInWaitlist(actor, appointment.locationId, appointment.startTime);

    return { appointment, refundEligible, refundPercentage };
  }

  /**
   * Reschedules an appointment to a new capacity hold atomically.
   */
  public async rescheduleAppointment(
    actor: UserContext,
    appointmentId: string,
    newHoldId: string,
    idempotencyKey: string
  ): Promise<AppointmentRecord> {
    const appointment = bookingStore.getAppointment(appointmentId);
    if (!appointment) throw new NotFoundError(`Appointment ${appointmentId}`);

    identityService.validateTenantAccess(actor, appointment.tenantId);

    const newHold = bookingStore.getHold(newHoldId);
    if (!newHold || newHold.status !== 'ACTIVE') {
      throw new ValidationError('New booking hold is invalid or expired');
    }

    // Release old capacity reservation
    bookingStore.cancelAppointment(appointmentId);

    // Update appointment time
    const oldStartTime = appointment.startTime;
    appointment.startTime = newHold.startTime;
    appointment.endTime = newHold.endTime;
    appointment.status = 'CONFIRMED';
    newHold.status = 'CONVERTED';

    // Re-register appointment with new capacity
    bookingStore.addAppointment(appointment);

    logger.info('Appointment rescheduled successfully', {
      appointmentId,
      tenantId: actor.tenantId,
      oldStartTime,
      newStartTime: newHold.startTime,
    });

    // Notify customer
    await notificationService.dispatchNotification({
      tenantId: actor.tenantId,
      recipient: appointment.customerPhone,
      channel: 'SMS',
      template: 'APPOINTMENT_REMINDER',
      deduplicationKey: `apt-resched-${appointment.id}-${newHold.startTime}`,
      data: {
        appointmentId: appointment.id,
        customerName: appointment.customerName,
        newStartTime: newHold.startTime,
      },
    });

    // Trigger Waitlist Refill for the old slot
    await WaitlistRefillEngine.notifyNextInWaitlist(actor, appointment.locationId, oldStartTime);

    return appointment;
  }
}

export const bookingService = new BookingService();
