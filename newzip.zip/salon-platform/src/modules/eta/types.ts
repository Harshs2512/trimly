export interface ETACalculationInput {
  tenantId: string;
  locationId: string;
  queueEntryId: string;
  serviceId: string;
  preferredStaffId?: string;
}

export interface ETARangeResult {
  queueEntryId: string;
  predictedStartIso: string;
  lowerEtaBoundIso: string;
  upperEtaBoundIso: string;
  recommendedArrivalIso: string;
  waitMinutesMin: number;
  waitMinutesMax: number;
  confidence: 'HIGH' | 'MEDIUM' | 'LOW';
  modelVersion: string;
  calculatedAtIso: string;
}

export interface DispatchAssignment {
  queueEntryId: string;
  staffId: string;
  assignedStartIso: string;
  assignedEndIso: string;
}
