import { dispatchEngine } from './dispatch';
import { ETARangeResult } from './types';
import { queueStore } from '../queue/store';
import { masterDataStore } from '../masterdata/store';
import { AuthActor } from '../identity/types';
import { TenantIsolationError } from '../../lib/errors';

export class ETAService {
  /**
   * Recalculate and persist ETAs for all active queue entries in a location.
   */
  recalculateLocationEtas(tenantId: string, locationId: string): ETARangeResult[] {
    const assignments = dispatchEngine.calculateDispatch(tenantId, locationId);
    const activeEntries = queueStore.listActiveByLocation(tenantId, locationId);
    const results: ETARangeResult[] = [];
    const nowMs = Date.now();

    for (let index = 0; index < activeEntries.length; index++) {
      const entry = activeEntries[index];
      const assignment = assignments.find((a) => a.queueEntryId === entry.id);

      const predictedStartMs = assignment
        ? new Date(assignment.assignedStartIso).getTime()
        : nowMs + (index + 1) * 30 * 60 * 1000;

      const waitMinutesExact = Math.max(0, Math.round((predictedStartMs - nowMs) / 60000));

      // Calculate lower & upper ETA bounds with explainable interval padding (e.g. ±5 mins)
      const lowerMinutes = Math.max(0, waitMinutesExact - 5);
      const upperMinutes = waitMinutesExact + 5;

      const predictedStartIso = new Date(predictedStartMs).toISOString();
      const lowerEtaBoundIso = new Date(nowMs + lowerMinutes * 60000).toISOString();
      const upperEtaBoundIso = new Date(nowMs + upperMinutes * 60000).toISOString();

      // Recommended arrival is 8 minutes before lower bound
      const recommendedArrivalMs = Math.max(nowMs, predictedStartMs - 8 * 60000);
      const recommendedArrivalIso = new Date(recommendedArrivalMs).toISOString();

      const confidence: 'HIGH' | 'MEDIUM' | 'LOW' = index < 3 ? 'HIGH' : index < 7 ? 'MEDIUM' : 'LOW';

      const result: ETARangeResult = {
        queueEntryId: entry.id,
        predictedStartIso,
        lowerEtaBoundIso,
        upperEtaBoundIso,
        recommendedArrivalIso,
        waitMinutesMin: lowerMinutes,
        waitMinutesMax: upperMinutes,
        confidence,
        modelVersion: 'V1.0-DETERMINISTIC',
        calculatedAtIso: new Date().toISOString(),
      };

      results.push(result);

      // Persist computed ETA on queue entry
      queueStore.updateEtaFields(entry.id, {
        assignedStaffId: assignment?.staffId,
        position: index + 1,
        estimatedStartIso: predictedStartIso,
        lowerEtaBoundIso,
        upperEtaBoundIso,
        recommendedArrivalIso,
        waitMinutesMin: lowerMinutes,
        waitMinutesMax: upperMinutes,
      });
    }

    return results;
  }

  getEtaForEntry(actor: AuthActor, queueEntryId: string): ETARangeResult {
    const entry = queueStore.getById(queueEntryId);
    if (!entry) {
      throw new Error(`Queue entry ${queueEntryId} not found.`);
    }

    if (actor.tenantId !== entry.tenantId) {
      throw new TenantIsolationError('Cross tenant ETA access denied.');
    }

    // Run calculation to ensure fresh estimates
    const locationEtas = this.recalculateLocationEtas(entry.tenantId, entry.locationId);
    const found = locationEtas.find((r) => r.queueEntryId === queueEntryId);

    if (found) return found;

    // Fallback if not active
    const nowMs = Date.now();
    return {
      queueEntryId,
      predictedStartIso: entry.estimatedStartIso || new Date(nowMs).toISOString(),
      lowerEtaBoundIso: entry.lowerEtaBoundIso || new Date(nowMs).toISOString(),
      upperEtaBoundIso: entry.upperEtaBoundIso || new Date(nowMs).toISOString(),
      recommendedArrivalIso: entry.recommendedArrivalIso || new Date(nowMs).toISOString(),
      waitMinutesMin: entry.waitMinutesMin || 0,
      waitMinutesMax: entry.waitMinutesMax || 0,
      confidence: 'HIGH',
      modelVersion: 'V1.0-DETERMINISTIC',
      calculatedAtIso: new Date().toISOString(),
    };
  }
}

export const etaService = new ETAService();
