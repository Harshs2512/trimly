import { masterDataStore } from '../masterdata/store';
import { bookingStore } from '../booking/store';
import { queueStore } from '../queue/store';
import { QueueEntry } from '../queue/types';
import { DispatchAssignment } from './types';

export class DispatchEngine {
  /**
   * Calculates earliest feasible assignments for active walk-in queue entries
   * while strictly protecting scheduled appointments from delay or overlap.
   */
  calculateDispatch(tenantId: string, locationId: string): DispatchAssignment[] {
    const activeEntries = queueStore.listActiveByLocation(tenantId, locationId);
    if (activeEntries.length === 0) return [];

    const staffList = masterDataStore.listStaff(tenantId, locationId).filter((s) => s.status === 'AVAILABLE');
    const services = masterDataStore.listServices(tenantId);
    const serviceMap = new Map(services.map((s) => [s.id, s]));

    const appointments = bookingStore.listByLocation(tenantId, locationId)
      .filter((a) => a.status === 'CONFIRMED' || a.status === 'IN_SERVICE');

    const now = Date.now();
    // Track next available time per staff (in epoch ms)
    const staffBusyUntil: Map<string, number> = new Map();

    for (const staff of staffList) {
      // Check if staff has active in-service appointment
      const activeApt = appointments.find((a) => a.items.some((i) => i.staffId === staff.id) && a.status === 'IN_SERVICE');
      if (activeApt) {
        staffBusyUntil.set(staff.id, new Date(activeApt.endTime).getTime());
      } else {
        staffBusyUntil.set(staff.id, now);
      }
    }

    const assignments: DispatchAssignment[] = [];

    for (const entry of activeEntries) {
      if (entry.state === 'IN_SERVICE') continue;

      const service = serviceMap.get(entry.serviceId);
      const durationMinutes = service?.defaultDurationMin || (service as any)?.durationMinutes || 30;
      const durationMs = durationMinutes * 60 * 1000;

      // Filter eligible staff (matches preferredStaffId if specified, or has service skill)
      let eligibleStaff = staffList.filter((s) => {
        if (entry.preferredStaffId && s.id !== entry.preferredStaffId) {
          return false;
        }
        return true;
      });

      if (eligibleStaff.length === 0 && entry.preferredStaffId) {
        // Fallback to any staff if preferred staff is unavailable
        eligibleStaff = staffList;
      }

      if (eligibleStaff.length === 0) continue;

      // Find best staff assignment that gives earliest finish WITHOUT conflicting with fixed appointments
      let bestStaffId = '';
      let bestStartMs = Infinity;

      for (const staff of eligibleStaff) {
        let candidateStartMs = Math.max(now, staffBusyUntil.get(staff.id) || now);

        // Check conflicts with upcoming confirmed appointments for this staff
        const staffApts = appointments
          .filter((a) => a.items.some((i) => i.staffId === staff.id) && a.status === 'CONFIRMED')
          .sort((a, b) => new Date(a.startTime).getTime() - new Date(b.startTime).getTime());

        for (const apt of staffApts) {
          const aptStartMs = new Date(apt.startTime).getTime();
          const aptEndMs = new Date(apt.endTime).getTime();

          // If proposed walk-in interval [candidateStartMs, candidateStartMs + durationMs] overlaps appointment [aptStartMs, aptEndMs], push candidateStartMs to after appointment!
          if (candidateStartMs + durationMs > aptStartMs && candidateStartMs < aptEndMs) {
            candidateStartMs = aptEndMs;
          }
        }

        if (candidateStartMs < bestStartMs) {
          bestStartMs = candidateStartMs;
          bestStaffId = staff.id;
        }
      }

      if (bestStaffId && bestStartMs !== Infinity) {
        const startIso = new Date(bestStartMs).toISOString();
        const endIso = new Date(bestStartMs + durationMs).toISOString();

        assignments.push({
          queueEntryId: entry.id,
          staffId: bestStaffId,
          assignedStartIso: startIso,
          assignedEndIso: endIso,
        });

        // Reserve this staff member's availability up to endIso for subsequent walk-ins
        staffBusyUntil.set(bestStaffId, bestStartMs + durationMs);
      }
    }

    return assignments;
  }
}

export const dispatchEngine = new DispatchEngine();
