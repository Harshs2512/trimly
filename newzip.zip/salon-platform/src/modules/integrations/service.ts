import crypto from 'node:crypto';
import {
  PosSyncRequest,
  PosSyncResult,
  WebhookDispatchInput,
  WebhookDispatchResult,
} from './types';
import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { createLogger } from '../../lib/logger';

const logger = createLogger('ExternalIntegrationEngine');

export class ExternalIntegrationEngine {
  public static getInstance(): ExternalIntegrationEngine {
    const g = globalThis as any;
    if (!g.__EXTERNAL_INTEGRATION_ENGINE_SINGLETON__) {
      g.__EXTERNAL_INTEGRATION_ENGINE_SINGLETON__ = new ExternalIntegrationEngine();
    }
    return g.__EXTERNAL_INTEGRATION_ENGINE_SINGLETON__;
  }

  public syncToPos(actor: UserContext, request: PosSyncRequest): PosSyncResult {
    identityService.validateTenantAccess(actor, request.tenantId);

    const posReference = `pos_ref_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;
    const syncId = `sync_${Date.now()}`;

    logger.info('Synced transaction to external POS terminal', {
      tenantId: request.tenantId,
      locationId: request.locationId,
      appointmentId: request.appointmentId,
      posReference,
    });

    return {
      syncId,
      posReference,
      status: 'SYNCED',
      syncedAtIso: new Date().toISOString(),
    };
  }

  public dispatchWebhook(actor: UserContext, input: WebhookDispatchInput): WebhookDispatchResult {
    identityService.validateTenantAccess(actor, input.tenantId);

    const payloadString = JSON.stringify(input.payload);
    const signature = crypto
      .createHmac('sha256', input.secretKey)
      .update(payloadString)
      .digest('hex');

    const dispatchId = `whd_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`;

    logger.info('Dispatched outbound webhook event with HMAC signature', {
      tenantId: input.tenantId,
      eventType: input.eventType,
      targetUrl: input.targetUrl,
      signature: `sha256=${signature.substring(0, 10)}...`,
    });

    return {
      dispatchId,
      targetUrl: input.targetUrl,
      statusCode: 200,
      signature: `sha256=${signature}`,
      success: true,
      deliveredAtIso: new Date().toISOString(),
    };
  }
}

export const externalIntegrationEngine = ExternalIntegrationEngine.getInstance();
