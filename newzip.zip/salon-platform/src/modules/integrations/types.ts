export interface PosSyncRequest {
  tenantId: string;
  locationId: string;
  appointmentId: string;
  customerName: string;
  totalAmount: number;
  paymentStatus: 'PAID' | 'UNPAID';
}

export interface PosSyncResult {
  syncId: string;
  posReference: string;
  status: 'SYNCED' | 'FAILED';
  syncedAtIso: string;
}

export interface WebhookDispatchInput {
  tenantId: string;
  eventType: 'appointment.created' | 'appointment.completed' | 'queue.joined' | 'payment.succeeded';
  payload: Record<string, any>;
  targetUrl: string;
  secretKey: string;
}

export interface WebhookDispatchResult {
  dispatchId: string;
  targetUrl: string;
  statusCode: number;
  signature: string;
  success: boolean;
  deliveredAtIso: string;
}
