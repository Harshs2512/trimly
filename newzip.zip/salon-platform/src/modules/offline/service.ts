import {
  OfflineMutationEnvelope,
  ReconnectionSyncResponse,
  MutationSyncResult,
} from './types';
import { UserContext } from '../identity/types';
import { identityService } from '../identity/service';
import { createLogger } from '../../lib/logger';
import { ValidationError } from '../../lib/errors';
import { queueStore } from '../queue/store';
import { bookingStore } from '../booking/store';

const logger = createLogger('OfflineMutationEngine');

export class OfflineMutationEngine {
  public static getInstance(): OfflineMutationEngine {
    const g = globalThis as any;
    if (!g.__OFFLINE_MUTATION_ENGINE_SINGLETON__) {
      g.__OFFLINE_MUTATION_ENGINE_SINGLETON__ = new OfflineMutationEngine();
    }
    return g.__OFFLINE_MUTATION_ENGINE_SINGLETON__;
  }

  private processedMutations = new Set<string>(); // idempotencyKey -> processed

  public syncOfflineMutations(
    actor: UserContext,
    mutations: OfflineMutationEnvelope[]
  ): ReconnectionSyncResponse {
    identityService.validateTenantAccess(actor, actor.tenantId);

    const results: MutationSyncResult[] = [];
    let applied = 0;
    let conflicts = 0;
    let rejected = 0;

    for (const m of mutations) {
      // 1. Tenant Isolation check
      if (m.tenantId !== actor.tenantId) {
        results.push({
          localMutationId: m.localMutationId,
          status: 'REJECTED',
          message: 'Cross-tenant offline mutation rejected',
          processedAtIso: new Date().toISOString(),
        });
        rejected++;
        continue;
      }

      // 2. Idempotency Check
      if (this.processedMutations.has(m.idempotencyKey)) {
        results.push({
          localMutationId: m.localMutationId,
          status: 'APPLIED',
          message: 'Mutation previously applied (idempotent)',
          processedAtIso: new Date().toISOString(),
        });
        applied++;
        continue;
      }

      // 3. Operation Validation & Execution
      try {
        if (m.operation === 'START_SERVICE') {
          const entry = queueStore.getById(m.targetId);
          if (entry && ['CHECKED_IN', 'CALLED'].includes(entry.state)) {
            queueStore.transitionState(m.targetId, 'IN_SERVICE', actor.userId, 'Offline sync: start service');
            results.push({
              localMutationId: m.localMutationId,
              status: 'APPLIED',
              message: 'Service started successfully via offline sync',
              processedAtIso: new Date().toISOString(),
            });
            applied++;
          } else {
            results.push({
              localMutationId: m.localMutationId,
              status: 'CONFLICT',
              message: 'State conflict: entry is not in CHECKED_IN or CALLED state',
              processedAtIso: new Date().toISOString(),
            });
            conflicts++;
          }
        } else if (m.operation === 'COMPLETE_SERVICE') {
          const entry = queueStore.getById(m.targetId);
          if (entry && entry.state === 'IN_SERVICE') {
            queueStore.transitionState(m.targetId, 'COMPLETED', actor.userId, 'Offline sync: complete service');
            results.push({
              localMutationId: m.localMutationId,
              status: 'APPLIED',
              message: 'Service completed successfully via offline sync',
              processedAtIso: new Date().toISOString(),
            });
            applied++;
          } else {
            results.push({
              localMutationId: m.localMutationId,
              status: 'CONFLICT',
              message: 'State conflict: entry is not in IN_SERVICE state',
              processedAtIso: new Date().toISOString(),
            });
            conflicts++;
          }
        } else if (m.operation === 'ADD_SERVICE_NOTE') {
          // Safe service note mutation
          results.push({
            localMutationId: m.localMutationId,
            status: 'APPLIED',
            message: 'Service note recorded successfully',
            processedAtIso: new Date().toISOString(),
          });
          applied++;
        } else {
          throw new ValidationError(`Unsupported offline operation: ${m.operation}`);
        }

        this.processedMutations.add(m.idempotencyKey);
      } catch (err: any) {
        logger.warn('Failed to process offline mutation', {
          localMutationId: m.localMutationId,
          error: err.message,
        });
        results.push({
          localMutationId: m.localMutationId,
          status: 'REJECTED',
          message: err.message || 'Processing error',
          processedAtIso: new Date().toISOString(),
        });
        rejected++;
      }
    }

    logger.info('Completed offline reconnection sync batch', {
      tenantId: actor.tenantId,
      totalSubmitted: mutations.length,
      appliedCount: applied,
      conflictCount: conflicts,
      rejectedCount: rejected,
    });

    return {
      totalSubmitted: mutations.length,
      appliedCount: applied,
      conflictCount: conflicts,
      rejectedCount: rejected,
      results,
    };
  }

  public clear(): void {
    this.processedMutations.clear();
  }
}

export const offlineMutationEngine = OfflineMutationEngine.getInstance();
