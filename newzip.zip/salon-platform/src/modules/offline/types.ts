export type OfflineOperationType =
  | 'START_SERVICE'
  | 'COMPLETE_SERVICE'
  | 'ADD_SERVICE_NOTE';

export interface OfflineMutationEnvelope {
  localMutationId: string;
  deviceId: string;
  tenantId: string;
  locationId: string;
  operation: OfflineOperationType;
  targetId: string; // queueEntryId or appointmentId
  payload: Record<string, unknown>;
  timestampIso: string;
  idempotencyKey: string;
}

export type SyncStatus = 'APPLIED' | 'CONFLICT' | 'REJECTED';

export interface MutationSyncResult {
  localMutationId: string;
  status: SyncStatus;
  message: string;
  processedAtIso: string;
}

export interface ReconnectionSyncResponse {
  totalSubmitted: number;
  appliedCount: number;
  conflictCount: number;
  rejectedCount: number;
  results: MutationSyncResult[];
}
