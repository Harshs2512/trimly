export type TenantStatus = 'ACTIVE' | 'SUSPENDED';

export interface TenantProvisionRequest {
  salonName: string;
  domain: string;
  ownerEmail: string;
  ownerName: string;
  ownerPhone: string;
  initialLocationName: string;
  initialLocationAddress: string;
}

export interface ProvisionedTenantResult {
  tenantId: string;
  locationId: string;
  ownerUserId: string;
  status: TenantStatus;
  createdAtIso: string;
}

export interface PlatformHealthStatus {
  totalTenants: number;
  activeTenants: number;
  suspendedTenants: number;
  systemStatus: 'HEALTHY' | 'DEGRADED' | 'MAINTENANCE';
  checkedAtIso: string;
}
