import {
  TenantProvisionRequest,
  ProvisionedTenantResult,
  TenantStatus,
  PlatformHealthStatus,
} from './types';
import { UserContext } from '../identity/types';
import { ForbiddenError, ValidationError } from '../../lib/errors';
import { createLogger } from '../../lib/logger';
import { identityStore } from '../identity/store';
import { masterDataStore } from '../masterdata/store';

const logger = createLogger('PlatformAdminService');

export class PlatformAdminService {
  public static getInstance(): PlatformAdminService {
    const g = globalThis as any;
    if (!g.__PLATFORM_ADMIN_SERVICE_SINGLETON__) {
      g.__PLATFORM_ADMIN_SERVICE_SINGLETON__ = new PlatformAdminService();
    }
    return g.__PLATFORM_ADMIN_SERVICE_SINGLETON__;
  }

  private tenantStatuses = new Map<string, TenantStatus>(); // tenantId -> TenantStatus

  private validatePlatformAdmin(actor: UserContext): void {
    if (actor.role !== 'PLATFORM_ADMIN') {
      logger.warn('Non-platform admin attempted restricted administrative action', {
        userId: actor.userId,
        role: actor.role,
      });
      throw new ForbiddenError('Only Platform Admins can perform this action.');
    }
  }

  public provisionTenant(actor: UserContext, request: TenantProvisionRequest): ProvisionedTenantResult {
    this.validatePlatformAdmin(actor);

    if (!request.salonName || !request.ownerEmail) {
      throw new ValidationError('Salon name and owner email are required for provisioning.');
    }

    const now = Date.now();
    const tenantId = `tenant-${now}-${Math.random().toString(36).substring(2, 6)}`;
    const locationId = `loc-${now}-${Math.random().toString(36).substring(2, 6)}`;
    const ownerUserId = `user-${now}-${Math.random().toString(36).substring(2, 6)}`;

    // Create Tenant Record
    identityStore.addTenant({
      id: tenantId,
      name: request.salonName,
      domain: request.domain || `${request.salonName.toLowerCase().replace(/\s+/g, '')}.trimly.app`,
      createdAt: new Date(now).toISOString(),
    });

    // Create Owner User
    identityStore.addUser({
      id: ownerUserId,
      tenantId,
      email: request.ownerEmail,
      name: request.ownerName,
      role: 'SALON_OWNER',
      locationIds: [locationId],
    });

    // Create Initial Location
    masterDataStore.addLocation({
      id: locationId,
      tenantId,
      name: request.initialLocationName,
      address: request.initialLocationAddress,
      timezone: 'America/New_York',
      operatingHours: Array.from({ length: 7 }, (_, day) => ({
        dayOfWeek: day,
        openTime: '09:00',
        closeTime: '18:00',
        isOpen: day !== 0,
      })),
      status: 'ACTIVE',
      createdAt: new Date(now).toISOString(),
    });

    this.tenantStatuses.set(tenantId, 'ACTIVE');

    logger.info('Provisioned new tenant successfully', {
      tenantId,
      locationId,
      ownerUserId,
      salonName: request.salonName,
    });

    return {
      tenantId,
      locationId,
      ownerUserId,
      status: 'ACTIVE',
      createdAtIso: new Date(now).toISOString(),
    };
  }

  public setTenantStatus(actor: UserContext, tenantId: string, status: TenantStatus): void {
    this.validatePlatformAdmin(actor);

    this.tenantStatuses.set(tenantId, status);
    logger.info('Updated tenant platform status', {
      tenantId,
      status,
      actorUserId: actor.userId,
    });
  }

  public getTenantStatus(tenantId: string): TenantStatus {
    return this.tenantStatuses.get(tenantId) || 'ACTIVE';
  }

  public getPlatformHealth(actor: UserContext): PlatformHealthStatus {
    this.validatePlatformAdmin(actor);

    let active = 0;
    let suspended = 0;

    for (const status of this.tenantStatuses.values()) {
      if (status === 'ACTIVE') active++;
      else if (status === 'SUSPENDED') suspended++;
    }

    const totalTenants = this.tenantStatuses.size || 1;

    return {
      totalTenants,
      activeTenants: active || totalTenants,
      suspendedTenants: suspended,
      systemStatus: 'HEALTHY',
      checkedAtIso: new Date().toISOString(),
    };
  }

  public clear(): void {
    this.tenantStatuses.clear();
  }
}

export const platformAdminService = PlatformAdminService.getInstance();
