export type QueueState =
  | 'WAITING'
  | 'APPROACHING'
  | 'CALLED'
  | 'CHECKED_IN'
  | 'IN_SERVICE'
  | 'COMPLETED'
  | 'CANCELLED'
  | 'EXPIRED'
  | 'NO_SHOW';

export interface QueueEntry {
  id: string;
  tenantId: string;
  locationId: string;
  customerId: string;
  customerName: string;
  customerPhone?: string;
  serviceId: string;
  preferredStaffId?: string;
  assignedStaffId?: string;
  joinedAt: string;
  updatedAt: string;
  state: QueueState;
  priority: number;
  ticketNumber: string;
  position?: number;
  estimatedStartIso?: string;
  lowerEtaBoundIso?: string;
  upperEtaBoundIso?: string;
  recommendedArrivalIso?: string;
  waitMinutesMin?: number;
  waitMinutesMax?: number;
  checkInGraceUntil?: string;
}

export interface QueueEvent {
  id: string;
  tenantId: string;
  locationId: string;
  queueEntryId: string;
  previousState: QueueState;
  newState: QueueState;
  actorId: string;
  occurredAt: string;
  reason?: string;
}

export interface JoinQueueInput {
  tenantId: string;
  locationId: string;
  customerId?: string;
  customerName: string;
  customerPhone?: string;
  serviceId: string;
  preferredStaffId?: string;
}
