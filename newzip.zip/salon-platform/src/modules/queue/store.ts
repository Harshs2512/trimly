import { QueueEntry, QueueEvent, QueueState, JoinQueueInput } from './types';
import { ValidationError } from '../../lib/errors';

const VALID_TRANSITIONS: Record<QueueState, QueueState[]> = {
  WAITING: ['APPROACHING', 'CALLED', 'CHECKED_IN', 'CANCELLED', 'EXPIRED'],
  APPROACHING: ['CALLED', 'CHECKED_IN', 'CANCELLED', 'EXPIRED', 'NO_SHOW'],
  CALLED: ['CHECKED_IN', 'IN_SERVICE', 'CANCELLED', 'EXPIRED', 'NO_SHOW'],
  CHECKED_IN: ['IN_SERVICE', 'CANCELLED', 'NO_SHOW'],
  IN_SERVICE: ['COMPLETED', 'CANCELLED'],
  COMPLETED: [],
  CANCELLED: [],
  EXPIRED: [],
  NO_SHOW: [],
};

class QueueStore {
  private entries: Map<string, QueueEntry> = new Map();
  private events: QueueEvent[] = [];
  private ticketCounters: Map<string, number> = new Map();

  create(input: JoinQueueInput): QueueEntry {
    const key = `${input.tenantId}:${input.locationId}`;
    const nextSeq = (this.ticketCounters.get(key) || 0) + 1;
    this.ticketCounters.set(key, nextSeq);

    const ticketNumber = `Q-${nextSeq.toString().padStart(3, '0')}`;
    const nowIso = new Date().toISOString();
    const id = `qentry-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;

    const entry: QueueEntry = {
      id,
      tenantId: input.tenantId,
      locationId: input.locationId,
      customerId: input.customerId || 'cust-anon',
      customerName: input.customerName,
      customerPhone: input.customerPhone,
      serviceId: input.serviceId,
      preferredStaffId: input.preferredStaffId,
      joinedAt: nowIso,
      updatedAt: nowIso,
      state: 'WAITING',
      priority: 1,
      ticketNumber,
    };

    this.entries.set(id, entry);

    // Initial audit event
    this.addEvent({
      id: `qevt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tenantId: input.tenantId,
      locationId: input.locationId,
      queueEntryId: id,
      previousState: 'WAITING',
      newState: 'WAITING',
      actorId: input.customerId || 'cust-anon',
      occurredAt: nowIso,
      reason: 'Joined Walk-In Queue',
    });

    return entry;
  }

  getById(id: string): QueueEntry | undefined {
    return this.entries.get(id);
  }

  listByLocation(tenantId: string, locationId: string): QueueEntry[] {
    return Array.from(this.entries.values()).filter(
      (e) => e.tenantId === tenantId && e.locationId === locationId
    );
  }

  listActiveByLocation(tenantId: string, locationId: string): QueueEntry[] {
    const activeStates: QueueState[] = ['WAITING', 'APPROACHING', 'CALLED', 'CHECKED_IN', 'IN_SERVICE'];
    return this.listByLocation(tenantId, locationId)
      .filter((e) => activeStates.includes(e.state))
      .sort((a, b) => new Date(a.joinedAt).getTime() - new Date(b.joinedAt).getTime());
  }

  transitionState(
    id: string,
    targetState: QueueState,
    actorId: string,
    reason?: string
  ): QueueEntry {
    const entry = this.entries.get(id);
    if (!entry) {
      throw new ValidationError(`Queue entry ${id} not found.`);
    }

    const allowed = VALID_TRANSITIONS[entry.state];
    if (!allowed.includes(targetState)) {
      throw new ValidationError(
        `Invalid state transition from ${entry.state} to ${targetState}.`
      );
    }

    const prevState = entry.state;
    const nowIso = new Date().toISOString();

    entry.state = targetState;
    entry.updatedAt = nowIso;

    if (targetState === 'CALLED') {
      // 10 minute grace window by default
      const graceMs = 10 * 60 * 1000;
      entry.checkInGraceUntil = new Date(Date.now() + graceMs).toISOString();
    }

    this.entries.set(id, entry);

    this.addEvent({
      id: `qevt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tenantId: entry.tenantId,
      locationId: entry.locationId,
      queueEntryId: id,
      previousState: prevState,
      newState: targetState,
      actorId,
      occurredAt: nowIso,
      reason,
    });

    return entry;
  }

  updateEtaFields(
    id: string,
    updates: Partial<Pick<QueueEntry, 'assignedStaffId' | 'position' | 'estimatedStartIso' | 'lowerEtaBoundIso' | 'upperEtaBoundIso' | 'recommendedArrivalIso' | 'waitMinutesMin' | 'waitMinutesMax'>>
  ): QueueEntry {
    const entry = this.entries.get(id);
    if (!entry) {
      throw new ValidationError(`Queue entry ${id} not found.`);
    }

    Object.assign(entry, updates);
    entry.updatedAt = new Date().toISOString();
    this.entries.set(id, entry);
    return entry;
  }

  addEvent(event: QueueEvent): void {
    this.events.push(event);
  }

  getEventsForEntry(queueEntryId: string): QueueEvent[] {
    return this.events.filter((e) => e.queueEntryId === queueEntryId);
  }

  clear(): void {
    this.entries.clear();
    this.events = [];
    this.ticketCounters.clear();
  }
}

export const queueStore = new QueueStore();
