import { queueStore } from './store';
import { QueueEntry, QueueEvent, QueueState, JoinQueueInput } from './types';
import { TenantIsolationError, AuthorizationError, ValidationError } from '../../lib/errors';
import { AuthActor } from '../identity/types';

export class QueueService {
  clear(): void {
    queueStore.clear();
  }
  joinQueue(actor: AuthActor, input: JoinQueueInput): QueueEntry {
    if (actor.tenantId !== input.tenantId) {
      throw new TenantIsolationError('Cannot join queue for another tenant.');
    }

    if (!input.customerName || !input.serviceId || !input.locationId) {
      throw new ValidationError('Customer name, service ID, and location ID are required.');
    }

    return queueStore.create(input);
  }

  transitionStatus(
    actor: AuthActor,
    queueEntryId: string,
    targetState: QueueState,
    reason?: string
  ): QueueEntry {
    const entry = queueStore.getById(queueEntryId);
    if (!entry) {
      throw new ValidationError(`Queue entry ${queueEntryId} not found.`);
    }

    if (actor.tenantId !== entry.tenantId) {
      throw new TenantIsolationError('Cross-tenant queue transition denied.');
    }

    // Role check: customer can CANCEL their own ticket; staff/admin/manager can transition any state
    const isPrivilegedRole = ['PLATFORM_ADMIN', 'SALON_OWNER', 'SALON_MANAGER', 'RECEPTIONIST', 'STAFF'].includes(actor.role);
    if (!isPrivilegedRole && targetState !== 'CANCELLED') {
      throw new AuthorizationError('Insufficient permissions for queue transition.');
    }

    return queueStore.transitionState(queueEntryId, targetState, actor.userId, reason);
  }

  getQueueForLocation(actor: AuthActor, locationId: string): QueueEntry[] {
    const entries = queueStore.listByLocation(actor.tenantId, locationId);
    return entries;
  }

  getActiveQueueForLocation(actor: AuthActor, locationId: string): QueueEntry[] {
    return queueStore.listActiveByLocation(actor.tenantId, locationId);
  }

  getEntryById(actor: AuthActor, id: string): QueueEntry {
    const entry = queueStore.getById(id);
    if (!entry) {
      throw new ValidationError(`Queue entry ${id} not found.`);
    }
    if (entry.tenantId !== actor.tenantId) {
      throw new TenantIsolationError('Cross-tenant queue entry access denied.');
    }
    return entry;
  }

  getEventHistory(actor: AuthActor, queueEntryId: string): QueueEvent[] {
    const entry = this.getEntryById(actor, queueEntryId);
    return queueStore.getEventsForEntry(entry.id);
  }
}

export const queueService = new QueueService();
