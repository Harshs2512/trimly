import { RealtimeEvent, ClientSubscription } from './types';
import { TenantIsolationError } from '../../lib/errors';
import { AuthActor } from '../identity/types';

class RealtimeBus {
  private subscriptions: Map<string, ClientSubscription> = new Map();

  subscribe(
    actor: AuthActor,
    clientId: string,
    locationId: string,
    callback: (event: RealtimeEvent) => void
  ): () => void {
    if (!actor.tenantId) {
      throw new TenantIsolationError('Tenant identity required for subscription.');
    }

    const subscription: ClientSubscription = {
      clientId,
      tenantId: actor.tenantId,
      locationId,
      callback,
    };

    this.subscriptions.set(clientId, subscription);

    return () => {
      this.subscriptions.delete(clientId);
    };
  }

  publish<T>(
    tenantId: string,
    locationId: string,
    topic: RealtimeEvent['topic'],
    payload: T
  ): RealtimeEvent<T> {
    const event: RealtimeEvent<T> = {
      id: `evt-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`,
      tenantId,
      locationId,
      topic,
      payload,
      timestampIso: new Date().toISOString(),
    };

    for (const sub of this.subscriptions.values()) {
      // STRICT TENANT & LOCATION ISOLATION CHECK
      if (sub.tenantId === tenantId && sub.locationId === locationId) {
        try {
          sub.callback(event);
        } catch (err) {
          console.error(`Error delivering realtime event to subscriber ${sub.clientId}:`, err);
        }
      }
    }

    return event;
  }

  getActiveSubscriberCount(tenantId?: string, locationId?: string): number {
    if (!tenantId) return this.subscriptions.size;
    return Array.from(this.subscriptions.values()).filter(
      (sub) => sub.tenantId === tenantId && (!locationId || sub.locationId === locationId)
    ).length;
  }

  clear(): void {
    this.subscriptions.clear();
  }
}

export const realtimeBus = new RealtimeBus();
