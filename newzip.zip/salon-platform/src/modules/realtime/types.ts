export interface RealtimeEvent<T = any> {
  id: string;
  tenantId: string;
  locationId: string;
  topic: 'queue:updated' | 'eta:updated' | 'appointment:updated' | 'notification:sent';
  payload: T;
  timestampIso: string;
}

export interface ClientSubscription {
  clientId: string;
  tenantId: string;
  locationId: string;
  callback: (event: RealtimeEvent) => void;
}
