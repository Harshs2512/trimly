import { CorrelationContext, HealthProbeStatus } from './types';
import { createLogger } from '../../lib/logger';
import { realtimeBus } from '../realtime/bus';

const logger = createLogger('ObservabilityService');
const startTime = Date.now();

export class ObservabilityService {
  public static getInstance(): ObservabilityService {
    const g = globalThis as any;
    if (!g.__OBSERVABILITY_SERVICE_SINGLETON__) {
      g.__OBSERVABILITY_SERVICE_SINGLETON__ = new ObservabilityService();
    }
    return g.__OBSERVABILITY_SERVICE_SINGLETON__;
  }

  public createCorrelationContext(headerCorrelationId?: string): CorrelationContext {
    const correlationId =
      headerCorrelationId || `corr-${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
    return {
      correlationId,
      createdAtIso: new Date().toISOString(),
    };
  }

  public getHealthProbe(): HealthProbeStatus {
    const uptimeSeconds = Math.floor((Date.now() - startTime) / 1000);
    const activeSubscribers = realtimeBus.getActiveSubscriberCount();

    const status: HealthProbeStatus = {
      status: 'UP',
      uptimeSeconds,
      databaseStoreStatus: 'HEALTHY',
      activeWebSocketsCount: activeSubscribers,
      queueLagCount: 0,
      checkedAtIso: new Date().toISOString(),
    };

    logger.info('Generated system health probe', { status: status.status, uptimeSeconds });
    return status;
  }
}

export const observabilityService = ObservabilityService.getInstance();
