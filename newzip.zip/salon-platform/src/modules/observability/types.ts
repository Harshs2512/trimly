export interface CorrelationContext {
  correlationId: string;
  tenantId?: string;
  createdAtIso: string;
}

export interface HealthProbeStatus {
  status: 'UP' | 'DEGRADED' | 'DOWN';
  uptimeSeconds: number;
  databaseStoreStatus: 'HEALTHY' | 'UNHEALTHY';
  activeWebSocketsCount: number;
  queueLagCount: number;
  checkedAtIso: string;
}
