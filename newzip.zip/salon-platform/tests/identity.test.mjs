import test from 'node:test';
import assert from 'node:assert';
import { identityService } from '../src/modules/identity/service.ts';
import { identityStore } from '../src/modules/identity/store.ts';
import { logAuditEvent, getAuditLogsForTenant } from '../src/modules/identity/audit.ts';
import { TenantIsolationError, ForbiddenError, UnauthorizedError } from '../src/lib/errors.ts';

test('Identity Service Token Generation and Verification', () => {
  const ownerA = identityStore.getUserByEmail('owner@downtownbarber.com');
  assert.ok(ownerA);

  const token = identityService.generateToken(ownerA);
  assert.ok(typeof token === 'string');

  const context = identityService.verifyToken(token);
  assert.strictEqual(context.userId, 'user-owner-a');
  assert.strictEqual(context.tenantId, 'tenant-a-111');
  assert.strictEqual(context.role, 'SALON_OWNER');
});

test('Tenant Isolation Violation Throws TenantIsolationError', () => {
  const contextA = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  // Same tenant access passes cleanly
  assert.doesNotThrow(() => {
    identityService.validateTenantAccess(contextA, 'tenant-a-111');
  });

  // Cross-tenant access MUST throw TenantIsolationError (IDOR Prevention)
  assert.throws(
    () => {
      identityService.validateTenantAccess(contextA, 'tenant-b-222');
    },
    { name: 'TenantIsolationError' }
  );
});

test('Role-Based Access Control (RBAC) Enforcement', () => {
  const staffContext = {
    userId: 'user-staff-a',
    tenantId: 'tenant-a-111',
    role: 'STAFF',
    locationIds: ['loc-a-1'],
  };

  // Staff requires STAFF or higher -> Pass
  assert.doesNotThrow(() => {
    identityService.validateMinimumRole(staffContext, 'STAFF');
  });

  // Staff requires SALON_OWNER privileges -> MUST throw ForbiddenError
  assert.throws(
    () => {
      identityService.validateMinimumRole(staffContext, 'SALON_OWNER');
    },
    { name: 'ForbiddenError' }
  );
});

test('Audit Logging Stores Immutable Security Record', () => {
  const userContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  const audit = logAuditEvent(userContext, 'MANUAL_OVERRIDE', 'queue/entry-123', {
    reason: 'Customer requested delayed slot',
  });

  assert.ok(audit.id);
  assert.strictEqual(audit.tenantId, 'tenant-a-111');
  assert.strictEqual(audit.actorId, 'user-owner-a');
  assert.strictEqual(audit.action, 'MANUAL_OVERRIDE');

  const logs = getAuditLogsForTenant('tenant-a-111');
  assert.ok(logs.some((l) => l.id === audit.id));
});
