import test from 'node:test';
import assert from 'node:assert';
import { checkInService } from '../src/modules/checkin/service.ts';
import { platformAdminService } from '../src/modules/admin/service.ts';
import { analyticsEngine } from '../src/modules/analytics/service.ts';
import { queueService } from '../src/modules/queue/service.ts';
import { bookingService } from '../src/modules/booking/service.ts';
import { ForbiddenError, TenantIsolationError, ValidationError } from '../src/lib/errors.ts';

test('QR and Kiosk Check-In: Token generation, PIN entry, QR scanning, and state transition', async () => {
  checkInService.clear();
  queueService.clear();

  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Join queue
  const queueEntry = queueService.joinQueue(ownerContext, {
    tenantId: 'tenant-a-111',
    locationId: 'loc-downtown',
    customerName: 'CheckIn Customer Bob',
    customerPhone: '+15551122',
    serviceId: 'srv-haircut-standard',
  });

  // 2. Generate Check-In Token
  const token = checkInService.generateCheckInToken(
    'tenant-a-111',
    'loc-downtown',
    queueEntry.id,
    'QUEUE_ENTRY'
  );

  assert.ok(token.pinCode);
  assert.ok(token.qrCodeData);
  assert.strictEqual(token.pinCode.length, 4);

  // 3. Perform Check-In via PIN code
  const pinResult = checkInService.checkInViaPin('tenant-a-111', 'loc-downtown', token.pinCode);
  assert.strictEqual(pinResult.success, true);
  assert.strictEqual(pinResult.targetId, queueEntry.id);

  const updatedEntry = queueService.getEntryById(ownerContext, queueEntry.id);
  assert.strictEqual(updatedEntry.state, 'CHECKED_IN');

  // 4. Invalid PIN and Cross-Tenant Rejection
  assert.throws(() => {
    checkInService.checkInViaPin('tenant-a-111', 'loc-downtown', '9999');
  }, (err) => err.code === 'VALIDATION_ERROR' || err.name === 'ValidationError');

  assert.throws(() => {
    checkInService.checkInViaQr('tenant-b-222', 'loc-downtown', token.qrCodeData);
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');
});

test('Platform Admin Service: Tenant provisioning, RBAC protection, and health monitoring', async () => {
  platformAdminService.clear();

  const platformAdminActor = {
    userId: 'user-admin-root',
    tenantId: 'platform-root',
    role: 'PLATFORM_ADMIN',
  };

  const salonOwnerActor = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Non-admin attempting provisioning MUST throw ForbiddenError
  assert.throws(() => {
    platformAdminService.provisionTenant(salonOwnerActor, {
      salonName: 'Unauthorized Salon',
      domain: 'unauth.app',
      ownerEmail: 'hacker@test.com',
      ownerName: 'Evil Hack',
      ownerPhone: '+15550000',
      initialLocationName: 'Hack Loc',
      initialLocationAddress: '123 Fake St',
    });
  }, (err) => err.code === 'FORBIDDEN' || err.name === 'ForbiddenError');

  // 2. Platform Admin provisions new tenant successfully
  const provisionResult = platformAdminService.provisionTenant(platformAdminActor, {
    salonName: 'Metro Barber Lounge',
    domain: 'metrobarber.trimly.app',
    ownerEmail: 'owner@metrobarber.com',
    ownerName: 'Marcus Vance',
    ownerPhone: '+15558899',
    initialLocationName: 'Metro Downtown',
    initialLocationAddress: '500 Main Street',
  });

  assert.ok(provisionResult.tenantId);
  assert.ok(provisionResult.locationId);
  assert.ok(provisionResult.ownerUserId);
  assert.strictEqual(provisionResult.status, 'ACTIVE');

  // 3. Platform Admin updates tenant status and checks platform health
  platformAdminService.setTenantStatus(platformAdminActor, provisionResult.tenantId, 'SUSPENDED');
  assert.strictEqual(platformAdminService.getTenantStatus(provisionResult.tenantId), 'SUSPENDED');

  const health = platformAdminService.getPlatformHealth(platformAdminActor);
  assert.strictEqual(health.systemStatus, 'HEALTHY');
  assert.ok(health.totalTenants >= 1);
});

test('Analytics Engine: Operational delay metrics, utilization, ETA accuracy, and privacy preservation', async () => {
  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Generate operational analytics report
  const metrics = analyticsEngine.generateOperationalAnalytics(ownerContext, 'loc-a-1', 'TODAY');

  assert.strictEqual(metrics.tenantId, 'tenant-a-111');
  assert.strictEqual(metrics.locationId, 'loc-a-1');
  assert.ok(typeof metrics.delays.averageTotalWaitMinutes === 'number');
  assert.ok(typeof metrics.utilization.utilizationPercentage === 'number');
  assert.strictEqual(metrics.etaAccuracy.accuracyGrade, 'HIGH');

  // 2. Tenant isolation check (cross-tenant access denied)
  assert.throws(() => {
    analyticsEngine.generateOperationalAnalytics(
      { userId: 'user-b', tenantId: 'tenant-b-222', role: 'SALON_OWNER' },
      'loc-a-1',
      'TODAY'
    );
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');

  // 3. Pseudonymized Customer Analytics (Privacy compliance)
  const privacyRecord = analyticsEngine.getPseudonymizedCustomerRecord(ownerContext, '+15559876');
  assert.ok(privacyRecord.customerHash);
  assert.ok(!privacyRecord.customerHash.includes('+15559876'), 'Plain phone number must NOT be in customerHash');
});
