import test from 'node:test';
import assert from 'node:assert';
import { queueService } from '../src/modules/queue/service.ts';
import { queueStore } from '../src/modules/queue/store.ts';
import { etaService } from '../src/modules/eta/service.ts';
import { dispatchEngine } from '../src/modules/eta/dispatch.ts';
import { realtimeBus } from '../src/modules/realtime/bus.ts';
import { masterDataService } from '../src/modules/masterdata/service.ts';
import { bookingService } from '../src/modules/booking/service.ts';
import { ValidationError, TenantIsolationError, AuthorizationError } from '../src/lib/errors.ts';

const staffActor = {
  userId: 'user-manager-1',
  tenantId: 'tenant-salon-101',
  role: 'SALON_MANAGER',
  locationIds: ['loc-downtown'],
};

const customerActor = {
  userId: 'cust-john-777',
  tenantId: 'tenant-salon-101',
  role: 'CUSTOMER',
  locationIds: ['loc-downtown'],
};

test.beforeEach(() => {
  queueService.clear();
  masterDataService.clear();
  bookingService.clear();
  realtimeBus.clear();

  // Setup seed data
  masterDataService.createLocation(staffActor, {
    id: 'loc-downtown',
    name: 'Downtown Location',
    address: '123 Main St',
    timezone: 'UTC',
  });

  masterDataService.createService(staffActor, {
    id: 'srv-1',
    name: 'Haircut',
    durationMinutes: 30,
    priceCents: 3500,
    requiredSkills: ['HAIRCUT'],
  });

  masterDataService.createStaff(staffActor, {
    userId: 'staff-sam-id',
    name: 'Sam Barber',
    serviceIds: ['srv-1'],
    skills: ['HAIRCUT'],
    isActive: true,
    locationIds: ['loc-downtown'],
  });
});

test('Virtual Queue: Customer joins queue and receives ticket number', () => {
  const entry = queueService.joinQueue(customerActor, {
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    customerId: 'cust-john-777',
    customerName: 'John Doe',
    serviceId: 'srv-1',
  });

  assert.ok(entry.id);
  assert.strictEqual(entry.state, 'WAITING');
  assert.ok(entry.ticketNumber.startsWith('Q-'));
  assert.strictEqual(entry.customerName, 'John Doe');
});

test('Queue State Machine: Enforces valid transition graph and rejects invalid ones', () => {
  const entry = queueService.joinQueue(customerActor, {
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    customerId: 'cust-john-777',
    customerName: 'John Doe',
    serviceId: 'srv-1',
  });

  // Valid: WAITING -> CALLED
  const calledEntry = queueService.transitionStatus(staffActor, entry.id, 'CALLED', 'Staff called customer');
  assert.strictEqual(calledEntry.state, 'CALLED');
  assert.ok(calledEntry.checkInGraceUntil);

  // Valid: CALLED -> CHECKED_IN
  const checkedInEntry = queueService.transitionStatus(staffActor, entry.id, 'CHECKED_IN');
  assert.strictEqual(checkedInEntry.state, 'CHECKED_IN');

  // Invalid: CHECKED_IN -> WAITING (Must throw ValidationError)
  assert.throws(
    () => {
      queueService.transitionStatus(staffActor, entry.id, 'WAITING');
    },
    { name: 'ValidationError' }
  );
});

test('Queue Audit Trail: Records append-only events for all transitions', () => {
  const entry = queueService.joinQueue(customerActor, {
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    customerId: 'cust-john-777',
    customerName: 'John Doe',
    serviceId: 'srv-1',
  });

  queueService.transitionStatus(staffActor, entry.id, 'CALLED', 'Called to chair');
  queueService.transitionStatus(staffActor, entry.id, 'CHECKED_IN');
  queueService.transitionStatus(staffActor, entry.id, 'IN_SERVICE');
  queueService.transitionStatus(staffActor, entry.id, 'COMPLETED');

  const history = queueService.getEventHistory(staffActor, entry.id);
  assert.strictEqual(history.length, 5); // 1 initial + 4 transitions
  assert.strictEqual(history[history.length - 1].newState, 'COMPLETED');
});

test('ETA Engine V1: Calculates explainable range results and recommended arrival', () => {
  const entry = queueService.joinQueue(customerActor, {
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    customerId: 'cust-john-777',
    customerName: 'John Doe',
    serviceId: 'srv-1',
  });

  const eta = etaService.getEtaForEntry(customerActor, entry.id);

  assert.strictEqual(eta.queueEntryId, entry.id);
  assert.strictEqual(eta.modelVersion, 'V1.0-DETERMINISTIC');
  assert.ok(eta.predictedStartIso);
  assert.ok(eta.lowerEtaBoundIso);
  assert.ok(eta.upperEtaBoundIso);
  assert.ok(eta.recommendedArrivalIso);
  assert.ok(eta.waitMinutesMax >= eta.waitMinutesMin);
});

test('Dispatch Engine: Protects booked appointments from walk-in overlap', () => {
  queueService.clear();
  const nowMs = Date.now();

  // Create a confirmed scheduled appointment for Sam Barber in 10 minutes
  const aptStartIso = new Date(nowMs + 10 * 60 * 1000).toISOString();
  const aptEndIso = new Date(nowMs + 40 * 60 * 1000).toISOString();

  bookingService.createAppointment({
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    holdId: 'hold-123',
    serviceId: 'srv-1',
    staffId: 'staff-sam-id',
    customerName: 'Scheduled Alice',
    customerPhone: '+15559998888',
    startIso: aptStartIso,
    endIso: aptEndIso,
    idempotencyKey: 'idem-alice-1',
  });

  // Customer joins walk-in queue needing 30 min service
  const entry = queueService.joinQueue(customerActor, {
    tenantId: 'tenant-salon-101',
    locationId: 'loc-downtown',
    customerId: 'cust-walkin-bob',
    customerName: 'Walk-In Bob',
    serviceId: 'srv-1',
    preferredStaffId: 'staff-sam-id',
  });

  const assignments = dispatchEngine.calculateDispatch('tenant-salon-101', 'loc-downtown');
  assert.strictEqual(assignments.length, 1);

  const bobAssignment = assignments[0];
  const bobStartMs = new Date(bobAssignment.assignedStartIso).getTime();
  const aliceEndMs = new Date(aptEndIso).getTime();

  // Walk-in Bob MUST be scheduled AFTER Alice's booked appointment finishes
  assert.ok(
    bobStartMs >= aliceEndMs,
    `Walk-in start (${new Date(bobStartMs).toISOString()}) must be >= booked appointment end (${aptEndIso})`
  );
});

test('Realtime Infrastructure: Enforces strict tenant and location subscriber isolation', () => {
  let receivedEventsTenant1 = 0;
  let receivedEventsTenant2 = 0;

  // Subscriber for Tenant 101, Downtown
  realtimeBus.subscribe(staffActor, 'client-sub-1', 'loc-downtown', () => {
    receivedEventsTenant1++;
  });

  // Subscriber for Tenant 202, Location B
  const otherActor = {
    userId: 'user-other',
    tenantId: 'tenant-salon-202',
    role: 'SALON_MANAGER',
    locationIds: ['loc-b'],
  };
  realtimeBus.subscribe(otherActor, 'client-sub-2', 'loc-b', () => {
    receivedEventsTenant2++;
  });

  // Publish event for Tenant 101, Downtown
  realtimeBus.publish('tenant-salon-101', 'loc-downtown', 'queue:updated', { test: true });

  assert.strictEqual(receivedEventsTenant1, 1);
  assert.strictEqual(receivedEventsTenant2, 0); // Tenant 202 MUST NOT receive Tenant 101 events!
});
