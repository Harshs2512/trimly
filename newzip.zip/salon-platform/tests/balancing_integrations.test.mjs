import test from 'node:test';
import assert from 'node:assert';
import { multiLocationBalancingEngine } from '../src/modules/balancing/service';
import { externalIntegrationEngine } from '../src/modules/integrations/service';

test('Multi-Location Balancing Engine (Phase 25): Cross-branch load balancing & net time savings recommendation', async () => {
  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  // 1. Generate Multi-Location Load Balancing Report
  const report = multiLocationBalancingEngine.recommendNearbyLocations(ownerContext, 'loc-a-1');

  assert.strictEqual(report.tenantId, 'tenant-a-111');
  assert.strictEqual(report.primaryLocationId, 'loc-a-1');
  assert.ok(Array.isArray(report.recommendations));

  // 2. Cross-tenant access throws TenantIsolationError
  assert.throws(() => {
    multiLocationBalancingEngine.recommendNearbyLocations(
      { userId: 'user-b', tenantId: 'tenant-b-222', role: 'SALON_OWNER', locationIds: ['loc-b-1'] },
      'loc-a-1'
    );
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');
});

test('Advanced External Integrations Engine (Phase 26): POS transaction sync and HMAC-signed webhook dispatch', async () => {
  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  // 1. Sync to POS
  const posRes = externalIntegrationEngine.syncToPos(ownerContext, {
    tenantId: 'tenant-a-111',
    locationId: 'loc-a-1',
    appointmentId: 'apt-101',
    customerName: 'Pos Customer',
    totalAmount: 45.0,
    paymentStatus: 'PAID',
  });

  assert.strictEqual(posRes.status, 'SYNCED');
  assert.ok(posRes.posReference.startsWith('pos_ref_'));

  // 2. Dispatch HMAC Webhook
  const webhookRes = externalIntegrationEngine.dispatchWebhook(ownerContext, {
    tenantId: 'tenant-a-111',
    eventType: 'appointment.completed',
    payload: { appointmentId: 'apt-101', amount: 45.0 },
    targetUrl: 'https://webhook.externalpos.com/events',
    secretKey: 'my_wh_secret_key_123',
  });

  assert.strictEqual(webhookRes.statusCode, 200);
  assert.strictEqual(webhookRes.success, true);
  assert.ok(webhookRes.signature.startsWith('sha256='));

  // 3. Cross-tenant POS sync throws TenantIsolationError
  assert.throws(() => {
    externalIntegrationEngine.syncToPos(
      { userId: 'user-b', tenantId: 'tenant-b-222', role: 'SALON_OWNER', locationIds: ['loc-b-1'] },
      {
        tenantId: 'tenant-a-111',
        locationId: 'loc-a-1',
        appointmentId: 'apt-101',
        customerName: 'Unauthorized Customer',
        totalAmount: 45.0,
        paymentStatus: 'PAID',
      }
    );
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');
});
