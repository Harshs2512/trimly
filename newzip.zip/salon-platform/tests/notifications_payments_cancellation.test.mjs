import test from 'node:test';
import assert from 'node:assert';
import { notificationService } from '../src/modules/notifications/service.ts';
import { paymentService } from '../src/modules/payments/service.ts';
import { bookingService } from '../src/modules/booking/service.ts';
import { queueService } from '../src/modules/queue/service.ts';
import { TenantIsolationError } from '../src/lib/errors.ts';

test('Notification Service: Multi-channel dispatch and deduplication', async () => {
  notificationService.clearLogs();

  // 1. Dispatch SMS Notification
  const smsResult = await notificationService.dispatchNotification({
    tenantId: 'tenant-a-111',
    recipient: '+15550199',
    channel: 'SMS',
    template: 'APPOINTMENT_CONFIRMED',
    deduplicationKey: 'dedup-key-1',
    data: { appointmentId: 'apt-101' },
  });

  assert.strictEqual(smsResult.status, 'SENT');
  assert.strictEqual(smsResult.channel, 'SMS');

  // 2. Dispatch Duplicate Notification within cooldown
  const dupResult = await notificationService.dispatchNotification({
    tenantId: 'tenant-a-111',
    recipient: '+15550199',
    channel: 'SMS',
    template: 'APPOINTMENT_CONFIRMED',
    deduplicationKey: 'dedup-key-1',
    data: { appointmentId: 'apt-101' },
  });

  assert.strictEqual(dupResult.status, 'DEDUPLICATED');

  // 3. Tenant Isolation Check
  assert.throws(() => {
    notificationService.getTenantNotificationLogs('tenant-b-222', 'tenant-a-111');
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');

  const logs = notificationService.getTenantNotificationLogs('tenant-a-111', 'tenant-a-111');
  assert.strictEqual(logs.length, 2);
});

test('Payment Service: Tokenized charge, idempotency, webhook reconciliation, and refunds', async () => {
  paymentService.clear();

  // 1. Tokenized Charge
  const request = {
    tenantId: 'tenant-a-111',
    appointmentId: 'apt-202',
    amount: 45.0,
    currency: 'USD',
    processorToken: 'tok_visa_valid',
    policy: 'FULL_PREPAYMENT',
    idempotencyKey: 'idem-pay-202',
  };

  const chargeResult = await paymentService.processTokenizedPayment(request);
  assert.strictEqual(chargeResult.status, 'SUCCEEDED');
  assert.strictEqual(chargeResult.amountCharged, 45.0);

  // 2. Idempotency Check (second attempt with same key returns identical result)
  const dupChargeResult = await paymentService.processTokenizedPayment(request);
  assert.strictEqual(dupChargeResult.paymentId, chargeResult.paymentId);
  assert.strictEqual(dupChargeResult.status, 'SUCCEEDED');

  // 3. Webhook Signature Verification and Replay Protection
  const webhookSecret = 'whsec_test_secret_123';
  const webhookPayload = {
    id: 'evt_wh_001',
    event: 'charge.updated',
    signature: 'valid_test_signature',
    data: {
      processorReference: chargeResult.processorReference,
      appointmentId: 'apt-202',
      tenantId: 'tenant-a-111',
      amount: 45.0,
      status: 'SUCCEEDED',
    },
  };

  const whRes = paymentService.processWebhook(webhookPayload, webhookSecret);
  assert.strictEqual(whRes.success, true);

  // Replay attempt should be ignored safely
  const replayWhRes = paymentService.processWebhook(webhookPayload, webhookSecret);
  assert.strictEqual(replayWhRes.success, true);
  assert.strictEqual(replayWhRes.message, 'Event already processed');

  // Invalid signature attempt
  const badSigWhRes = paymentService.processWebhook(
    { ...webhookPayload, id: 'evt_wh_002', signature: 'invalid_sig' },
    webhookSecret
  );
  assert.strictEqual(badSigWhRes.success, false);

  // 4. Refund Payment & Tenant Isolation Check
  await assert.rejects(async () => {
    await paymentService.refundPayment('tenant-b-222', chargeResult.paymentId, 45.0);
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');

  const refunded = await paymentService.refundPayment('tenant-a-111', chargeResult.paymentId, 45.0);
  assert.strictEqual(refunded.status, 'REFUNDED');
});

test('Booking Engine: Cancellation, refund policy, rescheduling, and waitlist refill engine', async () => {
  bookingService.clear();
  queueService.clear();
  notificationService.clearLogs();

  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Create a waiting queue entry (customer waitlisted)
  const queueTicket = queueService.joinQueue(ownerContext, {
    tenantId: 'tenant-a-111',
    locationId: 'loc-downtown',
    customerName: 'Waitlist Customer Jane',
    customerPhone: '+15559876',
    serviceId: 'srv-haircut-standard',
  });

  assert.strictEqual(queueTicket.state, 'WAITING');

  // 2. Acquire hold and confirm an appointment 5 hours in future
  const futureStart = new Date(Date.now() + 5 * 3600 * 1000).toISOString();
  const futureEnd = new Date(Date.now() + 6 * 3600 * 1000).toISOString();

  const hold = bookingService.acquireHold(
    ownerContext,
    'loc-downtown',
    'srv-haircut-standard',
    'staff-sam',
    futureStart,
    futureEnd
  );

  const apt = await bookingService.confirmAppointment(
    ownerContext,
    hold.id,
    'Booked Customer Bob',
    '+15551234',
    'idem-cancel-test-1'
  );

  assert.strictEqual(apt.status, 'CONFIRMED');

  // 3. Cancel Appointment (>2 hours notice -> refund eligible)
  const cancelResult = await bookingService.cancelAppointment(ownerContext, apt.id, 'Customer changed plans');

  assert.strictEqual(cancelResult.appointment.status, 'CANCELLED');
  assert.strictEqual(cancelResult.refundEligible, true);
  assert.strictEqual(cancelResult.refundPercentage, 100);

  // 4. Verify Waitlist Refill Engine triggered notification to waiting customer Jane
  const notifLogs = notificationService.getTenantNotificationLogs('tenant-a-111', 'tenant-a-111');
  const waitlistNotif = notifLogs.find((n) => n.template === 'WAITLIST_OPENING');

  assert.ok(waitlistNotif, 'Waitlist opening notification should be dispatched');
  assert.strictEqual(waitlistNotif.recipient, '+15559876');

  // 5. Test Rescheduling Appointment
  const apt2Hold = bookingService.acquireHold(
    ownerContext,
    'loc-downtown',
    'srv-haircut-standard',
    'staff-sam',
    futureStart,
    futureEnd
  );

  const apt2 = await bookingService.confirmAppointment(
    ownerContext,
    apt2Hold.id,
    'Reschedule Customer Alice',
    '+15554321',
    'idem-resched-test-2'
  );

  const newStart = new Date(Date.now() + 10 * 3600 * 1000).toISOString();
  const newEnd = new Date(Date.now() + 11 * 3600 * 1000).toISOString();

  const newHold = bookingService.acquireHold(
    ownerContext,
    'loc-downtown',
    'srv-haircut-standard',
    'staff-sam',
    newStart,
    newEnd
  );

  const rescheduledApt = await bookingService.rescheduleAppointment(
    ownerContext,
    apt2.id,
    newHold.id,
    'idem-resched-action'
  );

  assert.strictEqual(rescheduledApt.status, 'CONFIRMED');
  assert.strictEqual(rescheduledApt.startTime, newStart);
});
