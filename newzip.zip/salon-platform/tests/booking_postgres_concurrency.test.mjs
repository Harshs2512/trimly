import test from 'node:test';
import assert from 'node:assert';
import { bookingStore } from '../src/modules/booking/store.ts';

test('PostgreSQL Concurrency & Exclusion Constraint Verification (Phase 06b)', async () => {
  const isPgUp = await bookingStore.checkPgHealth();
  if (!isPgUp) {
    // If PostgreSQL container is not active in this local environment, explicitly flag as NOT FOUND / UNKNOWN
    console.log('⚠️ PostgreSQL DB connection NOT FOUND / UNKNOWN in local runner environment. Skipping live DB test gracefully.');
    assert.ok(true, 'Skipped live DB test when PostgreSQL container is offline');
    return;
  }

  const pool = bookingStore.getPool();
  assert.ok(pool, 'PostgreSQL pool must be initialized when PostgreSQL is UP');

  // Setup test parameters
  const tenantId = 'tenant-pg-test';
  const locationId = 'loc-pg-test';
  const staffId = 'staff-pg-concurrency';
  const serviceId = 'srv-pg-cut';
  const startTimeIso = '2026-08-25T10:00:00.000Z';
  const endTimeIso = '2026-08-25T10:30:00.000Z';

  const client1 = await pool.connect();
  const client2 = await pool.connect();

  try {
    // Fire 2 simultaneous confirmation attempts against PostgreSQL for the SAME capacity interval
    const p1 = bookingStore.confirmAppointmentPg(client1, {
      appointmentId: 'apt-pg-concurrent-1',
      tenantId,
      locationId,
      holdId: 'hold-1',
      customerId: 'cust-1',
      customerName: 'Customer One',
      customerPhone: '+15550001',
      staffId,
      serviceId,
      startTimeIso,
      endTimeIso,
      idempotencyKey: 'idem-pg-1',
    });

    const p2 = bookingStore.confirmAppointmentPg(client2, {
      appointmentId: 'apt-pg-concurrent-2',
      tenantId,
      locationId,
      holdId: 'hold-2',
      customerId: 'cust-2',
      customerName: 'Customer Two',
      customerPhone: '+15550002',
      staffId,
      serviceId,
      startTimeIso,
      endTimeIso,
      idempotencyKey: 'idem-pg-2',
    });

    const results = await Promise.allSettled([p1, p2]);

    const fulfilled = results.filter(r => r.status === 'fulfilled');
    const rejected = results.filter(r => r.status === 'rejected');

    assert.strictEqual(fulfilled.length, 1, 'Exactly one concurrent booking request must succeed');
    assert.strictEqual(rejected.length, 1, 'Exactly one concurrent booking request must fail with CapacityConcurrencyError');

    const error = rejected[0].reason;
    assert.strictEqual(error.code, 'CAPACITY_CONCURRENCY_CONFLICT');
  } finally {
    client1.release();
    client2.release();
  }
});
