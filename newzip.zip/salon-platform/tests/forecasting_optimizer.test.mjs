import test from 'node:test';
import assert from 'node:assert';
import { demandForecastingEngine } from '../src/modules/forecasting/service.ts';
import { staffingOptimizerEngine } from '../src/modules/optimizer/service.ts';

test('Demand Forecasting Engine (Phase 23): Hourly predictions, peak hour detection, and risk grading', async () => {
  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Generate Demand Forecast
  const forecast = demandForecastingEngine.generateDemandForecast(ownerContext, 'loc-a-1', '2026-08-20');

  assert.strictEqual(forecast.tenantId, 'tenant-a-111');
  assert.strictEqual(forecast.locationId, 'loc-a-1');
  assert.ok(forecast.hourlyForecasts.length > 0);
  assert.ok(forecast.totalPredictedVolume > 0);
  assert.ok(forecast.peakHours.includes('11:00'));

  // 2. Cross-tenant access throws TenantIsolationError
  assert.throws(() => {
    demandForecastingEngine.generateDemandForecast(
      { userId: 'user-b', tenantId: 'tenant-b-222', role: 'SALON_OWNER' },
      'loc-a-1',
      '2026-08-20'
    );
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');
});

test('Staffing Optimizer Engine (Phase 24): Shift roster recommendations and wait-time reduction metrics', async () => {
  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Generate Staffing Optimization Report
  const report = staffingOptimizerEngine.generateOptimizationReport(ownerContext, 'loc-a-1', '2026-08-20');

  assert.strictEqual(report.tenantId, 'tenant-a-111');
  assert.strictEqual(report.locationId, 'loc-a-1');
  assert.ok(report.recommendations.length > 0);
  assert.ok(report.optimalRosterCount >= 1);
  assert.ok(report.expectedWaitTimeReductionMin > 0);

  // 2. Cross-tenant access throws TenantIsolationError
  assert.throws(() => {
    staffingOptimizerEngine.generateOptimizationReport(
      { userId: 'user-b', tenantId: 'tenant-b-222', role: 'SALON_OWNER' },
      'loc-a-1',
      '2026-08-20'
    );
  }, (err) => err.code === 'TENANT_ISOLATION_VIOLATION' || err.name === 'TenantIsolationError');
});
