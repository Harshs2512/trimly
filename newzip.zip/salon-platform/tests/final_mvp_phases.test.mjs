import test from 'node:test';
import assert from 'node:assert';
import { offlineMutationEngine } from '../src/modules/offline/service.ts';
import { securityService } from '../src/modules/security/service.ts';
import { observabilityService } from '../src/modules/observability/service.ts';
import { MvpReadinessAuditor } from '../src/modules/audit/mvp_audit.ts';
import { queueService } from '../src/modules/queue/service.ts';

test('Offline Staff Operations: Queueing local mutations and reconnection sync with conflict handling', async () => {
  offlineMutationEngine.clear();
  queueService.clear();

  const staffContext = {
    userId: 'user-staff-sam',
    tenantId: 'tenant-a-111',
    role: 'STAFF',
  };

  // 1. Setup active checked-in customer
  const entry = queueService.joinQueue(staffContext, {
    tenantId: 'tenant-a-111',
    locationId: 'loc-a-1',
    customerName: 'Offline Test Customer',
    customerPhone: '+15554433',
    serviceId: 'srv-haircut',
  });
  queueService.transitionStatus(staffContext, entry.id, 'CHECKED_IN', 'Ready for haircut');

  // 2. Submit queued offline mutations
  const syncResponse = offlineMutationEngine.syncOfflineMutations(staffContext, [
    {
      localMutationId: 'mut-offline-01',
      deviceId: 'ipad-reception-01',
      tenantId: 'tenant-a-111',
      locationId: 'loc-a-1',
      operation: 'START_SERVICE',
      targetId: entry.id,
      payload: {},
      timestampIso: new Date().toISOString(),
      idempotencyKey: 'idem-mut-01',
    },
    {
      localMutationId: 'mut-offline-02',
      deviceId: 'ipad-reception-01',
      tenantId: 'tenant-a-111',
      locationId: 'loc-a-1',
      operation: 'ADD_SERVICE_NOTE',
      targetId: entry.id,
      payload: { note: 'Customer prefers skin fade' },
      timestampIso: new Date().toISOString(),
      idempotencyKey: 'idem-mut-02',
    },
  ]);

  assert.strictEqual(syncResponse.appliedCount, 2);
  assert.strictEqual(syncResponse.rejectedCount, 0);

  const updatedEntry = queueService.getEntryById(staffContext, entry.id);
  assert.strictEqual(updatedEntry.state, 'IN_SERVICE');
});

test('Security & Privacy Hardening: Rate limiting, session revocation, privacy export, and anonymization', async () => {
  securityService.clear();

  const ownerContext = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
  };

  // 1. Test Rate Limiting
  const ipKey = 'rate_ip_127_0_0_1';
  let allowedCount = 0;
  for (let i = 0; i < 6; i++) {
    const res = securityService.checkRateLimit(ipKey, 5, 60000);
    if (res.allowed) allowedCount++;
  }
  assert.strictEqual(allowedCount, 5, 'Must block 6th hit when maxHits is 5');

  // 2. Test Session Revocation
  const sessionId = 'sess_xyz_123';
  assert.strictEqual(securityService.isSessionValid(sessionId), true);
  securityService.revokeSession(sessionId);
  assert.strictEqual(securityService.isSessionValid(sessionId), false);

  // 3. Test Privacy Data Export and Anonymization
  const exportBundle = securityService.exportCustomerData(ownerContext, '+15554433');
  assert.ok(exportBundle.exportedAtIso);

  const anonResult = securityService.anonymizeCustomerData(ownerContext, '+15554433');
  assert.strictEqual(anonResult.success, true);
});

test('Observability: Correlation context tracking and system health probes', async () => {
  const corrCtx = observabilityService.createCorrelationContext('custom-trace-header-123');
  assert.strictEqual(corrCtx.correlationId, 'custom-trace-header-123');

  const healthProbe = observabilityService.getHealthProbe();
  assert.strictEqual(healthProbe.status, 'UP');
  assert.strictEqual(healthProbe.databaseStoreStatus, 'HEALTHY');
});

test('MVP Readiness Audit: Programmatic verification of all core product invariants', async () => {
  const auditReport = await MvpReadinessAuditor.runAudit();

  assert.strictEqual(auditReport.overallStatus, 'PASSED', `MVP Readiness Audit failed: ${JSON.stringify(auditReport.checks)}`);
  assert.strictEqual(auditReport.failedChecks, 0);
  assert.strictEqual(auditReport.passedChecks, 8);
});
