import test from 'node:test';
import assert from 'node:assert';
import { masterDataService } from '../src/modules/masterdata/service.ts';
import { masterDataStore } from '../src/modules/masterdata/store.ts';
import { TenantIsolationError, NotFoundError } from '../src/lib/errors.ts';

test('Master Data Service Scopes Locations to Tenant', () => {
  const actorA = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  const locations = masterDataService.getTenantLocations(actorA);
  assert.strictEqual(locations.length, 1);
  assert.strictEqual(locations[0].id, 'loc-a-1');
  assert.strictEqual(locations[0].timezone, 'America/New_York');
});

test('Cross-Tenant Location Access Throws TenantIsolationError', () => {
  const actorB = {
    userId: 'user-owner-b',
    tenantId: 'tenant-b-222',
    role: 'SALON_OWNER',
    locationIds: ['loc-b-1'],
  };

  // Tenant B actor attempting to fetch Tenant A location 'loc-a-1'
  assert.throws(
    () => {
      masterDataService.getLocation(actorB, 'loc-a-1');
    },
    { name: 'TenantIsolationError' }
  );
});

test('Services Store Default Durations and Resource Requirements', () => {
  const actorA = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  const services = masterDataService.getTenantServices(actorA);
  assert.strictEqual(services.length, 2);

  const haircut = services.find((s) => s.id === 'srv-haircut');
  assert.ok(haircut);
  assert.strictEqual(haircut.defaultDurationMin, 30);
  assert.strictEqual(haircut.requiredResourceType, 'CHAIR');

  const beard = services.find((s) => s.id === 'srv-beard');
  assert.ok(beard);
  assert.strictEqual(beard.defaultDurationMin, 15);
});

test('Staff Eligibility Filtered by Location and Service Skill', () => {
  const actorA = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  const eligibleStaff = masterDataService.getEligibleStaff(actorA, 'loc-a-1', 'srv-haircut');
  assert.strictEqual(eligibleStaff.length, 1);
  assert.strictEqual(eligibleStaff[0].id, 'staff-sam');
  assert.strictEqual(eligibleStaff[0].shifts.length, 1);
  assert.strictEqual(eligibleStaff[0].breaks.length, 1);
});

test('Location Operational Policies Retrievable with Grace Windows', () => {
  const actorA = {
    userId: 'user-owner-a',
    tenantId: 'tenant-a-111',
    role: 'SALON_OWNER',
    locationIds: ['loc-a-1'],
  };

  const policy = masterDataService.getLocationPolicy(actorA, 'loc-a-1');
  assert.strictEqual(policy.cancellationWindowHours, 24);
  assert.strictEqual(policy.lateArrivalGraceMinutes, 10);
  assert.strictEqual(policy.queueGraceMinutes, 10);
});
