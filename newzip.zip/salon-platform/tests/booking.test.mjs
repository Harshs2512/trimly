import test from 'node:test';
import assert from 'node:assert';
import { bookingService } from '../src/modules/booking/service.ts';
import { bookingStore } from '../src/modules/booking/store.ts';
import { CapacityConcurrencyError, ValidationError } from '../src/lib/errors.ts';

const actorA = {
  userId: 'user-owner-a',
  tenantId: 'tenant-a-111',
  role: 'SALON_OWNER',
  locationIds: ['loc-a-1'],
};

test('Calculate Available Slots for Service', () => {
  const slots = bookingService.calculateAvailableSlots(
    actorA,
    'loc-a-1',
    'srv-haircut',
    '2026-08-15',
    'staff-sam'
  );

  assert.ok(Array.isArray(slots));
  assert.ok(slots.length > 0);
  assert.strictEqual(slots[0].staffId, 'staff-sam');
  assert.strictEqual(slots[0].isAvailable, true);
});

test('Acquire Temporary Hold on Capacity', () => {
  const startIso = '2026-08-15T10:00:00.000Z';
  const endIso = '2026-08-15T10:30:00.000Z';

  const hold = bookingService.acquireHold(
    actorA,
    'loc-a-1',
    'srv-haircut',
    'staff-sam',
    startIso,
    endIso
  );

  assert.ok(hold.id);
  assert.strictEqual(hold.status, 'ACTIVE');
  assert.strictEqual(hold.staffId, 'staff-sam');
});

test('CONCURRENCY TEST: Two Users Cannot Acquire Same Capacity Interval', () => {
  const startIso = '2026-08-15T11:00:00.000Z';
  const endIso = '2026-08-15T11:30:00.000Z';

  // User 1 acquires hold
  const hold1 = bookingService.acquireHold(
    actorA,
    'loc-a-1',
    'srv-haircut',
    'staff-sam',
    startIso,
    endIso
  );
  assert.ok(hold1.id);

  // User 2 attempts to acquire hold for same interval -> MUST throw CapacityConcurrencyError
  assert.throws(
    () => {
      bookingService.acquireHold(
        actorA,
        'loc-a-1',
        'srv-haircut',
        'staff-sam',
        startIso,
        endIso
      );
    },
    { name: 'CapacityConcurrencyError' }
  );
});

test('Confirm Appointment Converts Hold and Protects Idempotency', async () => {
  const startIso = '2026-08-15T14:00:00.000Z';
  const endIso = '2026-08-15T14:30:00.000Z';

  const hold = bookingService.acquireHold(
    actorA,
    'loc-a-1',
    'srv-haircut',
    'staff-sam',
    startIso,
    endIso
  );

  const idempotencyKey = `idem-key-test-${Date.now()}`;

  // First confirmation call succeeds
  const apt1 = await bookingService.confirmAppointment(
    actorA,
    hold.id,
    'John Customer',
    '+15551234567',
    idempotencyKey
  );

  assert.ok(apt1.id);
  assert.strictEqual(apt1.status, 'CONFIRMED');
  assert.strictEqual(apt1.customerName, 'John Customer');

  // Second confirmation call with identical idempotencyKey returns exact same appointment
  const apt2 = await bookingService.confirmAppointment(
    actorA,
    hold.id,
    'John Customer',
    '+15551234567',
    idempotencyKey
  );

  assert.strictEqual(apt2.id, apt1.id);
});
