import test from 'node:test';
import assert from 'node:assert';
import { parseConfig } from '../src/lib/config.ts';
import { formatErrorResponse, TenantIsolationError, CapacityConcurrencyError } from '../src/lib/errors.ts';
import { Logger } from '../src/lib/logger.ts';

test('Config Parser Validates Required Fields', () => {
  const env = {
    NODE_ENV: 'test',
    JWT_SECRET: 'test_secret_key_at_least_16_chars',
    DATABASE_URL: 'postgresql://postgres:postgres@localhost:5432/salon_platform',
  };
  const cfg = parseConfig(env);
  assert.strictEqual(cfg.NODE_ENV, 'test');
  assert.strictEqual(cfg.ENABLE_VIRTUAL_QUEUE, true);
});

test('Error Taxonomy Formats Expected Outputs', () => {
  const isolationErr = new TenantIsolationError('Attempted cross tenant read');
  const formattedIsolation = formatErrorResponse(isolationErr);
  assert.strictEqual(formattedIsolation.success, false);
  assert.strictEqual(formattedIsolation.error.code, 'TENANT_ISOLATION_VIOLATION');

  const concurrencyErr = new CapacityConcurrencyError();
  const formattedConcurrency = formatErrorResponse(concurrencyErr);
  assert.strictEqual(formattedConcurrency.error.code, 'CAPACITY_CONCURRENCY_CONFLICT');
});

test('Logger Redacts Sensitive Attributes', () => {
  const logger = new Logger('TestLogger');
  let output = '';
  const originalLog = console.log;
  console.log = (msg) => { output = msg; };

  logger.info('Test login attempt', {
    user: 'barber_sam',
    password: 'super_secret_password_123',
    token: 'jwt_bearer_token',
  });

  console.log = originalLog;
  const parsed = JSON.parse(output);

  assert.strictEqual(parsed.meta.user, 'barber_sam');
  assert.strictEqual(parsed.meta.password, '[REDACTED]');
  assert.strictEqual(parsed.meta.token, '[REDACTED]');
});
