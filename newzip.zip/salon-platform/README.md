# Trimly Salon Platform — Local Setup & PostgreSQL Instructions

## Quick Start Development Server

```bash
cd salon-platform
npm install
npm run dev
```

The application runs at `http://localhost:3000`.

---

## Local PostgreSQL Setup for Booking Concurrency & Exclusion Constraints

Phase 06b introduces PostgreSQL persistence for the Booking engine with **exclusion constraints** enforcing zero capacity overlap for staff reservations.

### 1. Run Local PostgreSQL via Docker
```bash
docker run --name trimly-postgres \
  -e POSTGRES_USER=postgres \
  -e POSTGRES_PASSWORD=postgres \
  -e POSTGRES_DB=salon_platform \
  -p 5432:5432 \
  -d postgres:16
```

### 2. Apply Migration
```bash
# Execute schema migration against local Postgres container
docker exec -i trimly-postgres psql -U postgres -d salon_platform < migrations/001_booking_schema.sql
```

### 3. Verify Database Environment Variable
Ensure `.env.local` contains:
```env
DATABASE_URL=postgresql://postgres:postgres@localhost:5432/salon_platform?schema=public
```

---

## Automated Test Suite

```bash
npm test
```

Executes all 37 unit, integration, and PostgreSQL concurrency test suites.
