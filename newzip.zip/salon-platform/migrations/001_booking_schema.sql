-- Migration 001: PostgreSQL Booking Schema with Exclusion Constraints
-- Authoritative schema for Booking Integrity (AGENTS.md §9 & §18)

-- 1. Enable extension required for multi-column EXCLUDE constraints using btree + gist
CREATE EXTENSION IF NOT EXISTS btree_gist;

-- 2. Appointments Table
CREATE TABLE IF NOT EXISTS appointments (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL,
    location_id VARCHAR(64) NOT NULL,
    customer_id VARCHAR(64) NOT NULL,
    customer_name VARCHAR(128) NOT NULL,
    customer_phone VARCHAR(32) NOT NULL,
    staff_id VARCHAR(64) NOT NULL,
    service_id VARCHAR(64) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'CONFIRMED',
    idempotency_key VARCHAR(128) UNIQUE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_appointments_tenant_location ON appointments(tenant_id, location_id);
CREATE INDEX IF NOT EXISTS idx_appointments_staff_time ON appointments(staff_id, start_time, end_time);

-- 3. Appointment Items Table
CREATE TABLE IF NOT EXISTS appointment_items (
    id VARCHAR(64) PRIMARY KEY,
    appointment_id VARCHAR(64) NOT NULL REFERENCES appointments(id) ON DELETE CASCADE,
    service_id VARCHAR(64) NOT NULL,
    service_name VARCHAR(128) NOT NULL,
    duration_minutes INT NOT NULL,
    price NUMERIC(10, 2) NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- 4. Resource Reservations Table with Exclusion Constraint (Enforces No Overlap)
CREATE TABLE IF NOT EXISTS resource_reservations (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL,
    location_id VARCHAR(64) NOT NULL,
    resource_type VARCHAR(32) NOT NULL, -- 'STAFF' or 'CHAIR' / 'ROOM'
    resource_id VARCHAR(64) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    time_range TSTZRANGE GENERATED ALWAYS AS (tstzrange(start_time, end_time, '[)')) STORED,
    appointment_id VARCHAR(64) REFERENCES appointments(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,

    -- Exclusion Constraint enforcing zero overlapping reservations for the same staff/resource
    CONSTRAINT no_overlapping_resource_reservations EXCLUDE USING gist (
        tenant_id WITH =,
        resource_id WITH =,
        time_range WITH &&
    )
);

-- 5. Booking Holds Table (Temporary Slot Holds with Expiry TTL)
CREATE TABLE IF NOT EXISTS booking_holds (
    id VARCHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(64) NOT NULL,
    location_id VARCHAR(64) NOT NULL,
    staff_id VARCHAR(64) NOT NULL,
    service_id VARCHAR(64) NOT NULL,
    start_time TIMESTAMPTZ NOT NULL,
    end_time TIMESTAMPTZ NOT NULL,
    expires_at TIMESTAMPTZ NOT NULL,
    status VARCHAR(32) NOT NULL DEFAULT 'ACTIVE',
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_booking_holds_staff_time ON booking_holds(staff_id, start_time, end_time);
CREATE INDEX IF NOT EXISTS idx_booking_holds_expires_at ON booking_holds(expires_at);
