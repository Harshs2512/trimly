# AGENTS.md
## Online Salon Appointment and Queue Management System

This file defines mandatory operating rules for every AI coding agent working on this project.

The objective is to analyze an existing product **without changing it**, then build a **new, isolated Salon Appointment and Queue Management application** sequentially according to `PRD.md` and the approved source requirements.

---

# 1. Non-Negotiable Rule: Existing Product Is Read-Only

The existing product is a reference system only.

You MAY:

- inspect directories and files
- read source code
- read package/configuration files
- inspect database models/schema definitions
- inspect API routes
- inspect authentication and authorization
- inspect UI components and design patterns
- inspect tests
- inspect deployment/configuration structure
- inspect environment variable names without exposing secret values
- document verified architecture and workflows
- reuse concepts after explicitly documenting them

You MUST NOT:

- edit any existing source file
- rename, move, delete, or reformat existing files
- modify `package.json`
- modify lock files
- install dependencies into the existing product
- run formatters that change existing files
- change existing database schema or migrations
- modify existing APIs
- change existing authentication or authorization
- modify existing UI
- modify existing environment files
- change existing deployment configuration
- commit changes into the existing application
- perform automated "cleanup" or "refactoring" on the existing application

All new implementation must live in a separately approved application boundary.

Preferred structure:

```text
/existing-product     # READ ONLY
/salon-platform       # WRITE ALLOWED
```

If the real workspace differs, identify and document the safe boundary before writing any code.

---

# 2. Source-of-Truth Priority

When instructions or observations conflict, follow this order:

1. The user's latest explicit instruction.
2. `PRD.md`.
3. The approved Online Salon Appointment and Queue-Management System source document.
4. Verified behavior and structure found in the existing product.
5. Approved architecture/design documents created during this project.
6. General engineering knowledge.

General model knowledge must never silently override a higher-priority source.

If two higher-priority sources conflict:

1. Stop the affected implementation.
2. Record the conflict.
3. Explain the impact.
4. Ask for clarification only when the conflict blocks safe progress.

Do not invent a resolution.

---

# 3. Anti-Hallucination Protocol

Every agent must distinguish between facts, inference, assumptions, and unknowns.

Use the following statuses in analysis and implementation reports:

- `VERIFIED` — directly confirmed from source code, source document, tests, runtime output, or approved specification.
- `INFERRED` — strongly suggested by evidence but not directly confirmed.
- `ASSUMPTION` — temporary implementation assumption explicitly stated before use.
- `UNKNOWN` — insufficient evidence.
- `NOT FOUND` — actively searched for but not located.

Rules:

- Never state that a module, API, table, workflow, package, feature, or integration exists unless it was verified.
- Never fabricate file paths, API routes, database tables, environment variables, third-party credentials, test results, or deployment details.
- Never claim code was tested unless the relevant command was actually executed successfully.
- Never claim a build passed unless it actually passed.
- Never claim a database migration succeeded unless it was executed and verified.
- Never invent business rules missing from the PRD.
- Never invent payment/provider credentials.
- Never expose secret values.
- Never silently make large product decisions.
- If a detail is not defined and does not block progress, use the safest reversible assumption and mark it `ASSUMPTION`.
- If a detail affects data integrity, security, payments, tenant isolation, booking concurrency, queue fairness, or public behavior, do not guess.

---

# 4. Sequential Execution Is Mandatory

The system must be developed in the following order.

Do not skip ahead unless explicitly authorized.

```text
PHASE 00  Existing Product Read-Only Analysis
PHASE 01  Gap Analysis Against PRD
PHASE 02  New Application Architecture
PHASE 03  Project Foundation
PHASE 04  Multi-Tenancy + Authentication + RBAC
PHASE 05  Salon Master Data
PHASE 06  Booking + Availability
PHASE 07  Virtual Walk-In Queue
PHASE 08  ETA + Dispatch Engine
PHASE 09  Realtime Infrastructure
PHASE 10  Customer PWA
PHASE 11  Salon Operations Dashboard
PHASE 12  Staff PWA
PHASE 13  Notification Engine
PHASE 14  Payments
PHASE 15  Cancellation + Rescheduling + Waitlist Refill
PHASE 16  QR / Kiosk Check-In
PHASE 17  Platform Admin
PHASE 18  Analytics
PHASE 19  Offline Staff Behaviour
PHASE 20  Security / Privacy / Audit Hardening
PHASE 21  Testing / Observability / Deployment
PHASE 22  MVP Readiness Audit
```

Later phases, not part of the initial MVP unless explicitly approved:

```text
PHASE 23  Demand Forecasting
PHASE 24  Staffing Optimizer
PHASE 25  Multi-Location Balancing
PHASE 26  Advanced Integrations
```

---

# 5. Phase Gate Rule

Before starting any phase, verify:

- required previous phase is complete
- required artifacts exist
- unresolved blocker list is empty or explicitly accepted
- no existing-product files are modified
- architecture assumptions remain valid

At the end of every phase, produce a **Phase Completion Report**.

Required format:

```text
PHASE:
STATUS: COMPLETE | PARTIAL | BLOCKED

VERIFIED OUTPUTS:
- ...

CREATED FILES:
- ...

MODIFIED FILES:
- ...

TESTS EXECUTED:
- command
- result

ASSUMPTIONS:
- ...

UNRESOLVED ITEMS:
- ...

SECURITY / DATA RISKS:
- ...

EXISTING PRODUCT CHANGES:
- NONE

NEXT ALLOWED PHASE:
- ...
```

A phase is not complete if:

- required acceptance criteria fail
- tests fail without an approved exception
- existing product files were changed
- unresolved data-integrity or security issues remain
- implementation contradicts `PRD.md`

---

# 6. Mandatory Change Boundary Check

Before and after every implementation phase:

1. Inspect repository status.
2. Identify every changed file.
3. Confirm each changed file belongs to the new salon application.
4. Revert accidental modifications to the existing product.
5. Report the final changed-file list.

Never complete a task while unrelated modifications remain.

If Git is available, inspect:

```bash
git status --short
git diff --name-only
```

These commands are examples; do not execute destructive Git operations without authorization.

---

# 7. Architecture Rules

The initial target architecture is a **modular monolith**.

Core internal modules:

```text
identity
tenants
locations
staff
services
resources
policies
availability
appointments
queue
dispatch
eta
realtime
notifications
payments
analytics
admin
audit
```

Rules:

- Keep module boundaries explicit.
- Avoid circular dependencies.
- Use interfaces/adapters for external services.
- Do not introduce microservices during the MVP unless explicitly approved.
- Do not create distributed transactions unnecessarily.
- Domain logic must not be hidden inside UI components.
- Controllers/routes should remain thin.
- Booking, queue, ETA, payments, and authorization require dedicated domain/service logic.
- Cross-module writes must follow documented transactional/event boundaries.

---

# 8. Core Product Invariant

The product is not merely an appointment calendar.

The core business model is:

```text
Scheduled Appointments
+
Live Walk-Ins
+
Virtual Queue
+
Continuously Updated ETA Range
+
Remote Waiting
+
Staff / Resource Capacity Orchestration
```

Appointments and walk-ins must be treated as competing consumers of the same real salon capacity.

Do not build separate systems that ignore each other.

---

# 9. Booking Integrity Rules

Critical invariant:

> Two customers must never be able to confirm the same staff/resource capacity interval.

Availability must consider, as applicable:

- tenant
- location
- service
- service duration
- staff skill
- staff location
- staff shift
- staff break
- existing appointments
- temporary holds
- required resources/chairs/rooms
- staff preference
- resource reservations

Booking confirmation must:

1. validate input
2. authorize tenant/location context
3. create or validate a temporary hold when applicable
4. re-check authoritative availability
5. perform capacity reservation transactionally
6. use idempotency
7. confirm only after the authoritative write succeeds
8. release expired holds safely

Concurrency tests are mandatory before the Booking phase can pass.

---

# 10. Queue Rules

Primary queue states:

```text
WAITING
APPROACHING
CALLED
CHECKED_IN
IN_SERVICE
COMPLETED
```

Terminal alternatives:

```text
CANCELLED
EXPIRED
NO_SHOW
```

Maintain:

- current `QUEUE_ENTRY` state
- append-only `QUEUE_EVENT` history

Every state transition must validate:

- current state
- requested transition
- actor
- tenant/location
- permissions
- timestamp
- idempotency when relevant

Queue changes must trigger ETA recalculation when they affect capacity or ordering.

Do not make "people ahead" the authoritative waiting metric.

---

# 11. ETA Rules

ETA V1 must be deterministic/statistical and explainable.

Do not implement generative AI or opaque ML for MVP ETA.

Inputs may include:

- active queue entries
- service requested
- configured duration
- observed historical duration when available
- eligible staff
- staff skills
- staff status
- service in progress
- expected completion
- future appointments
- shifts
- breaks
- staff preference
- resource constraints
- check-in/grace state

Customer-facing output must use a range such as:

```text
Estimated service: 12:35–12:45
Estimated wait: 24–34 minutes
Recommended arrival: 12:27
```

Avoid false minute-level precision.

Persist model/version metadata so estimates can be evaluated later.

---

# 12. Realtime Rules

The server/database remains authoritative.

Realtime transports may include:

- WebSocket for salon/staff operational screens
- SSE for active customer queue views
- polling fallback
- push/SMS/email for background alerts

Realtime messages communicate state changes; they are not the authoritative data store.

All subscriptions must be tenant/location scoped and authorized.

Never expose events from one salon/tenant to another.

---

# 13. Multi-Tenancy and Authorization Rules

Cross-tenant data access is a critical security failure.

Every tenant-owned request must validate:

- authenticated identity
- tenant membership
- role
- location scope where applicable
- requested resource ownership

Protect against IDOR.

Do not trust tenant IDs, user IDs, staff IDs, appointment IDs, queue IDs, or location IDs supplied by the client without server-side ownership checks.

Minimum internal roles:

```text
PLATFORM_ADMIN
SALON_OWNER
SALON_MANAGER
RECEPTIONIST
STAFF
```

Customer identity should be logically separated from salon staff/administrative identity where appropriate.

Cross-tenant authorization tests are mandatory.

---

# 14. Security Rules

Apply secure defaults.

Where applicable include:

- input validation
- output encoding
- injection prevention
- XSS prevention
- CSRF protection
- secure cookies
- session expiration
- session revocation
- MFA-ready architecture for privileged users
- rate limiting
- OTP abuse protection
- bot protection
- secure headers
- CORS restrictions
- secret management
- dependency scanning
- audit events
- log redaction

Never log:

- passwords
- OTPs
- access tokens
- refresh tokens
- authorization headers
- payment card details
- CVV
- secrets

---

# 15. Payment Rules

Supported business policies may include:

```text
PAY_IN_SALON
DEPOSIT
FULL_PREPAYMENT
CARD_ON_FILE_NO_SHOW_PROTECTION
```

Never store raw:

- card number
- CVV

Use provider-hosted or tokenized payment mechanisms.

Payment integration must be provider-abstracted.

Webhook processing must include:

- signature verification
- idempotency
- duplicate/replay handling
- safe logging
- retry behavior
- authoritative status reconciliation

Never mark a payment successful solely because the browser says it succeeded.

---

# 16. Notification Rules

Initial channels:

```text
EMAIL
SMS
PUSH
```

WhatsApp may be added later through the same abstraction.

Examples of events:

- appointment confirmed
- appointment reminder
- appointment changed
- appointment cancelled
- queue joined
- significant ETA change
- approaching
- leave-for-salon
- you are next
- customer called
- waitlist opening
- payment receipt

Transactional communications and marketing consent must remain logically separate.

Prevent duplicate critical notifications.

---

# 17. Offline Rules

Offline staff operation is intentionally limited.

Safe offline operations may include:

- start service
- complete service
- approved service notes

Each mutation should carry:

- local mutation ID
- timestamp
- device ID
- idempotency key

Do not confirm guaranteed future bookings offline.

On reconnect:

1. send queued mutation
2. detect conflicts
3. apply safe reconciliation
4. require manager intervention if ambiguous
5. acknowledge only after authoritative server processing

---

# 18. Data Model Principles

Core domain concepts include:

```text
TENANT
LOCATION
CUSTOMER
STAFF
SERVICE
POLICY
STAFF_LOCATION
STAFF_SERVICE
SHIFT
BREAK
RESOURCE
APPOINTMENT
APPOINTMENT_ITEM
RESOURCE_RESERVATION
BOOKING_HOLD
QUEUE_ENTRY
QUEUE_EVENT
WAIT_ESTIMATE
NOTIFICATION
PAYMENT
AUDIT_LOG
```

Do not create a table/entity merely because it appears in this list if the approved architecture represents it differently.

Any schema design must preserve the domain behavior and integrity requirements in `PRD.md`.

---

# 19. Data and Privacy Rules

Treat at minimum the following as protected data:

- customer name
- phone
- email
- queue state/ETA
- service history
- staff schedules
- payment processor references
- consent/revocation history

Build privacy capabilities so the platform can support:

- access/export
- correction
- deletion where applicable
- retention
- marketing opt-out
- consent history

Long-lived analytics/modeling data should minimize or pseudonymize personal data where practical.

---

# 20. Testing Requirements

Required testing layers:

- unit
- integration
- API/contract
- authorization
- tenant-isolation
- concurrency
- queue-state transition
- ETA
- webhook
- notification
- realtime
- end-to-end
- performance/load for peak demand

High-risk test scenarios include:

- two users booking the same capacity
- forged tenant ID
- forged appointment ID
- queue transition from invalid state
- duplicate payment webhook
- repeated booking request with same idempotency key
- expired hold confirmation
- staff becomes unavailable while customers wait
- appointment overlaps an active queue forecast
- realtime cross-tenant subscription attempt

Do not disable tests merely to make a build pass.

---

# 21. Observability Rules

Production preparation must include, as applicable:

- structured logs
- request correlation IDs
- metrics
- traces
- queue lag
- booking failure metrics
- payment failure metrics
- notification delivery/failure metrics
- WebSocket connection/reconnection health
- database slow queries
- ETA prediction error
- provider webhook errors

Sensitive information must be redacted.

---

# 22. Accessibility and UX

Customer and business web interfaces should target WCAG 2.2 AA.

Required considerations:

- keyboard access
- visible focus
- semantic controls
- form labels
- error identification
- sufficient contrast
- responsive layout
- touch-friendly controls
- loading states
- empty states
- failure states
- stale realtime state
- offline state where supported

Do not hide critical workflow behavior behind hover-only interactions.

---

# 23. MVP Scope Protection

Do not add these during MVP unless specifically authorized:

- full consumer marketplace
- payroll
- full inventory management
- AI voice receptionist
- generative AI
- full POS replacement
- native customer iOS/Android apps
- advanced ML demand forecasting
- complex commissions
- enterprise SSO
- cross-city discovery
- advanced loyalty automation
- multi-region active-active deployment

Avoid scope creep.

---

# 24. Coding Standards

Code must be:

- secure
- maintainable
- modular
- testable
- typed where the selected stack supports it
- explicit about errors
- explicit about authorization
- explicit about tenant context

Prefer:

- small cohesive modules
- schema validation at external boundaries
- domain services for business rules
- provider adapters
- dependency inversion around external integrations
- centralized error taxonomy
- idempotent command handling
- structured audit events

Avoid:

- huge components
- business logic inside page/view code
- raw database operations scattered through controllers
- duplicated authorization checks with inconsistent behavior
- hidden cross-module coupling
- silent catch blocks
- arbitrary `any`/untyped payloads where avoidable
- hard-coded credentials
- hard-coded provider-specific business logic

---

# 25. No Unapproved Destructive Actions

Do not execute destructive operations without explicit approval.

Examples:

- deleting production/staging data
- dropping databases/tables
- resetting migrations
- force-pushing Git history
- deleting branches
- rotating secrets
- deleting cloud resources
- changing DNS
- altering production payment configuration

Prefer read-only inspection first.

---

# 26. Documentation Requirement

For every implemented module maintain documentation for:

- purpose
- business rules
- API contract
- data model
- authorization rules
- events
- configuration
- error cases
- tests
- operational considerations

Documentation must reflect actual implementation, not intended implementation.

---

# 27. Final Release Rule

The MVP is not ready simply because the UI works.

Release requires evidence that:

- tenant isolation works
- double booking is prevented
- queue transitions are valid
- ETA recalculates on relevant operational changes
- realtime is properly scoped
- payments are idempotent
- notifications are observable
- privileged actions are audited
- core workflows are tested
- deployment/recovery paths are documented
- there are no known critical security blockers

If any critical invariant is unverified, report the release as `BLOCKED`.
